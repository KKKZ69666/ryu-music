import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ryu/core/controllers/audio_controller.dart';
import 'package:ryu/core/controllers/library_controller.dart';
import 'package:ryu/core/models/history_entry.dart';
import 'package:ryu/core/models/playlist.dart';
import 'package:ryu/core/models/song.dart';
import 'package:ryu/core/ryu_scope.dart';
import 'package:ryu/core/services/storage_service.dart';
import 'package:ryu/core/theme/ryu_theme.dart';
import 'package:ryu/core/utils/duration_formatter.dart';
import 'package:ryu/core/utils/lrc_parser.dart';
import 'package:ryu/features/player/now_playing_screen.dart';
import 'package:ryu/features/shell/app_shell.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  test('DurationFormatter formats minutes and hours properly', () {
    expect(DurationFormatter.format(const Duration(seconds: 65)), '1:05');
    expect(
      DurationFormatter.format(const Duration(hours: 1, minutes: 2, seconds: 9)),
      '1:02:09',
    );
    expect(
      DurationFormatter.formatRemaining(
        const Duration(seconds: 30),
        const Duration(seconds: 90),
      ),
      '-1:00',
    );
  });

  test('LrcParser parses synced timestamps, metadata, and offset properly', () {
    const sample = """
[ti:Test Track]
[ar:RYU Artist]
[al:Midnight Neon]
[offset:+500]
[00:05.00] Line one
[00:10.50] Line two
[00:18.00] Line three
""";
    final lines = LrcParser.parse(sample);
    expect(lines.length, 3);
    expect(lines.first.isSynced, true);
    expect(lines.first.text, 'Line one');
    expect(lines.first.timestamp, const Duration(milliseconds: 4500));
    expect(
      LrcParser.findActiveIndex(lines, const Duration(seconds: 12)),
      1,
    );
  });

  test('Song, RyuPlaylist, and HistoryEntry serialize cleanly', () {
    const song = Song(
      id: 42,
      title: 'Midnight Drive',
      artist: 'RYU',
      album: 'Neon City',
      albumId: 7,
      durationMs: 215000,
      uri: 'content://media/external/audio/media/42',
      trackNumber: 3,
    );
    final restoredSong = Song.fromMap(song.toMap());
    expect(restoredSong, song);
    expect(restoredSong.duration, const Duration(milliseconds: 215000));

    final now = DateTime.utc(2026, 11, 24);
    final playlist = RyuPlaylist(
      id: 'pl_1',
      name: 'Late Night',
      description: 'Synthwave & R&B',
      songIds: const [42],
      createdAt: now,
      updatedAt: now,
    );
    final restoredPlaylist = RyuPlaylist.fromJson(playlist.toJson());
    expect(restoredPlaylist.id, 'pl_1');
    expect(restoredPlaylist.songIds, [42]);

    final entry = HistoryEntry(songId: 42, playedAt: now);
    final restoredEntry = HistoryEntry.fromJson(entry.toJson());
    expect(restoredEntry.songId, 42);
  });

  test('LibraryController manages favorites, playlists, and searches without recursion', () async {
    SharedPreferences.setMockInitialValues({});
    await StorageService.instance.init();

    final library = LibraryController();
    addTearDown(library.dispose);

    int notifications = 0;
    library.addListener(() => notifications++);

    await library.toggleFavorite(101);
    expect(library.isFavorite(101), true);
    expect(notifications, 1);

    final pl = await library.createPlaylist('Synthwave', initialSongIds: [101, 102]);
    expect(library.playlists.length, 1);
    expect(library.playlists.first.songIds, [101, 102]);

    await library.addSongsToPlaylist(pl.id, [102, 103]);
    expect(library.playlists.first.songIds, [101, 102, 103]);

    await library.reorderPlaylist(pl.id, 0, 3);
    expect(library.playlists.first.songIds, [102, 103, 101]);

    await library.removeSongFromPlaylist(pl.id, 103);
    expect(library.playlists.first.songIds, [102, 101]);

    await library.renamePlaylist(pl.id, 'Night Drive', newDescription: 'Updated');
    expect(library.playlists.first.name, 'Night Drive');
    expect(library.playlists.first.description, 'Updated');

    await library.addRecentSearch('Midnight');
    expect(library.recentSearches, ['Midnight']);
    await library.clearRecentSearches();
    expect(library.recentSearches, isEmpty);

    await library.deletePlaylist(pl.id);
    expect(library.playlists, isEmpty);
  });

  testWidgets('AppShell and NowPlayingScreen render cleanly on compact and standard viewports',
      (tester) async {
    SharedPreferences.setMockInitialValues({});
    await StorageService.instance.init();

    final library = LibraryController();
    final audio = AudioController(library: library);
    addTearDown(() {
      audio.dispose();
      library.dispose();
    });

    for (final size in const [Size(360, 640), Size(412, 915)]) {
      tester.view.physicalSize = size;
      tester.view.devicePixelRatio = 1.0;
      addTearDown(tester.view.resetPhysicalSize);
      addTearDown(tester.view.resetDevicePixelRatio);

      await tester.pumpWidget(
        RyuScope(
          library: library,
          audio: audio,
          child: MaterialApp(
            theme: RyuTheme.dark(),
            home: const AppShell(),
          ),
        ),
      );
      await tester.pump();
      expect(tester.takeException(), isNull);

      await tester.tap(find.text('Search'));
      await tester.pump();
      expect(tester.takeException(), isNull);

      await tester.tap(find.text('Library'));
      await tester.pump();
      expect(tester.takeException(), isNull);

      await tester.pumpWidget(
        RyuScope(
          library: library,
          audio: audio,
          child: MaterialApp(
            theme: RyuTheme.dark(),
            home: const NowPlayingScreen(),
          ),
        ),
      );
      await tester.pump();
      expect(tester.takeException(), isNull);
    }
  });
}
