#!/usr/bin/env bash
set -e

echo "=== [1/6] Membersihkan build cache (flutter clean) ==="
flutter clean

echo "=== [2/6] Mengunduh dependency Flutter (flutter pub get) ==="
flutter pub get

mkdir -p android/gradle/wrapper
if [ ! -f "android/gradle/wrapper/gradle-wrapper.jar" ]; then
  echo "=== [3/6] Melengkapi Gradle Wrapper JAR secara aman ==="
  TMP_GW=$(mktemp -d)
  if command -v gradle >/dev/null 2>&1; then
    (cd "$TMP_GW" && gradle wrapper --gradle-version 8.7 --distribution-type all)
    cp "$TMP_GW/gradle/wrapper/gradle-wrapper.jar" android/gradle/wrapper/gradle-wrapper.jar
  else
    flutter create "$TMP_GW/app" --platforms=android >/dev/null
    cp "$TMP_GW/app/android/gradle/wrapper/gradle-wrapper.jar" android/gradle/wrapper/gradle-wrapper.jar
  fi
  rm -rf "$TMP_GW"
else
  echo "=== [3/6] Gradle Wrapper sudah tersedia ==="
fi
chmod +x android/gradlew

echo "=== [4/6] Analisis statis (flutter analyze) ==="
flutter analyze

echo "=== [5/6] Menjalankan unit & widget test (flutter test) ==="
flutter test

echo "=== [6/6] Build Release APK (flutter build apk --release) ==="
flutter build apk --release

cp build/app/outputs/flutter-apk/app-release.apk ./RYU-RELEASE.apk
echo ""
echo "SUKSES! File APK siap instalasi tersimpan di: $(pwd)/RYU-RELEASE.apk"
