import 'dart:convert';
import '../utils/uri_utils.dart';

/// Unified track model for local (MediaStore) and online (provider) songs.
///
/// [id] stays an int for backward compatibility with stored favorites,
/// playlists and history. Local songs keep their MediaStore id (>= 0);
/// online songs get a stable negative id derived from [key].
class Song {
  const Song({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.albumId,
    required this.durationMs,
    required this.uri,
    this.filePath,
    this.dateAdded = 0,
    this.trackNumber = 0,
    this.provider = 'local',
    this.remoteId,
    this.artworkUrl,
    this.downloadUrl,
  });

  final int id;
  final String title;
  final String artist;
  final String album;
  final int albumId;
  final int durationMs;
  final String uri;
  final String? filePath;
  final int dateAdded;
  final int trackNumber;

  /// 'local', 'ytmusic', ...
  final String provider;
  final String? remoteId;
  final String? artworkUrl;

  /// Direct file URL, only set when the provider explicitly allows download.
  final String? downloadUrl;

  /// Online artwork lookup by song id so shared widgets can render URLs.
  static final Map<int, String> onlineArtwork = {};

  bool get isOnline => provider != 'local';
  Duration get duration => Duration(milliseconds: durationMs);

  /// True when this song has a legitimate audio stream that just_audio can play.
  bool get isPlayable =>
      !isOnline || (uri.isNotEmpty && !uri.startsWith('ytmusic://'));

  /// For catalog-only tracks, returns the official service URL.
  String? get catalogUrl {
    if (!isPlayable && remoteId != null && remoteId!.isNotEmpty) {
      return 'https://music.youtube.com/watch?v=$remoteId';
    }
    return null;
  }

  /// Globally unique identity, e.g. `local:42` or `ytmusic:videoId`.
  String get key => isOnline ? '$provider:${remoteId ?? id}' : 'local:$id';

  /// Stable negative int id (FNV-1a, 52-bit) for an online track key.
  static int onlineIdFor(String key) {
    var h = 0xcbf29ce484222325 & 0xFFFFFFFFFFFFF;
    for (final c in key.codeUnits) {
      h ^= c;
      h = (h * 0x100000001b3) & 0xFFFFFFFFFFFFF;
    }
    return -(h == 0 ? 1 : h);
  }

  factory Song.online({
    required String provider,
    required String remoteId,
    required String title,
    required String artist,
    String album = '',
    int durationMs = 0,
    required String streamUrl,
    String? artworkUrl,
    String? downloadUrl,
  }) {
    final id = onlineIdFor('$provider:$remoteId');
    final safeStreamUrl = UriUtils.preferHttps(streamUrl);
    final safeArtworkUrl = UriUtils.preferHttpsNullable(artworkUrl);
    final safeDownloadUrl = UriUtils.preferHttpsNullable(downloadUrl);
    if (safeArtworkUrl != null && safeArtworkUrl.isNotEmpty) {
      onlineArtwork[id] = safeArtworkUrl;
    }
    return Song(
      id: id,
      title: title,
      artist: artist,
      album: album,
      albumId: -1,
      durationMs: durationMs,
      uri: safeStreamUrl,
      provider: provider,
      remoteId: remoteId,
      artworkUrl: safeArtworkUrl,
      downloadUrl: safeDownloadUrl,
      dateAdded: DateTime.now().millisecondsSinceEpoch ~/ 1000,
    );
  }

  factory Song.fromMap(Map<dynamic, dynamic> map) {
    return Song(
      id: (map['id'] as num?)?.toInt() ?? 0,
      title: (map['title'] as String?) ?? 'Unknown Title',
      artist: (map['artist'] as String?) ?? 'Unknown Artist',
      album: (map['album'] as String?) ?? 'Unknown Album',
      albumId: (map['albumId'] as num?)?.toInt() ?? -1,
      durationMs: (map['durationMs'] as num?)?.toInt() ?? 0,
      uri: ((map['provider'] as String?) ?? 'local') != 'local'
          ? UriUtils.preferHttps((map['uri'] as String?) ?? '')
          : ((map['uri'] as String?) ?? ''),
      filePath: map['filePath'] as String?,
      dateAdded: (map['dateAdded'] as num?)?.toInt() ?? 0,
      trackNumber: (map['trackNumber'] as num?)?.toInt() ?? 0,
      provider: (map['provider'] as String?) ?? 'local',
      remoteId: map['remoteId'] as String?,
      artworkUrl: UriUtils.preferHttpsNullable(map['artworkUrl'] as String?),
      downloadUrl: UriUtils.preferHttpsNullable(map['downloadUrl'] as String?),
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'artist': artist,
        'album': album,
        'albumId': albumId,
        'durationMs': durationMs,
        'uri': uri,
        'filePath': filePath,
        'dateAdded': dateAdded,
        'trackNumber': trackNumber,
        'provider': provider,
        'remoteId': remoteId,
        'artworkUrl': artworkUrl,
        'downloadUrl': downloadUrl,
      };

  String toJson() => jsonEncode(toMap());

  factory Song.fromJson(String source) {
    final map = jsonDecode(source) as Map<String, dynamic>;
    return Song.fromMap(map);
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || (other is Song && other.id == id);

  @override
  int get hashCode => id.hashCode;
}
