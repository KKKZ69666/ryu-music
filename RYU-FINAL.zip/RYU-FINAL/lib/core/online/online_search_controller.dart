import 'dart:async';
import 'package:flutter/foundation.dart';
import '../models/song.dart';
import 'music_provider.dart';
import 'online_models.dart';
import 'provider_hub.dart';

enum OnlineSearchType { songs, artists, albums, playlists }

/// Debounced, paginated, multi-provider search state.
class OnlineSearchController extends ChangeNotifier {
  OnlineSearchController({List<MusicProvider>? providers})
      : _providers = providers ?? ProviderHub.instance.all;

  final List<MusicProvider> _providers;
  static const pageSize = 20;

  String _query = '';
  OnlineSearchType _type = OnlineSearchType.songs;
  String? _providerFilter; // null = all
  OnlineSort _sort = OnlineSort.relevance;

  final List<Song> _songs = [];
  final List<OnlineArtist> _artists = [];
  final List<OnlineAlbum> _albums = [];
  final List<OnlinePlaylist> _playlists = [];
  final List<Song> _trending = [];

  final Map<String, int> _offset = {};
  final Map<String, bool> _more = {};
  final Map<String, String> _errors = {};

  bool _loading = false;
  bool _loadingTrending = false;
  int _token = 0;
  Timer? _debounce;
  bool _disposed = false;

  String get query => _query;
  OnlineSearchType get type => _type;
  String? get providerFilter => _providerFilter;
  OnlineSort get sort => _sort;
  bool get loading => _loading;
  bool get loadingTrending => _loadingTrending;
  Map<String, String> get errors => Map.unmodifiable(_errors);
  List<MusicProvider> get providers => _providers;
  List<Song> get trending => List.unmodifiable(_trending);
  List<OnlineArtist> get artists => List.unmodifiable(_artists);
  List<OnlineAlbum> get albums => List.unmodifiable(_albums);
  List<OnlinePlaylist> get playlists => List.unmodifiable(_playlists);
  bool get hasMore => _active.any((p) => _more[p.id] ?? true) && _query.isNotEmpty;

  List<Song> get songs => sortSongs(_songs, _sort);

  int get resultCount => switch (_type) {
        OnlineSearchType.songs => _songs.length,
        OnlineSearchType.artists => _artists.length,
        OnlineSearchType.albums => _albums.length,
        OnlineSearchType.playlists => _playlists.length,
      };

  List<MusicProvider> get _active => _providers
      .where((p) => p.isAvailable && (_providerFilter == null || p.id == _providerFilter))
      .toList();

  @visibleForTesting
  static List<Song> sortSongs(List<Song> input, OnlineSort sort) {
    final l = List<Song>.from(input);
    switch (sort) {
      case OnlineSort.relevance:
        break;
      case OnlineSort.title:
        l.sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
      case OnlineSort.artist:
        l.sort((a, b) => a.artist.toLowerCase().compareTo(b.artist.toLowerCase()));
      case OnlineSort.shortest:
        l.sort((a, b) => a.durationMs.compareTo(b.durationMs));
      case OnlineSort.longest:
        l.sort((a, b) => b.durationMs.compareTo(a.durationMs));
    }
    return l;
  }

  /// Round-robin merge so one provider does not dominate the list.
  @visibleForTesting
  static List<T> interleave<T>(List<List<T>> lists) {
    final out = <T>[];
    var i = 0;
    var added = true;
    while (added) {
      added = false;
      for (final l in lists) {
        if (i < l.length) {
          out.add(l[i]);
          added = true;
        }
      }
      i++;
    }
    return out;
  }

  void _n() {
    if (!_disposed) notifyListeners();
  }

  void setQuery(String q) {
    _query = q.trim();
    _debounce?.cancel();
    if (_query.isEmpty) {
      _token++;
      _clearResults();
      _loading = false;
      _n();
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 450), () => _search(reset: true));
  }

  /// Run immediately (keyboard submit).
  void submit() {
    _debounce?.cancel();
    if (_query.isNotEmpty) _search(reset: true);
  }

  void setType(OnlineSearchType t) {
    if (_type == t) return;
    _type = t;
    if (_query.isNotEmpty) {
      _search(reset: true);
    } else {
      _n();
    }
  }

  void setProviderFilter(String? id) {
    if (_providerFilter == id) return;
    _providerFilter = id;
    if (_query.isNotEmpty) {
      _search(reset: true);
    } else {
      _n();
    }
  }

  void setSort(OnlineSort s) {
    _sort = s;
    _n();
  }

  void _clearResults() {
    _songs.clear();
    _artists.clear();
    _albums.clear();
    _playlists.clear();
    _offset.clear();
    _more.clear();
    _errors.clear();
  }

  Future<void> loadMore() async {
    if (_loading || !hasMore) return;
    await _search(reset: false);
  }

  Future<void> retry() => _search(reset: true);

  Future<void> _search({required bool reset}) async {
    final token = ++_token;
    if (reset) _clearResults();
    _errors.clear();
    _loading = true;
    _n();

    final type = _type;
    final q = _query;
    final targets = _active.where((p) => _more[p.id] ?? true).toList();

    final batches = await Future.wait<(MusicProvider, PagedResult<Object>?, String?)>(targets.map((p) async {
      final off = _offset[p.id] ?? 0;
      try {
        final PagedResult<Object> r = switch (type) {
          OnlineSearchType.songs => await p.searchTracks(q, offset: off, limit: pageSize),
          OnlineSearchType.artists => await p.searchArtists(q, offset: off, limit: pageSize),
          OnlineSearchType.albums => await p.searchAlbums(q, offset: off, limit: pageSize),
          OnlineSearchType.playlists => await p.searchPlaylists(q, offset: off, limit: pageSize),
        };
        return (p, r, null);
      } catch (e) {
        return (p, null, e.toString());
      }
    }));

    if (token != _token || _disposed) return; // superseded by a newer search

    final songBatches = <List<Song>>[];
    final artistBatches = <List<OnlineArtist>>[];
    final albumBatches = <List<OnlineAlbum>>[];
    final playlistBatches = <List<OnlinePlaylist>>[];
    for (final (p, r, err) in batches) {
      if (err != null || r == null) {
        _errors[p.id] = err ?? 'Unknown error';
        continue;
      }
      _offset[p.id] = (_offset[p.id] ?? 0) + pageSize;
      _more[p.id] = r.hasMore && r.items.isNotEmpty;
      switch (type) {
        case OnlineSearchType.songs:
          songBatches.add(r.items.cast<Song>());
        case OnlineSearchType.artists:
          artistBatches.add(r.items.cast<OnlineArtist>());
        case OnlineSearchType.albums:
          albumBatches.add(r.items.cast<OnlineAlbum>());
        case OnlineSearchType.playlists:
          playlistBatches.add(r.items.cast<OnlinePlaylist>());
      }
    }
    final seen = _songs.map((s) => s.id).toSet();
    _songs.addAll(interleave(songBatches).where((s) => seen.add(s.id)));
    _artists.addAll(interleave(artistBatches));
    _albums.addAll(interleave(albumBatches));
    _playlists.addAll(interleave(playlistBatches));
    _loading = false;
    _n();
  }

  /// Discovery content shown before the user types (only what providers return).
  Future<void> loadTrending() async {
    if (_loadingTrending) return;
    _loadingTrending = true;
    _n();
    final lists = await Future.wait(_providers.where((p) => p.isAvailable).map((p) async {
      try {
        return await p.trending(limit: 12);
      } catch (_) {
        return <Song>[];
      }
    }));
    _trending
      ..clear()
      ..addAll(interleave(lists));
    _loadingTrending = false;
    _n();
  }

  @override
  void dispose() {
    _disposed = true;
    _debounce?.cancel();
    super.dispose();
  }
}
