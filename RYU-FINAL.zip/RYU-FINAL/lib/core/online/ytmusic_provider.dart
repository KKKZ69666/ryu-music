import '../utils/uri_utils.dart';
import '../models/song.dart';
import 'music_provider.dart';
import 'online_models.dart';

// dart_ytmusic_api is used under GPL-3.0.
// See LICENSE file for full license text and notices.
import 'package:dart_ytmusic_api/yt_music.dart';

/// YouTube Music catalog provider for RYU Music.
///
/// This provider supplies metadata (titles, artists, albums, artwork, lyrics)
/// from the YouTube Music catalog. It does **not** provide audio streams.
/// Tracks discovered here are catalog-only; playback is handled through
/// other providers (Audius, Jamendo, local files) or by opening the
/// official service.
///
/// Licensed under GPL-3.0 (same as dart_ytmusic_api).
class YTMusicProvider extends MusicProvider {
  final YTMusic _yt = YTMusic();
  bool _initialized = false;

  @override
  String get id => 'ytmusic';

  @override
  String get displayName => 'Catalog';

  @override
  bool get isAvailable => true;

  @override
  String? get unavailableReason => null;

  @override
  bool get supportsDownload => false;

  @override
  String get licenseNote =>
      'Catalog metadata only. Audio playback is not provided. '
      'Uses dart_ytmusic_api (GPL-3.0).';

  Future<void> _ensureInit() async {
    if (_initialized) return;
    try {
      await _yt.initialize();
      _initialized = true;
    } catch (_) {
      // If initialization fails, we'll try again on next call.
    }
  }

  // ---- Thumbnail helpers ----
  static String? _bestThumb(dynamic thumbnails) {
    if (thumbnails is! List || thumbnails.isEmpty) return null;
    String? best;
    int bestW = 0;
    for (final t in thumbnails) {
      if (t is! Map) continue;
      final url = t['url'] as String?;
      final w = (t['width'] as num?)?.toInt() ?? 0;
      if (url != null && w >= bestW) {
        best = url;
        bestW = w;
      }
    }
    return UriUtils.preferHttpsNullable(best);
  }

  static String? _highResThumb(dynamic thumbnails) {
    final best = _bestThumb(thumbnails);
    if (best == null) return null;
    // Google's image server supports arbitrary resize by replacing the suffix
    return UriUtils.preferHttpsNullable(best.replaceAll(RegExp(r'=w\d+-h\d+.*'), '=w1200-h1200'));
  }

  // ---- Duration parser ----
  static int _parseDuration(dynamic value) {
    if (value is int) return value * 1000;
    if (value is num) return (value * 1000).round();
    if (value is String) {
      final parts = value.split(':').map(int.tryParse).whereType<int>().toList();
      if (parts.length == 2) return (parts[0] * 60 + parts[1]) * 1000;
      if (parts.length == 3) return (parts[0] * 3600 + parts[1] * 60 + parts[2]) * 1000;
    }
    return 0;
  }

  // ---- Song parser ----
  static Song? _parseSong(dynamic item, {String providerLabel = 'ytmusic'}) {
    if (item is! Map) return null;
    final videoId = item['videoId']?.toString();
    if (videoId == null || videoId.isEmpty) return null;

    final name = (item['name'] as String?) ?? 'Unknown Title';
    final artist = _firstArtist(item);
    final album = (item['album'] as String?) ?? '';
    final durationMs = _parseDuration(item['duration']);
    final thumbs = item['thumbnails'];
    final explicit = item['explicit'] == true;

    return Song.online(
      provider: providerLabel,
      remoteId: videoId,
      title: name,
      artist: artist,
      album: album,
      durationMs: durationMs,
      streamUrl: 'ytmusic://catalog/$videoId',
      artworkUrl: _highResThumb(thumbs) ?? _bestThumb(thumbs),
    );
  }

  static String _firstArtist(dynamic item) {
    if (item is! Map) return 'Unknown Artist';
    final artists = item['artists'];
    if (artists is List && artists.isNotEmpty) {
      final first = artists.first;
      if (first is Map) {
        return (first['name'] as String?) ?? 'Unknown Artist';
      }
    }
    return (item['artist'] as String?) ?? 'Unknown Artist';
  }

  // ---- Search: Songs ----
  @override
  Future<PagedResult<Song>> searchTracks(String q,
      {int offset = 0, int limit = 20}) async {
    await _ensureInit();
    try {
      final results = await _yt.searchSongs(q);
      if (results is! List) {
        return const PagedResult([], hasMore: false);
      }
      final items = results
          .skip(offset)
          .take(limit)
          .map((e) => _parseSong(e))
          .whereType<Song>()
          .toList();
      final hasMore = results.length > offset + limit;
      return PagedResult(items, hasMore: hasMore);
    } catch (e) {
      throw ProviderException('Catalog search failed: $e');
    }
  }

  // ---- Search: Videos ----
  Future<PagedResult<Song>> searchVideos(String q,
      {int offset = 0, int limit = 20}) async {
    await _ensureInit();
    try {
      final results = await _yt.searchVideos(q);
      if (results is! List) {
        return const PagedResult([], hasMore: false);
      }
      final items = results
          .skip(offset)
          .take(limit)
          .map((e) => _parseSong(e, providerLabel: 'ytmusic_video'))
          .whereType<Song>()
          .toList();
      final hasMore = results.length > offset + limit;
      return PagedResult(items, hasMore: hasMore);
    } catch (e) {
      throw ProviderException('Catalog video search failed: $e');
    }
  }

  // ---- Search: Artists ----
  @override
  Future<PagedResult<OnlineArtist>> searchArtists(String q,
      {int offset = 0, int limit = 20}) async {
    await _ensureInit();
    try {
      final results = await _yt.searchArtists(q);
      if (results is! List) {
        return const PagedResult([], hasMore: false);
      }
      final items = results
          .skip(offset)
          .take(limit)
          .map((e) {
            if (e is! Map) return null;
            final id = e['artistId']?.toString();
            if (id == null || id.isEmpty) return null;
            return OnlineArtist(
              provider: id,
              id: id,
              name: (e['name'] as String?) ?? 'Unknown Artist',
              imageUrl: _highResThumb(e['thumbnails']) ?? _bestThumb(e['thumbnails']),
            );
          })
          .whereType<OnlineArtist>()
          .toList();
      final hasMore = results.length > offset + limit;
      return PagedResult(items, hasMore: hasMore);
    } catch (e) {
      throw ProviderException('Catalog artist search failed: $e');
    }
  }

  // ---- Search: Albums ----
  @override
  Future<PagedResult<OnlineAlbum>> searchAlbums(String q,
      {int offset = 0, int limit = 20}) async {
    await _ensureInit();
    try {
      final results = await _yt.searchAlbums(q);
      if (results is! List) {
        return const PagedResult([], hasMore: false);
      }
      final items = results
          .skip(offset)
          .take(limit)
          .map((e) {
            if (e is! Map) return null;
            final id = e['albumId']?.toString();
            if (id == null || id.isEmpty) return null;
            return OnlineAlbum(
              provider: id,
              id: id,
              name: (e['name'] as String?) ?? 'Unknown Album',
              artist: _firstArtist(e),
              imageUrl: _highResThumb(e['thumbnails']) ?? _bestThumb(e['thumbnails']),
            );
          })
          .whereType<OnlineAlbum>()
          .toList();
      final hasMore = results.length > offset + limit;
      return PagedResult(items, hasMore: hasMore);
    } catch (e) {
      throw ProviderException('Catalog album search failed: $e');
    }
  }

  // ---- Search: Playlists ----
  @override
  Future<PagedResult<OnlinePlaylist>> searchPlaylists(String q,
      {int offset = 0, int limit = 20}) async {
    await _ensureInit();
    try {
      final results = await _yt.searchPlaylists(q);
      if (results is! List) {
        return const PagedResult([], hasMore: false);
      }
      final items = results
          .skip(offset)
          .take(limit)
          .map((e) {
            if (e is! Map) return null;
            final id = e['playlistId']?.toString();
            if (id == null || id.isEmpty) return null;
            return OnlinePlaylist(
              provider: id,
              id: id,
              name: (e['name'] as String?) ?? 'Unknown Playlist',
              owner: (e['author'] as String?) ?? '',
              imageUrl: _highResThumb(e['thumbnails']) ?? _bestThumb(e['thumbnails']),
            );
          })
          .whereType<OnlinePlaylist>()
          .toList();
      final hasMore = results.length > offset + limit;
      return PagedResult(items, hasMore: hasMore);
    } catch (e) {
      throw ProviderException('Catalog playlist search failed: $e');
    }
  }

  // ---- Artist tracks ----
  @override
  Future<List<Song>> artistTracks(OnlineArtist artist, {int limit = 50}) async {
    await _ensureInit();
    try {
      final result = await _yt.getArtist(artist.id);
      if (result is! Map) return [];
      final songs = result['songs'] ?? result['topSongs'];
      if (songs is! List) return [];
      return songs
          .take(limit)
          .map((e) => _parseSong(e))
          .whereType<Song>()
          .toList();
    } catch (e) {
      throw ProviderException('Catalog artist tracks failed: $e');
    }
  }

  // ---- Album tracks ----
  @override
  Future<List<Song>> albumTracks(OnlineAlbum album) async {
    await _ensureInit();
    try {
      final result = await _yt.getAlbum(album.id);
      if (result is! Map) return [];
      final songs = result['songs'];
      if (songs is! List) return [];
      return songs
          .map((e) => _parseSong(e))
          .whereType<Song>()
          .toList();
    } catch (e) {
      throw ProviderException('Catalog album tracks failed: $e');
    }
  }

  // ---- Playlist tracks ----
  @override
  Future<List<Song>> playlistTracks(OnlinePlaylist playlist) async {
    await _ensureInit();
    try {
      final result = await _yt.getPlaylist(playlist.id);
      if (result is! Map) return [];
      final videos = result['videos'] ?? result['songs'];
      if (videos is! List) return [];
      return videos
          .map((e) => _parseSong(e))
          .whereType<Song>()
          .toList();
    } catch (e) {
      throw ProviderException('Catalog playlist tracks failed: $e');
    }
  }

  // ---- Trending / Home ----
  @override
  Future<List<Song>> trending({int limit = 20}) async {
    await _ensureInit();
    try {
      final sections = await _yt.getHomeSections();
      if (sections is! List) return [];
      final songs = <Song>[];
      for (final section in sections) {
        if (section is! Map) continue;
        final contents = section['contents'];
        if (contents is! List) continue;
        for (final item in contents) {
          final s = _parseSong(item);
          if (s != null) songs.add(s);
          if (songs.length >= limit) break;
        }
        if (songs.length >= limit) break;
      }
      return songs;
    } catch (e) {
      return [];
    }
  }

  // ---- Extended catalog methods (not in MusicProvider contract) ----

  /// Search suggestions for the query string.
  Future<List<String>> getSearchSuggestions(String query) async {
    if (query.trim().isEmpty) return [];
    await _ensureInit();
    try {
      final results = await _yt.getSearchSuggestions(query);
      if (results is List) {
        return results.whereType<String>().toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  /// Detailed song info including lyrics link.
  Future<Map<String, dynamic>?> getSongDetail(String videoId) async {
    await _ensureInit();
    try {
      final result = await _yt.getSong(videoId);
      if (result is Map) return result;
      return null;
    } catch (e) {
      return null;
    }
  }

  /// Plain lyrics lines.
  Future<List<String>?> getLyrics(String videoId) async {
    await _ensureInit();
    try {
      final result = await _yt.getLyrics(videoId);
      if (result is List) return result.whereType<String>().toList();
      return null;
    } catch (e) {
      return null;
    }
  }

  /// Timed lyrics [{time, text}].
  Future<List<Map<String, dynamic>>?> getTimedLyrics(String videoId) async {
    await _ensureInit();
    try {
      final result = await _yt.getTimedLyrics(videoId);
      if (result is List) {
        return result.whereType<Map<String, dynamic>>().toList();
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  /// Up-next recommendations for a video.
  Future<List<Song>> getUpNexts(String videoId) async {
    await _ensureInit();
    try {
      final results = await _yt.getUpNexts(videoId);
      if (results is! List) return [];
      return results
          .map((e) => _parseSong(e))
          .whereType<Song>()
          .toList();
    } catch (e) {
      return [];
    }
  }

  /// Home sections (mixed content).
  Future<List<Map<String, dynamic>>> getHomeSections() async {
    await _ensureInit();
    try {
      final results = await _yt.getHomeSections();
      if (results is List) {
        return results.whereType<Map<String, dynamic>>().toList();
      }
      return [];
    } catch (e) {
      return [];
    }
  }

  /// Artist albums.
  Future<List<OnlineAlbum>> getArtistAlbums(String artistId) async {
    await _ensureInit();
    try {
      final results = await _yt.getArtistAlbums(artistId);
      if (results is! List) return [];
      return results
          .map((e) {
            if (e is! Map) return null;
            final id = e['albumId']?.toString();
            if (id == null || id.isEmpty) return null;
            return OnlineAlbum(
              provider: id,
              id: id,
              name: (e['name'] as String?) ?? 'Unknown Album',
              artist: _firstArtist(e),
              imageUrl: _highResThumb(e['thumbnails']) ?? _bestThumb(e['thumbnails']),
            );
          })
          .whereType<OnlineAlbum>()
          .toList();
    } catch (e) {
      return [];
    }
  }

  /// Artist singles.
  Future<List<OnlineAlbum>> getArtistSingles(String artistId) async {
    await _ensureInit();
    try {
      final results = await _yt.getArtistSingles(artistId);
      if (results is! List) return [];
      return results
          .map((e) {
            if (e is! Map) return null;
            final id = e['albumId']?.toString();
            if (id == null || id.isEmpty) return null;
            return OnlineAlbum(
              provider: id,
              id: id,
              name: (e['name'] as String?) ?? 'Unknown Single',
              artist: _firstArtist(e),
              imageUrl: _highResThumb(e['thumbnails']) ?? _bestThumb(e['thumbnails']),
            );
          })
          .whereType<OnlineAlbum>()
          .toList();
    } catch (e) {
      return [];
    }
  }

  /// Build a share link for an item.
  static String shareUrl(String videoId) => 'https://music.youtube.com/watch?v=$videoId';
}
