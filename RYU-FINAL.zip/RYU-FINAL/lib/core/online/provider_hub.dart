import 'audius_provider.dart';
import 'jamendo_provider.dart';
import 'music_provider.dart';

/// Registry of all providers. Add new providers to [all].
class ProviderHub {
  ProviderHub._();
  static final ProviderHub instance = ProviderHub._();

  final List<MusicProvider> all = [AudiusProvider(), JamendoProvider()];

  List<MusicProvider> get available => all.where((p) => p.isAvailable).toList();

  MusicProvider? byId(String id) {
    for (final p in all) {
      if (p.id == id) return p;
    }
    return null;
  }
}
