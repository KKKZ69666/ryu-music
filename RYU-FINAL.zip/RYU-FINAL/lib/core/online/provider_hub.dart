import 'music_provider.dart';
import 'ytmusic_provider.dart';

/// Registry of online catalog providers.
class ProviderHub {
  ProviderHub._();
  static final ProviderHub instance = ProviderHub._();

  final List<MusicProvider> all = [YTMusicProvider()];

  List<MusicProvider> get available => all.where((p) => p.isAvailable).toList();

  MusicProvider? byId(String id) {
    for (final p in all) {
      if (p.id == id) return p;
    }
    return null;
  }

  YTMusicProvider? get catalog {
    for (final p in all) {
      if (p is YTMusicProvider) return p;
    }
    return null;
  }
}
