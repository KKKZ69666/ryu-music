import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/song.dart';
import '../online/provider_hub.dart';
import '../online/ytmusic_provider.dart';

class LyricLine {
  final int timeMs;
  final String text;
  const LyricLine(this.timeMs, this.text);
  factory LyricLine.fromJson(Map<String, dynamic> j) =>
      LyricLine((j['time'] as num?)?.toInt() ?? 0, (j['text'] ?? '').toString());
  Map<String, dynamic> toJson() => {'time': timeMs, 'text': text};
}

/// Fetches lyrics from multiple sources: local cache, YTMusic (catalog), and lrclib.net.
class LyricsService {
  static const _cacheKeyPrefix = 'lyrics_cache_';

  String _cacheKey(Song s) => '${_cacheKeyPrefix}${s.uri.hashCode}';

  /// Try YTMusic first if the song is catalog-only, then fall back to lrclib.
  Future<List<String>?> fetchLyrics(Song song) async {
    // 1. Try YTMusic catalog lyrics if the song has a remoteId
    if (song.remoteId != null && song.remoteId!.isNotEmpty) {
      final catalog = ProviderHub.instance.catalog;
      if (catalog != null) {
        try {
          final lines = await catalog.getLyrics(song.remoteId!);
          if (lines != null && lines.isNotEmpty) return lines;
        } catch (_) {
          // Fall through to lrclib
        }
      }
    }

    // 2. lrclib.net (open-source lyric DB)
    try {
      final r = await http.get(
        Uri.parse(
          'https://lrclib.net/api/search?q=${Uri.encodeComponent(song.title)}+${Uri.encodeComponent(song.artist)}',
        ),
      );
      if (r.statusCode == 200) {
        final j = jsonDecode(r.body);
        if (j is List && j.isNotEmpty) {
          final plain = (j.first['plainLyrics'] ?? '').toString();
          if (plain.isNotEmpty) return plain.split('\n');
        }
      }
    } catch (_) {}
    return null;
  }

  /// Fetch timed lyrics. YTMusic preferred if available.
  Future<List<LyricLine>> fetchTimed(Song song) async {
    // 1. Try YTMusic timed lyrics
    if (song.remoteId != null && song.remoteId!.isNotEmpty) {
      final catalog = ProviderHub.instance.catalog;
      if (catalog != null) {
        try {
          final raw = await catalog.getTimedLyrics(song.remoteId!);
          if (raw != null && raw.isNotEmpty) {
            return raw.map((e) {
              final time = (e['time'] as num?)?.toInt() ??
                  ((e['timestamp'] as num?)?.toInt() ?? 0);
              final text = (e['text'] ?? e['line'] ?? '').toString();
              return LyricLine(time, text);
            }).toList();
          }
        } catch (_) {
          // Fall through
        }
      }
    }

    // 2. lrclib.net synced lyrics
    try {
      final r = await http.get(
        Uri.parse(
          'https://lrclib.net/api/search?q=${Uri.encodeComponent(song.title)}+${Uri.encodeComponent(song.artist)}',
        ),
      );
      if (r.statusCode == 200) {
        final j = jsonDecode(r.body);
        if (j is List && j.isNotEmpty) {
          final lrc = (j.first['syncedLyrics'] ?? '').toString();
          if (lrc.isNotEmpty) return _parseLrc(lrc);
        }
      }
    } catch (_) {}
    return [];
  }

  static List<LyricLine> _parseLrc(String lrc) {
    final lines = <LyricLine>[];
    for (final line in lrc.split('\n')) {
      final m = RegExp(r'\[(\d+):(\d+\.?\d*)\](.*)').firstMatch(line);
      if (m != null) {
        final min = int.tryParse(m.group(1)!) ?? 0;
        final sec = double.tryParse(m.group(2)!) ?? 0;
        final text = m.group(3)!.trim();
        lines.add(LyricLine((min * 60 * 1000 + (sec * 1000).toInt()), text));
      }
    }
    return lines;
  }
}
