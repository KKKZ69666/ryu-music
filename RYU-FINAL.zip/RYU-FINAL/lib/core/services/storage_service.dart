import '../utils/uri_utils.dart';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as p;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import '../models/song.dart';
import '../models/history_entry.dart';
import '../models/playlist.dart';

class StorageService {
  StorageService._();
  static final StorageService instance = StorageService._();

  static const _kFavorites = 'ryu_favorites_v1';
  static const _kPlaylists = 'ryu_playlists_v1';
  static const _kHistory = 'ryu_history_v1';
  static const _kPlayCounts = 'ryu_play_counts_v1';
  static const _kShuffle = 'ryu_shuffle_v1';
  static const _kRepeat = 'ryu_repeat_v1';
  static const _kRecentSearches = 'ryu_recent_searches_v1';
  static const _kLyricsPrefix = 'ryu_lyrics_song_';

  late SharedPreferences _prefs;
  bool _initialized = false;

  Database? _db;
  bool _cachesReady = false;
  bool get dbAvailable => _db != null;

  // In-memory caches (loaded from SQLite once at startup) so the existing
  // synchronous API keeps working.
  Set<int> _favC = {};
  List<RyuPlaylist> _plC = [];
  List<HistoryEntry> _hisC = [];
  Map<int, int> _pcC = {};
  List<String> _rsC = [];
  final Map<int, Map<String, String>> _lyC = {};

  static const _schemaVersion = 2;

  Database? get db => _db;

  Future<void> init() async {
    if (_initialized) return;
    _prefs = await SharedPreferences.getInstance();
    try {
      final dir = await getDatabasesPath();
      _db = await openDatabase(
        p.join(dir, 'ryu_music.db'),
        version: _schemaVersion,
        onCreate: _createSchema,
        onUpgrade: _upgradeSchema,
      );
      await _migrateFromPrefs();
      await _loadCaches();
      _cachesReady = true;
    } catch (e) {
      // Recovery: never crash the app because SQLite failed. Fall back to the
      // legacy SharedPreferences data (left untouched by the migration).
      debugPrint('RYU: SQLite unavailable, using SharedPreferences: $e');
      try {
        await _db?.close();
      } catch (_) {}
      _db = null;
      _loadLegacyIntoCaches();
      _cachesReady = true;
    }
    _initialized = true;
  }

  Future<void> _createSchema(Database db, int version) async {
    final b = db.batch();
    b.execute('CREATE TABLE meta(key TEXT PRIMARY KEY, value TEXT)');
    b.execute('CREATE TABLE settings(key TEXT PRIMARY KEY, value TEXT)');
    b.execute('''CREATE TABLE tracks(
      id INTEGER PRIMARY KEY, key TEXT UNIQUE NOT NULL, provider TEXT NOT NULL,
      remote_id TEXT, title TEXT, artist TEXT, album TEXT, duration_ms INTEGER,
      uri TEXT, file_path TEXT, artwork_url TEXT, saved_at INTEGER,
      download_url TEXT, in_library INTEGER NOT NULL DEFAULT 0)''');
    b.execute(
        'CREATE TABLE favorites(song_id INTEGER PRIMARY KEY, added_at INTEGER)');
    b.execute('''CREATE TABLE playlists(
      id TEXT PRIMARY KEY, name TEXT, description TEXT,
      created_at TEXT, updated_at TEXT, position INTEGER)''');
    b.execute('''CREATE TABLE playlist_items(
      playlist_id TEXT NOT NULL, position INTEGER NOT NULL, song_id INTEGER NOT NULL,
      PRIMARY KEY(playlist_id, position))''');
    b.execute('''CREATE TABLE history(
      id INTEGER PRIMARY KEY AUTOINCREMENT, song_id INTEGER NOT NULL,
      played_at TEXT NOT NULL)''');
    b.execute(
        'CREATE TABLE play_counts(song_id INTEGER PRIMARY KEY, count INTEGER)');
    b.execute('''CREATE TABLE lyrics(
      song_id INTEGER PRIMARY KEY, raw_text TEXT, source TEXT, updated_at INTEGER)''');
    b.execute(
        'CREATE TABLE recent_searches(query TEXT PRIMARY KEY, ts INTEGER)');
    _extraTables(b);
    await b.commit(noResult: true);
  }

  void _extraTables(Batch b) {
    b.execute('''CREATE TABLE IF NOT EXISTS downloads(
      song_id INTEGER PRIMARY KEY, status TEXT NOT NULL, path TEXT,
      received INTEGER NOT NULL DEFAULT 0, total INTEGER NOT NULL DEFAULT 0,
      error TEXT, updated_at INTEGER)''');
    b.execute('''CREATE TABLE IF NOT EXISTS listen_events(
      id INTEGER PRIMARY KEY AUTOINCREMENT, song_id INTEGER NOT NULL,
      started_at INTEGER NOT NULL, listened_ms INTEGER NOT NULL)''');
    b.execute(
        'CREATE INDEX IF NOT EXISTS idx_listen_started ON listen_events(started_at)');
  }

  Future<void> _upgradeSchema(Database db, int from, int to) async {
    if (from < 2) {
      final b = db.batch();
      b.execute('ALTER TABLE tracks ADD COLUMN download_url TEXT');
      b.execute(
          'ALTER TABLE tracks ADD COLUMN in_library INTEGER NOT NULL DEFAULT 0');
      _extraTables(b);
      await b.commit(noResult: true);
    }
  }

  /// One-time, non-destructive copy of SharedPreferences data into SQLite.
  /// Legacy keys are kept so a rollback to the old build still has its data.
  Future<void> _migrateFromPrefs() async {
    final db = _db!;
    final done = await db
        .query('meta', where: 'key = ?', whereArgs: ['prefs_migrated_v1']);
    if (done.isNotEmpty) return;
    final fav = loadFavorites();
    final pls = loadPlaylists();
    final his = loadHistory();
    final pcs = loadPlayCounts();
    final rs = loadRecentSearches();
    final lyr = <int, Map<String, String>>{};
    for (final k in _prefs.getKeys()) {
      if (k.startsWith(_kLyricsPrefix)) {
        final id = int.tryParse(k.substring(_kLyricsPrefix.length));
        final v = id == null ? null : loadSongLyrics(id);
        if (id != null && v != null) lyr[id] = v;
      }
    }
    await db.transaction((txn) async {
      final now = DateTime.now().millisecondsSinceEpoch;
      for (final id in fav) {
        await txn.insert('favorites', {'song_id': id, 'added_at': now},
            conflictAlgorithm: ConflictAlgorithm.ignore);
      }
      await _writePlaylists(txn, pls);
      await _writeHistory(txn, his);
      for (final e in pcs.entries) {
        await txn.insert('play_counts', {'song_id': e.key, 'count': e.value},
            conflictAlgorithm: ConflictAlgorithm.replace);
      }
      for (var i = 0; i < rs.length; i++) {
        await txn.insert('recent_searches', {'query': rs[i], 'ts': now - i},
            conflictAlgorithm: ConflictAlgorithm.replace);
      }
      for (final e in lyr.entries) {
        await txn.insert(
            'lyrics',
            {
              'song_id': e.key,
              'raw_text': e.value['rawText'],
              'source': e.value['source'],
              'updated_at': now,
            },
            conflictAlgorithm: ConflictAlgorithm.replace);
      }
      final sh = _prefs.getBool(_kShuffle);
      final rp = _prefs.getInt(_kRepeat);
      if (sh != null) await _putSetting(txn, 'shuffle', sh ? '1' : '0');
      if (rp != null) await _putSetting(txn, 'repeat', '$rp');
      await txn.insert('meta', {'key': 'prefs_migrated_v1', 'value': '1'});
    });
  }

  void _loadLegacyIntoCaches() {
    _favC = _legacyFavorites();
    _plC = _legacyPlaylists();
    _hisC = _legacyHistory();
    _pcC = _legacyPlayCounts();
    _rsC = _prefs.getStringList(_kRecentSearches) ?? [];
  }

  Future<void> _loadCaches() async {
    final db = _db!;
    _favC = (await db.query('favorites', orderBy: 'added_at'))
        .map((r) => (r['song_id'] as num).toInt())
        .toSet();
    final plRows = await db.query('playlists', orderBy: 'position');
    final items = await db.query('playlist_items', orderBy: 'position');
    final byPl = <String, List<int>>{};
    for (final r in items) {
      byPl
          .putIfAbsent(r['playlist_id'] as String, () => [])
          .add((r['song_id'] as num).toInt());
    }
    _plC = plRows
        .map((r) => RyuPlaylist(
              id: r['id'] as String,
              name: (r['name'] as String?) ?? 'Untitled Playlist',
              description: (r['description'] as String?) ?? '',
              songIds: byPl[r['id']] ?? <int>[],
              createdAt: DateTime.tryParse(r['created_at'] as String? ?? '') ??
                  DateTime.now(),
              updatedAt: DateTime.tryParse(r['updated_at'] as String? ?? '') ??
                  DateTime.now(),
            ))
        .toList();
    _hisC = (await db.query('history', orderBy: 'id DESC', limit: 200))
        .map((r) => HistoryEntry(
              songId: (r['song_id'] as num).toInt(),
              playedAt: DateTime.tryParse(r['played_at'] as String? ?? '') ??
                  DateTime.now(),
            ))
        .toList();
    _pcC = {
      for (final r in await db.query('play_counts'))
        (r['song_id'] as num).toInt(): (r['count'] as num).toInt()
    };
    for (final r in await db.query('settings')) {
      _settingC[r['key'] as String] = (r['value'] as String?) ?? '';
    }
    _rsC = (await db.query('recent_searches', orderBy: 'ts DESC', limit: 12))
        .map((r) => r['query'] as String)
        .toList();
  }

  Future<void> _putSetting(DatabaseExecutor ex, String k, String v) =>
      ex.insert('settings', {'key': k, 'value': v},
          conflictAlgorithm: ConflictAlgorithm.replace);

  Future<void> _writePlaylists(
      DatabaseExecutor ex, List<RyuPlaylist> pls) async {
    await ex.delete('playlist_items');
    await ex.delete('playlists');
    for (var i = 0; i < pls.length; i++) {
      final pl = pls[i];
      await ex.insert('playlists', {
        'id': pl.id,
        'name': pl.name,
        'description': pl.description,
        'created_at': pl.createdAt.toIso8601String(),
        'updated_at': pl.updatedAt.toIso8601String(),
        'position': i,
      });
      for (var j = 0; j < pl.songIds.length; j++) {
        await ex.insert('playlist_items', {
          'playlist_id': pl.id,
          'position': j,
          'song_id': pl.songIds[j],
        });
      }
    }
  }

  Future<void> _writeHistory(DatabaseExecutor ex, List<HistoryEntry> es) async {
    await ex.delete('history');
    // Stored newest-first in memory; insert oldest-first so id order = time.
    for (final e in es.take(200).toList().reversed) {
      await ex.insert('history',
          {'song_id': e.songId, 'played_at': e.playedAt.toIso8601String()});
    }
  }

  // ---- Tracks (metadata for local + online songs) ----
  Future<void> upsertTracks(List<Song> songs, {bool? inLibrary}) async {
    final db = _db;
    if (db == null || songs.isEmpty) return;
    try {
      final b = db.batch();
      final now = DateTime.now().millisecondsSinceEpoch;
      for (final s in songs) {
        b.insert(
            'tracks',
            {
              'download_url': s.downloadUrl,
              if (inLibrary != null) 'in_library': inLibrary ? 1 : 0,
              'id': s.id,
              'key': s.key,
              'provider': s.provider,
              'remote_id': s.remoteId,
              'title': s.title,
              'artist': s.artist,
              'album': s.album,
              'duration_ms': s.durationMs,
              'uri': s.uri,
              'file_path': s.filePath,
              'artwork_url': s.artworkUrl,
              'saved_at': now,
            },
            conflictAlgorithm: ConflictAlgorithm.replace);
        if (inLibrary == null) {
          // REPLACE reset in_library; restore previous flag for known rows.
          b.rawUpdate(
              'UPDATE tracks SET in_library = ? WHERE id = ?',
              [_libFlags[s.id] == true ? 1 : 0, s.id]);
        } else {
          _libFlags[s.id] = inLibrary;
        }
      }
      await b.commit(noResult: true);
    } catch (e) {
      debugPrint('RYU: upsertTracks failed: $e');
    }
  }

  final Map<int, bool> _libFlags = {};

  /// Online tracks previously seen. `.$2` = saved in library.
  Future<List<(Song, bool)>> loadOnlineTracks() async {
    final db = _db;
    if (db == null) return [];
    final rows = await db.query('tracks', where: "provider != 'local'");
    return rows.map((r) {
      final saved = ((r['in_library'] as num?)?.toInt() ?? 0) == 1;
      _libFlags[(r['id'] as num).toInt()] = saved;
      final song = Song(
              id: (r['id'] as num).toInt(),
              title: (r['title'] as String?) ?? 'Unknown Title',
              artist: (r['artist'] as String?) ?? 'Unknown Artist',
              album: (r['album'] as String?) ?? '',
              albumId: -1,
              durationMs: (r['duration_ms'] as num?)?.toInt() ?? 0,
              uri: UriUtils.preferHttps((r['uri'] as String?) ?? ''),
              provider: r['provider'] as String,
              remoteId: r['remote_id'] as String?,
              artworkUrl: UriUtils.preferHttpsNullable(r['artwork_url'] as String?),
              downloadUrl: UriUtils.preferHttpsNullable(r['download_url'] as String?),
              dateAdded: ((r['saved_at'] as num?)?.toInt() ?? 0) ~/ 1000,
            );
      if (song.artworkUrl != null && song.artworkUrl!.isNotEmpty) {
        Song.onlineArtwork[song.id] = song.artworkUrl!;
      }
      return (song, saved);
    }).toList();
  }

  Future<void> _guard(Future<void> Function(Database db) fn) async {
    final db = _db;
    if (db == null) return;
    try {
      await fn(db);
    } catch (e) {
      debugPrint('RYU: DB write failed: $e');
    }
  }

  // Favorites
  Set<int> _legacyFavorites() {
    final raw = _prefs.getStringList(_kFavorites) ?? const <String>[];
    return raw.map(int.tryParse).whereType<int>().where((id) => id != 0).toSet();
  }

  Set<int> loadFavorites() => !_cachesReady ? _legacyFavorites() : {..._favC};
  List<RyuPlaylist> loadPlaylists() => !_cachesReady ? _legacyPlaylists() : [..._plC];
  List<HistoryEntry> loadHistory() => !_cachesReady ? _legacyHistory() : [..._hisC];
  Map<int, int> loadPlayCounts() => !_cachesReady ? _legacyPlayCounts() : {..._pcC};

  Future<void> saveFavorites(Set<int> ids) async {
    _favC = {...ids};
    if (_db == null) {
      await _prefs.setStringList(
          _kFavorites, ids.map((e) => e.toString()).toList());
      return;
    }
    await _guard((db) async {
      await db.transaction((txn) async {
        await txn.delete('favorites');
        final now = DateTime.now().millisecondsSinceEpoch;
        for (final id in ids) {
          await txn.insert('favorites', {'song_id': id, 'added_at': now});
        }
      });
    });
  }

  // Playlists
  List<RyuPlaylist> _legacyPlaylists() {
    final raw = _prefs.getString(_kPlaylists);
    if (raw == null || raw.isEmpty) return [];
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      return decoded
          .map((e) => RyuPlaylist.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> savePlaylists(List<RyuPlaylist> playlists) async {
    _plC = [...playlists];
    if (_db == null) {
      await _prefs.setString(
          _kPlaylists, jsonEncode(playlists.map((e) => e.toJson()).toList()));
      return;
    }
    await _guard((db) => db.transaction((txn) => _writePlaylists(txn, playlists)));
  }

  // Listening History
  List<HistoryEntry> _legacyHistory() {
    final raw = _prefs.getString(_kHistory);
    if (raw == null || raw.isEmpty) return [];
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      return decoded
          .map((e) => HistoryEntry.fromJson(e as Map<String, dynamic>))
          .toList();
    } catch (_) {
      return [];
    }
  }

  Future<void> saveHistory(List<HistoryEntry> entries) async {
    final capped = entries.take(200).toList();
    _hisC = capped;
    if (_db == null) {
      await _prefs.setString(
          _kHistory, jsonEncode(capped.map((e) => e.toJson()).toList()));
      return;
    }
    await _guard((db) => db.transaction((txn) => _writeHistory(txn, capped)));
  }

  // Play Counts
  Map<int, int> _legacyPlayCounts() {
    final raw = _prefs.getString(_kPlayCounts);
    if (raw == null || raw.isEmpty) return {};
    try {
      final decoded = jsonDecode(raw) as Map<String, dynamic>;
      final map = <int, int>{};
      decoded.forEach((key, value) {
        final id = int.tryParse(key);
        if (id != null && value is num) {
          map[id] = value.toInt();
        }
      });
      return map;
    } catch (_) {
      return {};
    }
  }

  Future<void> savePlayCounts(Map<int, int> counts) async {
    _pcC = {...counts};
    if (_db == null) {
      await _prefs.setString(_kPlayCounts,
          jsonEncode(counts.map((k, v) => MapEntry(k.toString(), v))));
      return;
    }
    await _guard((db) => db.transaction((txn) async {
          await txn.delete('play_counts');
          for (final e in counts.entries) {
            await txn.insert(
                'play_counts', {'song_id': e.key, 'count': e.value});
          }
        }));
  }

  // Playback Modes
  bool loadShuffle() => (_settingC['shuffle'] ?? (_prefs.getBool(_kShuffle) == true ? '1' : '0')) == '1';
  Future<void> saveShuffle(bool value) async {
    await _prefs.setBool(_kShuffle, value);
    await setSetting('shuffle', value ? '1' : '0');
  }

  int loadRepeatModeIndex() =>
      int.tryParse(_settingC['repeat'] ?? '') ?? _prefs.getInt(_kRepeat) ?? 0;
  Future<void> saveRepeatModeIndex(int index) async {
    await _prefs.setInt(_kRepeat, index);
    await setSetting('repeat', '$index');
  }

  // Generic key/value settings (SQLite-backed, mirrored in memory).
  final Map<String, String> _settingC = {};
  String? getSetting(String key) => _settingC[key];
  Future<void> setSetting(String key, String value) async {
    _settingC[key] = value;
    await _guard((db) => _putSetting(db, key, value));
  }

  // Recent Searches
  List<String> loadRecentSearches() =>
      !_cachesReady
          ? (_prefs.getStringList(_kRecentSearches) ?? const [])
          : [..._rsC];

  Future<void> saveRecentSearches(List<String> queries) async {
    final q = queries.take(12).toList();
    _rsC = q;
    if (_db == null) {
      await _prefs.setStringList(_kRecentSearches, q);
      return;
    }
    await _guard((db) => db.transaction((txn) async {
          await txn.delete('recent_searches');
          final now = DateTime.now().millisecondsSinceEpoch;
          for (var i = 0; i < q.length; i++) {
            await txn.insert('recent_searches', {'query': q[i], 'ts': now - i});
          }
        }));
  }

  // Cached / user lyrics per song id (SQLite, prefs fallback)
  Map<String, String>? loadSongLyrics(int songId) {
    final c = _lyC[songId];
    if (c != null) return c;
    return _legacyLyrics(songId);
  }

  Map<String, String>? _legacyLyrics(int songId) {
    final raw = _prefs.getString('$_kLyricsPrefix$songId');
    if (raw == null || raw.isEmpty) return null;
    try {
      final d = jsonDecode(raw) as Map<String, dynamic>;
      return {
        'rawText': d['rawText'] as String? ?? '',
        'source': d['source'] as String? ?? 'manualInput',
      };
    } catch (_) {
      return null;
    }
  }

  /// Async lookup that hits SQLite first (use before the sync cache is warm).
  Future<Map<String, String>?> fetchSongLyrics(int songId) async {
    final c = _lyC[songId];
    if (c != null) return c;
    final db = _db;
    if (db != null) {
      try {
        final r = await db
            .query('lyrics', where: 'song_id = ?', whereArgs: [songId]);
        if (r.isNotEmpty) {
          final m = {
            'rawText': (r.first['raw_text'] as String?) ?? '',
            'source': (r.first['source'] as String?) ?? 'manualInput',
          };
          _lyC[songId] = m;
          return m;
        }
      } catch (e) {
        debugPrint('RYU: lyrics read failed: $e');
      }
    }
    return _legacyLyrics(songId);
  }

  Future<void> saveSongLyrics({
    required int songId,
    required String rawText,
    required String sourceName,
  }) async {
    _lyC[songId] = {'rawText': rawText, 'source': sourceName};
    if (_db == null) {
      await _prefs.setString('$_kLyricsPrefix$songId',
          jsonEncode({'rawText': rawText, 'source': sourceName}));
      return;
    }
    await _guard((db) => db.insert(
        'lyrics',
        {
          'song_id': songId,
          'raw_text': rawText,
          'source': sourceName,
          'updated_at': DateTime.now().millisecondsSinceEpoch,
        },
        conflictAlgorithm: ConflictAlgorithm.replace));
  }

  Future<void> clearSongLyrics(int songId) async {
    _lyC.remove(songId);
    await _prefs.remove('$_kLyricsPrefix$songId');
    await _guard((db) => db.delete('lyrics', where: 'song_id = ?', whereArgs: [songId]));
  }
}
