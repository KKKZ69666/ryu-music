import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/models/song.dart';
import '../../core/online/online_models.dart';
import '../../core/online/provider_hub.dart';
import '../../core/online/ytmusic_provider.dart';
import '../../core/ryu_scope.dart';
import '../../core/theme/ryu_colors.dart';
import '../../core/utils/duration_formatter.dart';
import '../../shared/widgets/song_tile.dart';
import '../online/online_detail_screen.dart';
import '../online/online_search_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  bool _loadingHome = true;
  bool _loadingRecents = true;
  final List<_HomeSection> _homeSections = [];

  @override
  void initState() {
    super.initState();
    _loadHomeSections();
  }

  Future<void> _loadHomeSections() async {
    final catalog = ProviderHub.instance.catalog;
    if (catalog == null) {
      setState(() => _loadingHome = false);
      return;
    }
    try {
      final sections = await catalog.getHomeSections();
      if (!mounted) return;
      final parsed = <_HomeSection>[];
      for (final sec in sections) {
        final title = (sec['title'] ?? 'Section').toString();
        final contents = sec['contents'];
        if (contents is! List || contents.isEmpty) continue;
        final items = <_HomeItem>[];
        for (final item in contents) {
          if (item is! Map) continue;
          final videoId = item['videoId']?.toString();
          final artistId = item['artistId']?.toString();
          final albumId = item['albumId']?.toString();
          final playlistId = item['playlistId']?.toString();
          final name = (item['name'] ?? '').toString();
          final titleItem = (item['title'] ?? '').toString();
          final displayName = name.isNotEmpty ? name : (titleItem.isNotEmpty ? titleItem : 'Unknown');
          final artist = _firstArtist(item);
          final thumbs = item['thumbnails'];
          String? imageUrl;
          if (thumbs is List && thumbs.isNotEmpty) {
            final best = thumbs.last;
            if (best is Map) imageUrl = best['url']?.toString();
          }
          _HomeItemType type = _HomeItemType.song;
          String? id;
          if (videoId != null && videoId.isNotEmpty) {
            type = _HomeItemType.song;
            id = videoId;
          } else if (artistId != null && artistId.isNotEmpty) {
            type = _HomeItemType.artist;
            id = artistId;
          } else if (albumId != null && albumId.isNotEmpty) {
            type = _HomeItemType.album;
            id = albumId;
          } else if (playlistId != null && playlistId.isNotEmpty) {
            type = _HomeItemType.playlist;
            id = playlistId;
          }
          if (id != null) {
            items.add(_HomeItem(
              type: type,
              id: id,
              title: displayName,
              subtitle: artist,
              imageUrl: imageUrl,
              raw: item,
            ));
          }
        }
        if (items.isNotEmpty) {
          parsed.add(_HomeSection(title: title, items: items));
        }
      }
      setState(() {
        _homeSections.addAll(parsed);
        _loadingHome = false;
      });
    } catch (e) {
      if (mounted) setState(() => _loadingHome = false);
    }
  }

  String _firstArtist(dynamic item) {
    if (item is! Map) return '';
    final artists = item['artists'];
    if (artists is List && artists.isNotEmpty) {
      final first = artists.first;
      if (first is Map) return (first['name'] as String?) ?? '';
    }
    return (item['artist'] as String?) ?? '';
  }

  void _onHomeItemTap(BuildContext context, _HomeItem item) {
    final catalog = ProviderHub.instance.catalog;
    switch (item.type) {
      case _HomeItemType.song:
        if (catalog != null && item.id.isNotEmpty) {
          _showCatalogPreview(context, item);
        }
      case _HomeItemType.artist:
        Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => OnlineDetailScreen.artist(OnlineArtist(
            provider: 'ytmusic',
            id: item.id,
            name: item.title,
            imageUrl: item.imageUrl,
          )),
        ));
      case _HomeItemType.album:
        Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => OnlineDetailScreen.album(OnlineAlbum(
            provider: 'ytmusic',
            id: item.id,
            name: item.title,
            artist: item.subtitle,
            imageUrl: item.imageUrl,
          )),
        ));
      case _HomeItemType.playlist:
        Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => OnlineDetailScreen.playlist(OnlinePlaylist(
            provider: 'ytmusic',
            id: item.id,
            name: item.title,
            owner: item.subtitle,
            imageUrl: item.imageUrl,
          )),
        ));
    }
  }

  void _showCatalogPreview(BuildContext context, _HomeItem item) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: RyuColors.surfaceHigh,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 36,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.25),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                if (item.imageUrl != null)
                  Center(
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.network(
                        item.imageUrl!,
                        width: 160,
                        height: 160,
                        fit: BoxFit.cover,
                        errorBuilder: (context, error, stackTrace) =>
                            Container(
                              width: 160,
                              height: 160,
                              color: RyuColors.surface,
                              child: const Icon(Icons.music_note_rounded),
                            ),
                      ),
                    ),
                  ),
                const SizedBox(height: 16),
                Text(
                  item.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                Text(
                  item.subtitle.isNotEmpty ? item.subtitle : 'Catalog',
                  style: const TextStyle(color: RyuColors.textSecondary, fontSize: 14),
                ),
                const SizedBox(height: 16),
                const Text(
                  'This track is available in the catalog for discovery. '
                  'Audio playback is not provided directly.',
                  style: TextStyle(color: RyuColors.textSecondary, fontSize: 13),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () async {
                          Navigator.pop(ctx);
                          final url = Uri.parse(YTMusicProvider.shareUrl(item.id));
                          if (await canLaunchUrl(url)) {
                            await launchUrl(url, mode: LaunchMode.externalApplication);
                          }
                        },
                        icon: const Icon(Icons.open_in_new_rounded, size: 18),
                        label: const Text('Open in service'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text('Close'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scope = RyuScope.of(context);
    return SafeArea(
      bottom: false,
      child: ListenableBuilder(
        listenable: Listenable.merge([scope.library, scope.audio]),
        builder: (context, _) {
          final now = DateTime.now();
          String greeting;
          if (now.hour < 12) {
            greeting = 'Good morning';
          } else if (now.hour < 18) {
            greeting = 'Good afternoon';
          } else {
            greeting = 'Good evening';
          }

          final recents = scope.library.recentSongs
            .map(scope.library.songById)
            .where((s) => s != null)
            .cast<Song>()
            .toList();

          final mostPlayed = scope.library.mostPlayedSongs.toList();

          return CustomScrollView(
            slivers: [
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                  child: Text(
                    greeting,
                    style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900),
                  ),
                ),
              ),

              // Quick actions
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      ActionChip(
                        avatar: const Icon(Icons.shuffle_rounded, size: 16),
                        label: const Text('Shuffle all'),
                        onPressed: () {
                          final all = scope.library.allSongs.toList();
                          if (all.isNotEmpty) {
                            scope.audio.playSongs(all, forceShuffle: true, contextLabel: 'All songs');
                          }
                        },
                      ),
                      ActionChip(
                        avatar: const Icon(Icons.favorite_rounded, size: 16),
                        label: const Text('Favorites'),
                        onPressed: () {
                          final favs = scope.library.favoriteSongs.toList();
                          if (favs.isNotEmpty) {
                            scope.audio.playSongs(favs, contextLabel: 'Favorites');
                          }
                        },
                      ),
                      if (recents.isNotEmpty)
                        ActionChip(
                          avatar: const Icon(Icons.history_rounded, size: 16),
                          label: const Text('Recently played'),
                          onPressed: () {
                            scope.audio.playSongs(recents, contextLabel: 'Recently played');
                          },
                        ),
                    ],
                  ),
                ),
              ),

              // Recently played
              if (recents.isNotEmpty) ...[
                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(20, 24, 20, 4),
                    child: Text('Recently played',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                  ),
                ),
                SliverList.builder(
                  itemCount: recents.take(8).length,
                  itemBuilder: (_, i) => SongTile(
                    song: recents[i],
                    onTap: () => scope.audio.playSongs(recents, initialIndex: i, contextLabel: 'Recently played'),
                    onMore: () => _showOptions(context, recents[i]),
                  ),
                ),
              ],

              // Most played
              if (mostPlayed.isNotEmpty) ...[
                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(20, 24, 20, 4),
                    child: Text('Your top picks',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
                  ),
                ),
                SliverList.builder(
                  itemCount: mostPlayed.take(8).length,
                  itemBuilder: (_, i) => SongTile(
                    song: mostPlayed[i],
                    onTap: () => scope.audio.playSongs(mostPlayed, initialIndex: i, contextLabel: 'Top picks'),
                    onMore: () => _showOptions(context, mostPlayed[i]),
                  ),
                ),
              ],

              // YTMusic Home Sections
              if (_loadingHome)
                const SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
                  ),
                )
              else
                for (final section in _homeSections) ...[
                  SliverToBoxAdapter(
                    child: Padding(
                      padding: const EdgeInsets.fromLTRB(20, 24, 20, 8),
                      child: Text(
                        section.title,
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                      ),
                    ),
                  ),
                  SliverToBoxAdapter(
                    child: SizedBox(
                      height: 200,
                      child: ListView.builder(
                        scrollDirection: Axis.horizontal,
                        padding: const EdgeInsets.symmetric(horizontal: 20),
                        itemCount: section.items.length,
                        itemBuilder: (_, i) {
                          final item = section.items[i];
                          return GestureDetector(
                            onTap: () => _onHomeItemTap(context, item),
                            child: Container(
                              width: 140,
                              margin: const EdgeInsets.only(right: 12),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(12),
                                    child: SizedBox(
                                      width: 140,
                                      height: 140,
                                      child: item.imageUrl == null
                                          ? Container(
                                              color: RyuColors.surfaceHigh,
                                              child: const Icon(Icons.music_note_rounded,
                                                  color: RyuColors.textSecondary),
                                            )
                                          : Image.network(
                                              item.imageUrl!,
                                              fit: BoxFit.cover,
                                              errorBuilder: (context, error, stackTrace) =>
                                                  Container(color: RyuColors.surfaceHigh),
                                            ),
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    item.title,
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        fontWeight: FontWeight.w600, fontSize: 12.5),
                                  ),
                                  Text(
                                    item.subtitle.isNotEmpty ? item.subtitle : 'Catalog',
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(
                                        color: RyuColors.textSecondary, fontSize: 11),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ),
                ],

              const SliverToBoxAdapter(child: SizedBox(height: 180)),
            ],
          );
        },
      ),
    );
  }

  void _showOptions(BuildContext context, Song song) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (_) => SafeArea(
        child: Container(
          margin: const EdgeInsets.all(16),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: RyuColors.surfaceHigh,
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            ListTile(
              leading: const Icon(Icons.favorite_rounded, color: RyuColors.textSecondary),
              title: const Text('Add to favorites'),
              onTap: () {
                RyuScope.of(context).library.toggleFavorite(song);
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.queue_music_rounded, color: RyuColors.textSecondary),
              title: const Text('Add to queue'),
              onTap: () {
                RyuScope.of(context).audio.addToQueue(song);
                Navigator.pop(context);
              },
            ),
          ]),
        ),
      ),
    );
  }
}

enum _HomeItemType { song, artist, album, playlist }

class _HomeItem {
  final _HomeItemType type;
  final String id;
  final String title;
  final String subtitle;
  final String? imageUrl;
  final Map<String, dynamic> raw;

  _HomeItem({
    required this.type,
    required this.id,
    required this.title,
    required this.subtitle,
    this.imageUrl,
    required this.raw,
  });
}

class _HomeSection {
  final String title;
  final List<_HomeItem> items;
  _HomeSection({required this.title, required this.items});
}
