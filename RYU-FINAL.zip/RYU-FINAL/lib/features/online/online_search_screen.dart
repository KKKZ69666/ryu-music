import '../../core/utils/uri_utils.dart';
import 'package:flutter/material.dart';
import '../../core/models/song.dart';
import '../../core/online/online_models.dart';
import '../../core/online/online_search_controller.dart';
import '../../core/ryu_scope.dart';
import '../../core/theme/ryu_colors.dart';
import '../../shared/widgets/online_song_tile.dart';
import 'online_detail_screen.dart';

class OnlineSearchScreen extends StatefulWidget {
  const OnlineSearchScreen({super.key});

  @override
  State<OnlineSearchScreen> createState() => _OnlineSearchScreenState();
}

class _OnlineSearchScreenState extends State<OnlineSearchScreen> {
  final _ctl = OnlineSearchController();
  final _text = TextEditingController();
  final _scroll = ScrollController();

  @override
  void initState() {
    super.initState();
    _scroll.addListener(() {
      if (_scroll.position.pixels > _scroll.position.maxScrollExtent - 400) {
        _ctl.loadMore();
      }
    });
    _ctl.loadTrending();
  }

  @override
  void dispose() {
    _ctl.dispose();
    _text.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _run(String q) {
    _text.text = q;
    _text.selection = TextSelection.collapsed(offset: q.length);
    _ctl.setQuery(q);
    _ctl.submit();
    RyuScope.of(context).library.addRecentSearch(q);
  }

  @override
  Widget build(BuildContext context) {
    final scope = RyuScope.of(context);
    return SafeArea(
      bottom: false,
      child: ListenableBuilder(
        listenable: Listenable.merge([_ctl, scope.library]),
        builder: (context, _) {
          final hasQuery = _ctl.query.isNotEmpty;
          return CustomScrollView(
            controller: _scroll,
            slivers: [
              SliverToBoxAdapter(child: _header(context)),
              if (!hasQuery) ..._discovery(context, scope) else ..._results(context, scope),
              const SliverToBoxAdapter(child: SizedBox(height: 180)),
            ],
          );
        },
      ),
    );
  }

  Widget _header(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Online',
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
        const SizedBox(height: 12),
        TextField(
          controller: _text,
          textInputAction: TextInputAction.search,
          onChanged: _ctl.setQuery,
          onSubmitted: (q) {
            _ctl.submit();
            if (q.trim().isNotEmpty) {
              RyuScope.of(context).library.addRecentSearch(q);
            }
          },
          decoration: InputDecoration(
            hintText: 'Search songs, artists, albums, playlists',
            prefixIcon: const Icon(Icons.search_rounded),
            suffixIcon: _text.text.isEmpty
                ? null
                : IconButton(
                    icon: const Icon(Icons.close_rounded),
                    onPressed: () {
                      _text.clear();
                      _ctl.setQuery('');
                      setState(() {});
                    },
                  ),
            filled: true,
            fillColor: RyuColors.surface,
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(18), borderSide: BorderSide.none),
          ),
        ),
        const SizedBox(height: 10),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: [
            for (final t in OnlineSearchType.values)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: ChoiceChip(
                  label: Text(t.name[0].toUpperCase() + t.name.substring(1)),
                  selected: _ctl.type == t,
                  onSelected: (_) => _ctl.setType(t),
                ),
              ),
          ]),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: [
            Padding(
              padding: const EdgeInsets.only(right: 8),
              child: FilterChip(
                label: const Text('All sources'),
                selected: _ctl.providerFilter == null,
                onSelected: (_) => _ctl.setProviderFilter(null),
              ),
            ),
            for (final p in _ctl.providers)
              Padding(
                padding: const EdgeInsets.only(right: 8),
                child: Tooltip(
                  message: p.unavailableReason ?? p.licenseNote,
                  child: FilterChip(
                    label: Text(p.displayName),
                    selected: _ctl.providerFilter == p.id,
                    onSelected: p.isAvailable ? (_) => _ctl.setProviderFilter(p.id) : null,
                  ),
                ),
              ),
            if (_ctl.type == OnlineSearchType.songs)
              PopupMenuButton<OnlineSort>(
                color: RyuColors.surfaceHigh,
                tooltip: 'Sort',
                icon: const Icon(Icons.sort_rounded),
                onSelected: _ctl.setSort,
                itemBuilder: (_) => [
                  for (final s in OnlineSort.values)
                    CheckedPopupMenuItem(
                        value: s, checked: _ctl.sort == s, child: Text(s.label)),
                ],
              ),
          ]),
        ),
        for (final p in _ctl.providers.where((p) => !p.isAvailable))
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text('${p.displayName}: ${p.unavailableReason}',
                style: const TextStyle(color: RyuColors.textSecondary, fontSize: 12)),
          ),
      ]),
    );
  }

  List<Widget> _discovery(BuildContext context, RyuScope scope) {
    final recents = scope.library.recentSearches;
    return [
      if (recents.isNotEmpty) ...[
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 8, 0),
            child: Row(children: [
              const Expanded(
                  child: Text('Recent searches',
                      style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800))),
              TextButton(
                  onPressed: scope.library.clearRecentSearches,
                  child: const Text('Clear')),
            ]),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Wrap(spacing: 8, children: [
              for (final q in recents.take(8))
                ActionChip(
                    avatar: const Icon(Icons.history_rounded, size: 16),
                    label: Text(q),
                    onPressed: () => _run(q)),
            ]),
          ),
        ),
      ],
      const SliverToBoxAdapter(
        child: Padding(
          padding: EdgeInsets.fromLTRB(20, 20, 20, 4),
          child: Text('Trending now',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800)),
        ),
      ),
      if (_ctl.loadingTrending && _ctl.trending.isEmpty)
        const SliverToBoxAdapter(
            child: Padding(
                padding: EdgeInsets.all(32),
                child: Center(child: CircularProgressIndicator())))
      else if (_ctl.trending.isEmpty)
        SliverToBoxAdapter(
          child: _Notice(
            icon: Icons.cloud_off_rounded,
            text: 'Trending is unavailable right now. Search to find music.',
            onRetry: _ctl.loadTrending,
          ),
        )
      else
        _songList(_ctl.trending, scope, 'Trending'),
    ];
  }

  Widget _songList(List<Song> songs, RyuScope scope, String label) {
    return SliverList.builder(
      itemCount: songs.length,
      itemBuilder: (_, i) => OnlineSongTile(
        song: songs[i],
        onTap: () => scope.audio.playSongs(songs, initialIndex: i, contextLabel: label),
      ),
    );
  }

  List<Widget> _results(BuildContext context, RyuScope scope) {
    final errs = _ctl.errors;
    final widgets = <Widget>[
      if (errs.isNotEmpty)
        SliverToBoxAdapter(
          child: _Notice(
            icon: Icons.wifi_off_rounded,
            text: errs.entries.map((e) => '${e.key}: ${e.value}').join('\n'),
            onRetry: _ctl.retry,
          ),
        ),
    ];
    if (_ctl.loading && _ctl.resultCount == 0) {
      widgets.add(const SliverToBoxAdapter(
          child: Padding(
              padding: EdgeInsets.all(40),
              child: Center(child: CircularProgressIndicator()))));
      return widgets;
    }
    if (_ctl.resultCount == 0 && !_ctl.loading) {
      if (errs.isEmpty) {
        widgets.add(const SliverToBoxAdapter(
            child: _Notice(icon: Icons.search_off_rounded, text: 'No results found.')));
      }
      return widgets;
    }
    switch (_ctl.type) {
      case OnlineSearchType.songs:
        widgets.add(_songList(_ctl.songs, scope, 'Online search'));
      case OnlineSearchType.artists:
        widgets.add(SliverList.builder(
          itemCount: _ctl.artists.length,
          itemBuilder: (_, i) {
            final a = _ctl.artists[i];
            return _EntityTile(
              title: a.name,
              subtitle: a.provider,
              imageUrl: a.imageUrl,
              round: true,
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => OnlineDetailScreen.artist(a))),
            );
          },
        ));
      case OnlineSearchType.albums:
        widgets.add(SliverList.builder(
          itemCount: _ctl.albums.length,
          itemBuilder: (_, i) {
            final a = _ctl.albums[i];
            return _EntityTile(
              title: a.name,
              subtitle: '${a.artist} • ${a.provider}',
              imageUrl: a.imageUrl,
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => OnlineDetailScreen.album(a))),
            );
          },
        ));
      case OnlineSearchType.playlists:
        widgets.add(SliverList.builder(
          itemCount: _ctl.playlists.length,
          itemBuilder: (_, i) {
            final p = _ctl.playlists[i];
            return _EntityTile(
              title: p.name,
              subtitle: '${p.owner} • ${p.provider}',
              imageUrl: p.imageUrl,
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => OnlineDetailScreen.playlist(p))),
            );
          },
        ));
    }
    if (_ctl.loading) {
      widgets.add(const SliverToBoxAdapter(
          child: Padding(
              padding: EdgeInsets.all(16),
              child: Center(child: CircularProgressIndicator(strokeWidth: 2)))));
    }
    return widgets;
  }
}

class _EntityTile extends StatelessWidget {
  const _EntityTile({
    required this.title,
    required this.subtitle,
    required this.onTap,
    this.imageUrl,
    this.round = false,
  });
  final String title;
  final String subtitle;
  final String? imageUrl;
  final bool round;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(round ? 28 : 12),
        child: SizedBox(
          width: 56,
          height: 56,
          child: imageUrl == null
              ? Container(
                  color: RyuColors.surfaceHigh,
                  child: const Icon(Icons.music_note_rounded, color: RyuColors.textSecondary))
              : Image.network(UriUtils.preferHttps(imageUrl!),
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                      Container(color: RyuColors.surfaceHigh)),
        ),
      ),
      title: Text(title, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(subtitle, maxLines: 1, overflow: TextOverflow.ellipsis,
          style: const TextStyle(color: RyuColors.textSecondary, fontSize: 12.5)),
      trailing: const Icon(Icons.chevron_right_rounded, color: RyuColors.textSecondary),
    );
  }
}

class _Notice extends StatelessWidget {
  const _Notice({required this.icon, required this.text, this.onRetry});
  final IconData icon;
  final String text;
  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(20, 12, 20, 0),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
          color: RyuColors.surface, borderRadius: BorderRadius.circular(18)),
      child: Row(children: [
        Icon(icon, color: RyuColors.textSecondary),
        const SizedBox(width: 12),
        Expanded(
            child: Text(text, style: const TextStyle(color: RyuColors.textSecondary))),
        if (onRetry != null) TextButton(onPressed: onRetry, child: const Text('Retry')),
      ]),
    );
  }
}

