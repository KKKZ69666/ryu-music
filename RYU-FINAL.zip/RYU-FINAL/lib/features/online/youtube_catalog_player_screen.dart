import 'package:flutter/material.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';
import '../../core/models/song.dart';
import '../../core/theme/ryu_colors.dart';

/// Embedded official YouTube IFrame playback for YouTube Music catalog items.
/// The catalog provider supplies metadata only; playback is handled by YouTube.
class YoutubeCatalogPlayerScreen extends StatefulWidget {
  const YoutubeCatalogPlayerScreen({
    super.key,
    required this.songs,
    required this.initialIndex,
  });

  final List<Song> songs;
  final int initialIndex;

  @override
  State<YoutubeCatalogPlayerScreen> createState() => _YoutubeCatalogPlayerScreenState();
}

class _YoutubeCatalogPlayerScreenState extends State<YoutubeCatalogPlayerScreen> {
  late final List<Song> _queue;
  late int _index;
  late final YoutubePlayerController _controller;

  Song get _current => _queue[_index];

  @override
  void initState() {
    super.initState();
    _queue = widget.songs.where((s) => s.remoteId?.isNotEmpty == true).toList();
    _index = widget.initialIndex.clamp(0, _queue.length - 1).toInt();
    _controller = YoutubePlayerController.fromVideoId(
      videoId: _current.remoteId!,
      autoPlay: true,
      params: const YoutubePlayerParams(
        showControls: true,
        showFullscreenButton: true,
        playsInline: true,
      ),
    );
  }

  void _move(int delta) {
    final next = _index + delta;
    if (next < 0 || next >= _queue.length) return;
    setState(() => _index = next);
    _controller.loadVideoById(videoId: _current.remoteId!);
  }

  @override
  void dispose() {
    _controller.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_queue.isEmpty) {
      return const Scaffold(body: Center(child: Text('No YouTube video is available.')));
    }
    return Scaffold(
      backgroundColor: RyuColors.void_,
      appBar: AppBar(title: const Text('RYU • YouTube Player')),
      body: SafeArea(
        child: Column(
          children: [
            YoutubePlayer(controller: _controller, aspectRatio: 16 / 9),
            Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(_current.title, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  Text(_current.artist, style: const TextStyle(color: RyuColors.textSecondary)),
                  const SizedBox(height: 18),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      IconButton(
                        tooltip: 'Previous',
                        onPressed: _index > 0 ? () => _move(-1) : null,
                        icon: const Icon(Icons.skip_previous_rounded, size: 34),
                      ),
                      const SizedBox(width: 20),
                      IconButton(
                        tooltip: 'Next',
                        onPressed: _index < _queue.length - 1 ? () => _move(1) : null,
                        icon: const Icon(Icons.skip_next_rounded, size: 34),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text('Queue • ${_index + 1} of ${_queue.length}',
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                ],
              ),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: _queue.length,
                itemBuilder: (context, i) => ListTile(
                  selected: i == _index,
                  title: Text(_queue[i].title, maxLines: 1, overflow: TextOverflow.ellipsis),
                  subtitle: Text(_queue[i].artist, maxLines: 1, overflow: TextOverflow.ellipsis),
                  trailing: i == _index ? const Icon(Icons.equalizer_rounded) : null,
                  onTap: () {
                    setState(() => _index = i);
                    _controller.loadVideoById(videoId: _current.remoteId!);
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
