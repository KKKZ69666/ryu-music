import 'package:flutter/material.dart';
import '../../core/models/song.dart';
import '../../core/online/music_provider.dart';
import '../../core/online/online_models.dart';
import '../../core/online/provider_hub.dart';
import '../../core/ryu_scope.dart';
import '../../core/theme/ryu_colors.dart';
import '../../shared/widgets/online_song_tile.dart';

/// Detail page for an online artist, album or playlist.
class OnlineDetailScreen extends StatefulWidget {
  OnlineDetailScreen.artist(OnlineArtist a, {super.key})
      : title = a.name,
        subtitle = 'Artist • ${a.provider}',
        imageUrl = a.imageUrl,
        provider = a.provider,
        loader = ((MusicProvider p) => p.artistTracks(a));
  OnlineDetailScreen.album(OnlineAlbum a, {super.key})
      : title = a.name,
        subtitle = 'Album • ${a.artist}',
        imageUrl = a.imageUrl,
        provider = a.provider,
        loader = ((MusicProvider p) => p.albumTracks(a));
  OnlineDetailScreen.playlist(OnlinePlaylist a, {super.key})
      : title = a.name,
        subtitle = 'Playlist • ${a.owner}',
        imageUrl = a.imageUrl,
        provider = a.provider,
        loader = ((MusicProvider p) => p.playlistTracks(a));

  final String title;
  final String subtitle;
  final String? imageUrl;
  final String provider;
  final Future<List<Song>> Function(MusicProvider) loader;

  @override
  State<OnlineDetailScreen> createState() => _OnlineDetailScreenState();
}

class _OnlineDetailScreenState extends State<OnlineDetailScreen> {
  List<Song>? _songs;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() {
      _songs = null;
      _error = null;
    });
    final p = ProviderHub.instance.byId(widget.provider);
    if (p == null) {
      setState(() => _error = 'Provider not available');
      return;
    }
    try {
      final s = await widget.loader(p);
      if (mounted) setState(() => _songs = s);
    } catch (e) {
      if (mounted) setState(() => _error = e.toString());
    }
  }

  @override
  Widget build(BuildContext context) {
    final scope = RyuScope.of(context);
    final songs = _songs;
    return Scaffold(
      appBar: AppBar(title: Text(widget.title, maxLines: 1, overflow: TextOverflow.ellipsis)),
      body: _error != null
          ? Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const Icon(Icons.wifi_off_rounded, size: 40, color: RyuColors.textSecondary),
                const SizedBox(height: 8),
                Text(_error!, textAlign: TextAlign.center),
                TextButton(onPressed: _load, child: const Text('Retry')),
              ]),
            )
          : songs == null
              ? const Center(child: CircularProgressIndicator())
              : songs.isEmpty
                  ? const Center(child: Text('No playable tracks found.'))
                  : ListView(padding: const EdgeInsets.only(bottom: 160), children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 8, 20, 12),
                        child: Row(children: [
                          Expanded(
                              child: Text(widget.subtitle,
                                  style: const TextStyle(color: RyuColors.textSecondary))),
                          FilledButton.icon(
                            onPressed: () => scope.audio
                                .playSongs(songs, contextLabel: widget.title),
                            icon: const Icon(Icons.play_arrow_rounded),
                            label: const Text('Play'),
                          ),
                          const SizedBox(width: 8),
                          OutlinedButton.icon(
                            onPressed: () => scope.audio.playSongs(songs,
                                contextLabel: widget.title, forceShuffle: true),
                            icon: const Icon(Icons.shuffle_rounded),
                            label: const Text('Shuffle'),
                          ),
                        ]),
                      ),
                      for (var i = 0; i < songs.length; i++)
                        OnlineSongTile(
                          song: songs[i],
                          onTap: () => scope.audio.playSongs(songs,
                              initialIndex: i, contextLabel: widget.title),
                        ),
                    ]),
    );
  }
}
