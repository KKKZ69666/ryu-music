import 'package:flutter/material.dart';
import '../../core/models/song.dart';
import '../../core/theme/ryu_colors.dart';
import '../../core/utils/duration_formatter.dart';

class OnlineSongTile extends StatelessWidget {
  const OnlineSongTile({
    super.key,
    required this.song,
    this.onTap,
    this.onMore,
    this.trailing,
  });
  final Song song;
  final VoidCallback? onTap;
  final VoidCallback? onMore;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) {
    final isCatalogPlayable = (song.provider == 'ytmusic' || song.provider == 'ytmusic_video') && (song.remoteId?.isNotEmpty ?? false);
    final isUnavailable = !song.isPlayable && !isCatalogPlayable;
    return ListTile(
      onTap: onTap,
      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
      leading: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: SizedBox(
          width: 56,
          height: 56,
          child: song.artworkUrl == null
              ? Container(
                  color: RyuColors.surfaceHigh,
                  child: const Icon(Icons.music_note_rounded,
                      color: RyuColors.textSecondary))
              : Image.network(song.artworkUrl!,
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) =>
                      Container(color: RyuColors.surfaceHigh)),
        ),
      ),
      title: Text(song.title,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(
              fontWeight: FontWeight.w700,
              color: isUnavailable ? RyuColors.textSecondary : Colors.white)),
      subtitle: Text(
        '${song.artist}${song.durationMs > 0 ? ' • ${DurationFormatter.format(Duration(milliseconds: song.durationMs))}' : ''}',
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: TextStyle(
          color: isUnavailable ? RyuColors.textSecondary.withValues(alpha: 0.7) : RyuColors.textSecondary,
          fontSize: 12.5,
        ),
      ),
      trailing: trailing ??
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              if (isUnavailable)
                const Tooltip(
                  message: 'Audio not available in RYU',
                  child: Icon(Icons.info_outline_rounded,
                      size: 18, color: RyuColors.textSecondary),
                )
              else
                const Icon(Icons.play_arrow_rounded,
                    color: RyuColors.textSecondary),
              if (onMore != null)
                IconButton(
                  icon: const Icon(Icons.more_vert_rounded,
                      color: RyuColors.textSecondary, size: 18),
                  onPressed: onMore,
                ),
            ],
          ),
    );
  }
}
