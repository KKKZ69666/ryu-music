import 'package:flutter/material.dart';
import '../../core/models/song.dart';
import '../../core/ryu_scope.dart';
import '../../core/services/download_manager.dart';
import '../../core/theme/ryu_colors.dart';
import '../../core/utils/duration_formatter.dart';
import 'artwork_image.dart';

/// Song row for online results with save / favorite / playlist / download.
class OnlineSongTile extends StatelessWidget {
  const OnlineSongTile({super.key, required this.song, required this.onTap});
  final Song song;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final scope = RyuScope.of(context);
    return ListenableBuilder(
      listenable: Listenable.merge(
          [scope.audio, scope.library, DownloadManager.instance]),
      builder: (context, _) {
        final current = scope.audio.currentSong?.id == song.id;
        final dl = DownloadManager.instance.taskFor(song.id);
        final downloaded = DownloadManager.instance.isDownloaded(song.id);
        return ListTile(
          onTap: onTap,
          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
          leading: ArtworkImage(songId: song.id, albumId: song.albumId, size: 52),
          title: Text(song.title,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: current ? RyuColors.violet : null)),
          subtitle: Row(children: [
            if (downloaded)
              const Padding(
                padding: EdgeInsets.only(right: 4),
                child: Icon(Icons.download_done_rounded, size: 14, color: RyuColors.blue),
              ),
            Expanded(
              child: Text(
                '${song.artist} • ${song.provider}'
                '${song.durationMs > 0 ? ' • ${DurationFormatter.format(song.duration)}' : ''}',
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(color: RyuColors.textSecondary, fontSize: 12.5),
              ),
            ),
          ]),
          trailing: PopupMenuButton<String>(
            icon: const Icon(Icons.more_vert_rounded, color: RyuColors.textSecondary),
            color: RyuColors.surfaceHigh,
            onSelected: (v) => _onMenu(context, v, dl),
            itemBuilder: (_) => [
              PopupMenuItem(
                value: 'save',
                child: Text(scope.library.isSavedOnline(song.id)
                    ? 'Remove from library'
                    : 'Save to library'),
              ),
              PopupMenuItem(
                value: 'fav',
                child: Text(scope.library.isFavorite(song.id)
                    ? 'Remove favorite'
                    : 'Add to favorites'),
              ),
              const PopupMenuItem(value: 'playlist', child: Text('Add to playlist')),
              const PopupMenuItem(value: 'queue', child: Text('Add to queue')),
              if (DownloadManager.canDownload(song) && !downloaded)
                const PopupMenuItem(value: 'download', child: Text('Download'))
              else if (!DownloadManager.canDownload(song))
                const PopupMenuItem(
                    enabled: false, value: 'nodl', child: Text('Download not allowed by provider')),
            ],
          ),
        );
      },
    );
  }

  Future<void> _onMenu(BuildContext context, String v, DownloadTask? dl) async {
    final scope = RyuScope.of(context);
    final messenger = ScaffoldMessenger.of(context);
    switch (v) {
      case 'save':
        await scope.library
            .setSavedOnline(song, !scope.library.isSavedOnline(song.id));
      case 'fav':
        await scope.library.registerSongs([song]);
        await scope.library.toggleFavorite(song.id);
      case 'queue':
        await scope.library.registerSongs([song]);
        await scope.audio.addToQueue(song);
        messenger.showSnackBar(const SnackBar(content: Text('Added to queue')));
      case 'download':
        await DownloadManager.instance.enqueue(song);
        messenger.showSnackBar(const SnackBar(content: Text('Download started')));
      case 'playlist':
        await scope.library.registerSongs([song]);
        if (context.mounted) await _pickPlaylist(context);
    }
  }

  Future<void> _pickPlaylist(BuildContext context) async {
    final lib = RyuScope.of(context).library;
    final messenger = ScaffoldMessenger.of(context);
    final choice = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(
        backgroundColor: RyuColors.surface,
        title: const Text('Add to playlist'),
        children: [
          SimpleDialogOption(
            onPressed: () => Navigator.pop(ctx, '__new__'),
            child: const Text('＋ New playlist'),
          ),
          for (final p in lib.playlists)
            SimpleDialogOption(
              onPressed: () => Navigator.pop(ctx, p.id),
              child: Text(p.name),
            ),
        ],
      ),
    );
    if (choice == null) return;
    if (choice == '__new__') {
      final pl = await lib.createPlaylist(song.title, initialSongIds: [song.id]);
      messenger.showSnackBar(SnackBar(content: Text('Created "${pl.name}"')));
    } else {
      await lib.addSongToPlaylist(choice, song.id);
      messenger.showSnackBar(const SnackBar(content: Text('Added to playlist')));
    }
  }
}
