# Configuration

## Online YouTube Music catalog and embedded player

`dart_ytmusic_api` is used for catalog metadata and search. The app embeds YouTube's official IFrame player via `youtube_player_iframe`; playback is subject to YouTube availability, embed restrictions, and account/region requirements.

The catalog package does not provide raw audio streams. RYU does not extract, fabricate, or bypass protected audio URLs.

## Build

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```
