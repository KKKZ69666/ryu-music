import 'package:ryu/core/utils/uri_utils.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:ryu/core/models/song.dart';
import 'package:ryu/core/online/audius_provider.dart';
import 'package:ryu/core/online/jamendo_provider.dart';
import 'package:ryu/core/online/online_models.dart';
import 'package:ryu/core/online/online_search_controller.dart';
import 'package:ryu/core/services/analytics_service.dart';
import 'package:ryu/core/services/lyrics_service.dart';

void main() {
  group('Song identity', () {
    test('local and online keys do not collide', () {
      const local = Song(
          id: 5, title: 'a', artist: 'b', album: 'c', albumId: 1, durationMs: 1, uri: 'x');
      final online = Song.online(
          provider: 'audius', remoteId: 'D7KyD', title: 'a', artist: 'b', streamUrl: 'https://x');
      expect(local.key, 'local:5');
      expect(online.key, 'audius:D7KyD');
      expect(online.id, isNegative);
      expect(online.isOnline, isTrue);
      expect(Song.onlineIdFor('audius:D7KyD'), online.id); // stable
      expect(Song.onlineIdFor('jamendo:D7KyD'), isNot(online.id));
    });

    test('toMap/fromMap round-trips online fields', () {
      final s = Song.online(
          provider: 'jamendo',
          remoteId: '9',
          title: 't',
          artist: 'a',
          streamUrl: 'https://s',
          downloadUrl: 'https://d',
          artworkUrl: 'https://i');
      final r = Song.fromMap(s.toMap());
      expect(r.key, s.key);
      expect(r.downloadUrl, 'https://d');
      expect(r.artworkUrl, 'https://i');
    });
  });

  group('Provider parsing', () {
    test('Audius track', () {
      final s = AudiusProvider.parseTrack({
        'id': 'abc',
        'title': 'Song',
        'duration': 200,
        'user': {'name': 'Artist'},
        'artwork': {'480x480': 'https://img'},
      }, 'https://host');
      expect(s!.title, 'Song');
      expect(s.durationMs, 200000);
      expect(s.uri, startsWith('https://host/v1/tracks/abc/stream'));
      expect(s.downloadUrl, isNull);
    });

    test('UriUtils upgrades http URLs to https while preserving non-http schemes', () {
      expect(UriUtils.preferHttps('http://api.jamendo.com/v3.0/tracks'),
          'https://api.jamendo.com/v3.0/tracks');
      expect(UriUtils.preferHttps('http://example.com:80/stream.mp3?a=1'),
          'https://example.com/stream.mp3?a=1');
      expect(UriUtils.preferHttps('https://api.audius.co'), 'https://api.audius.co');
      expect(UriUtils.preferHttps('content://media/external/audio/media/1'),
          'content://media/external/audio/media/1');
      expect(UriUtils.preferHttpsNullable(''), isNull);
    });

    test('Audius and Jamendo upgrade http stream/artwork/download URLs to https', () {
      final audiusSong = AudiusProvider.parseTrack({
        'id': 'xyz',
        'title': 'HTTPS Song',
        'duration': 180,
        'user': {'name': 'Artist'},
        'artwork': {'480x480': 'http://node.audius.co/art.jpg'},
      }, 'http://node.audius.co');
      expect(audiusSong!.uri, 'https://node.audius.co/v1/tracks/xyz/stream?app_name=RYU-Music');
      expect(audiusSong.artworkUrl, 'https://node.audius.co/art.jpg');

      final jamendoSong = JamendoProvider.parseTrack({
        'id': '77',
        'name': 'CC Track',
        'duration': 120,
        'artist_name': 'CC Artist',
        'audio': 'http://prod-1.storage.jamendo.com/audio.mp3',
        'audiodownload': 'http://prod-1.storage.jamendo.com/dl.mp3',
        'audiodownload_allowed': true,
        'image': 'http://usercontent.jamendo.com/cover.jpg',
      });
      expect(jamendoSong!.uri, 'https://prod-1.storage.jamendo.com/audio.mp3');
      expect(jamendoSong.downloadUrl, 'https://prod-1.storage.jamendo.com/dl.mp3');
      expect(jamendoSong.artworkUrl, 'https://usercontent.jamendo.com/cover.jpg');
    });

    test('Audius skips non-streamable tracks', () {
      expect(
          AudiusProvider.parseTrack(
              {'id': '1', 'title': 't', 'is_streamable': false}, 'https://h'),
          isNull);
    });

    test('Jamendo download only when allowed', () {
      final base = {
        'id': '1',
        'name': 'n',
        'duration': 10,
        'artist_name': 'a',
        'audio': 'https://stream',
        'audiodownload': 'https://dl',
      };
      expect(JamendoProvider.parseTrack({...base, 'audiodownload_allowed': true})!.downloadUrl,
          'https://dl');
      expect(JamendoProvider.parseTrack({...base, 'audiodownload_allowed': false})!.downloadUrl,
          isNull);
      expect(JamendoProvider.parseTrack({'id': '1', 'name': 'x'}), isNull);
    });
  });

  group('Search helpers', () {
    test('interleave round-robins', () {
      expect(
          OnlineSearchController.interleave([
            [1, 2, 3],
            [10, 20]
          ]),
          [1, 10, 2, 20, 3]);
    });

    test('sortSongs', () {
      Song mk(String t, int d) => Song.online(
          provider: 'p', remoteId: t, title: t, artist: 'z', durationMs: d, streamUrl: 'u');
      final l = [mk('b', 300), mk('a', 100)];
      expect(OnlineSearchController.sortSongs(l, OnlineSort.title).first.title, 'a');
      expect(OnlineSearchController.sortSongs(l, OnlineSort.longest).first.title, 'b');
      expect(OnlineSearchController.sortSongs(l, OnlineSort.relevance).first.title, 'b');
    });
  });

  group('Analytics buckets', () {
    test('daily buckets aggregate real durations', () {
      final now = DateTime(2026, 11, 24, 15);
      final starts = AnalyticsService.bucketStarts('day', now);
      expect(starts.length, 14);
      final b = AnalyticsService.aggregate('day', starts, [
        (DateTime(2026, 11, 24, 9), 60000),
        (DateTime(2026, 11, 24, 12), 30000),
        (DateTime(2026, 11, 23, 12), 10000),
      ]);
      expect(b.last.listenedMs, 90000);
      expect(b.last.plays, 2);
      expect(b[b.length - 2].listenedMs, 10000);
    });

    test('monthly buckets cover 12 months', () {
      expect(AnalyticsService.bucketStarts('month', DateTime(2026, 1, 15)).length, 12);
    });
  });

  test('LRCLIB candidate prefers synced text', () {
    final c = LrclibCandidate.fromJson({
      'trackName': 't',
      'artistName': 'a',
      'duration': 100,
      'syncedLyrics': '[00:01.00] hi',
      'plainLyrics': 'hi',
    });
    expect(c.isSynced, isTrue);
    expect(c.bestText, '[00:01.00] hi');
  });
}
