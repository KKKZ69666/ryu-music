import 'package:flutter/material.dart';
import '../../core/services/download_manager.dart';
import '../../core/ryu_scope.dart';
import '../../core/theme/ryu_colors.dart';
import '../../shared/widgets/artwork_image.dart';

String formatBytes(int b) {
  if (b < 1024) return '$b B';
  if (b < 1024 * 1024) return '${(b / 1024).toStringAsFixed(0)} KB';
  if (b < 1024 * 1024 * 1024) return '${(b / 1024 / 1024).toStringAsFixed(1)} MB';
  return '${(b / 1024 / 1024 / 1024).toStringAsFixed(2)} GB';
}

class DownloadsScreen extends StatelessWidget {
  const DownloadsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final dm = DownloadManager.instance;
    final scope = RyuScope.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Downloads'), actions: [
        IconButton(
          tooltip: 'Delete all downloads',
          icon: const Icon(Icons.delete_sweep_rounded),
          onPressed: () async {
            final ok = await showDialog<bool>(
              context: context,
              builder: (c) => AlertDialog(
                title: const Text('Delete all downloads?'),
                content: const Text('Downloaded files will be removed from this device.'),
                actions: [
                  TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
                  TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete')),
                ],
              ),
            );
            if (ok == true) await dm.deleteAll();
          },
        ),
      ]),
      body: ListenableBuilder(
        listenable: dm,
        builder: (context, _) {
          final tasks = dm.tasks;
          return ListView(padding: const EdgeInsets.only(bottom: 160), children: [
            FutureBuilder<int>(
              future: dm.usedBytes(),
              builder: (_, snap) => Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
                child: Text('Storage used: ${formatBytes(snap.data ?? 0)}',
                    style: const TextStyle(color: RyuColors.textSecondary)),
              ),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 0, 20, 12),
              child: Text(
                'Only tracks a provider explicitly allows to be downloaded can be saved offline (currently Jamendo, when enabled). Downloads continue while the app is open.',
                style: TextStyle(color: RyuColors.textSecondary, fontSize: 12.5),
              ),
            ),
            if (tasks.isEmpty)
              const Padding(
                padding: EdgeInsets.all(32),
                child: Center(child: Text('No downloads yet.')),
              ),
            for (final t in tasks)
              ListTile(
                onTap: t.status == DownloadStatus.completed
                    ? () => scope.audio.playSongs(
                        tasks
                            .where((x) => x.status == DownloadStatus.completed)
                            .map((x) => x.song)
                            .toList(),
                        initialIndex: tasks
                            .where((x) => x.status == DownloadStatus.completed)
                            .toList()
                            .indexOf(t),
                        contextLabel: 'Downloads')
                    : null,
                leading: ArtworkImage(songId: t.song.id, albumId: -1, size: 48),
                title: Text(t.song.title, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(_status(t), style: const TextStyle(color: RyuColors.textSecondary, fontSize: 12.5)),
                  if (t.status == DownloadStatus.downloading ||
                      t.status == DownloadStatus.paused)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: LinearProgressIndicator(value: t.progress),
                    ),
                ]),
                trailing: _actions(t, dm),
              ),
          ]);
        },
      ),
    );
  }

  String _status(DownloadTask t) {
    switch (t.status) {
      case DownloadStatus.queued:
        return 'Waiting…';
      case DownloadStatus.downloading:
        return t.total > 0
            ? 'Downloading ${formatBytes(t.received)} / ${formatBytes(t.total)}'
            : 'Downloading ${formatBytes(t.received)}';
      case DownloadStatus.paused:
        return 'Paused • ${formatBytes(t.received)}';
      case DownloadStatus.completed:
        return 'Offline • ${formatBytes(t.total)}';
      case DownloadStatus.failed:
        return 'Failed: ${t.error ?? 'unknown error'}';
    }
  }

  Widget _actions(DownloadTask t, DownloadManager dm) {
    final id = t.song.id;
    return Row(mainAxisSize: MainAxisSize.min, children: [
      if (t.status == DownloadStatus.downloading || t.status == DownloadStatus.queued)
        IconButton(icon: const Icon(Icons.pause_rounded), onPressed: () => dm.pause(id)),
      if (t.status == DownloadStatus.paused)
        IconButton(icon: const Icon(Icons.play_arrow_rounded), onPressed: () => dm.resume(id)),
      if (t.status == DownloadStatus.failed)
        IconButton(icon: const Icon(Icons.refresh_rounded), onPressed: () => dm.retry(id)),
      IconButton(
        icon: Icon(t.status == DownloadStatus.completed
            ? Icons.delete_outline_rounded
            : Icons.close_rounded),
        onPressed: () => dm.cancel(id),
      ),
    ]);
  }
}
