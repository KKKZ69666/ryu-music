import 'package:flutter/material.dart';
import '../../core/ryu_scope.dart';
import '../../core/services/analytics_service.dart';
import '../../core/services/app_settings.dart';
import '../../core/services/artwork_service.dart';
import '../../core/services/backup_service.dart';
import '../../core/services/download_manager.dart';
import '../../core/theme/ryu_colors.dart';
import 'downloads_screen.dart';
import 'saved_online_screen.dart';
import 'stats_screen.dart';

class MoreScreen extends StatelessWidget {
  const MoreScreen({super.key});

  void _toast(BuildContext c, String m) =>
      ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

  Future<bool> _confirm(BuildContext c, String title, String body) async {
    final r = await showDialog<bool>(
      context: c,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: Text(body),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Confirm')),
        ],
      ),
    );
    return r == true;
  }

  @override
  Widget build(BuildContext context) {
    final scope = RyuScope.of(context);
    final s = AppSettings.instance;
    return SafeArea(
      bottom: false,
      child: ListenableBuilder(
        listenable: Listenable.merge([s, scope.library, scope.audio]),
        builder: (context, _) => ListView(
          padding: const EdgeInsets.only(bottom: 180),
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: Text('More', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
            ),
            _nav(context, Icons.insights_rounded, 'Listening stats',
                'Top tracks, artists, daily/weekly/monthly activity', const StatsScreen()),
            _nav(context, Icons.download_rounded, 'Downloads',
                'Offline songs and storage', const DownloadsScreen()),
            _nav(context, Icons.cloud_done_rounded, 'Saved online songs',
                '${scope.library.savedOnlineSongs.length} saved', const SavedOnlineScreen()),

            _section('Playback'),
            ListTile(
              title: const Text('Volume'),
              subtitle: Slider(
                value: s.volume,
                onChanged: (v) => scope.audio.setVolume(v),
              ),
            ),
            SwitchListTile(
              title: const Text('Resume playback'),
              subtitle: const Text('Restore the last queue and position on launch'),
              value: s.resumePlayback,
              onChanged: s.setResumePlayback,
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                'Playback is gapless (ExoPlayer). Audio focus, ducking and unplug-pause are always on. Crossfade is not supported by the audio engine.',
                style: TextStyle(color: RyuColors.textSecondary, fontSize: 12),
              ),
            ),

            _section('Lyrics'),
            SwitchListTile(
              title: const Text('Auto-fetch lyrics (LRCLIB)'),
              subtitle: const Text('Search by title, artist and duration when a song plays'),
              value: s.autoFetchLyrics,
              onChanged: s.setAutoFetchLyrics,
            ),
            ListTile(
              title: Text('Text size  ×${s.lyricsScale.toStringAsFixed(2)}'),
              subtitle: Slider(
                min: 0.8, max: 1.4, divisions: 12,
                value: s.lyricsScale,
                onChanged: s.setLyricsScale,
              ),
            ),
            ListTile(
              title: Text('Sync offset  ${s.lyricsOffsetMs} ms'),
              subtitle: Slider(
                min: -3000, max: 3000, divisions: 60,
                value: s.lyricsOffsetMs.toDouble(),
                onChanged: (v) => s.setLyricsOffsetMs(v.round()),
              ),
            ),

            _section('Library'),
            ListTile(
              leading: const Icon(Icons.refresh_rounded),
              title: const Text('Rescan local music'),
              subtitle: Text(scope.library.isScanning
                  ? 'Scanning…'
                  : '${scope.library.songs.length} local songs'),
              onTap: scope.library.isScanning
                  ? null
                  : () => scope.library.scanLibrary(requestPermission: true),
            ),

            _section('Backup'),
            ListTile(
              leading: const Icon(Icons.upload_file_rounded),
              title: const Text('Export backup'),
              subtitle: const Text('Favorites, playlists, history, lyrics, settings'),
              onTap: () async {
                final r = await BackupService.instance.export(scope.library);
                if (context.mounted) _toast(context, r.message);
              },
            ),
            ListTile(
              leading: const Icon(Icons.download_for_offline_rounded),
              title: const Text('Import backup'),
              subtitle: const Text('Merges into your current data'),
              onTap: () async {
                final r = await BackupService.instance.importFromDevice(scope.library);
                if (context.mounted) _toast(context, r.message);
              },
            ),

            _section('Privacy & data'),
            ListTile(
              leading: const Icon(Icons.history_rounded),
              title: const Text('Clear listening history'),
              subtitle: const Text('History, play counts and listening stats'),
              onTap: () async {
                if (await _confirm(context, 'Clear listening history?',
                    'This removes history, play counts and statistics.')) {
                  await scope.library.clearHistory();
                  await scope.library.clearPlayCounts();
                  await AnalyticsService.instance.clear();
                  if (context.mounted) _toast(context, 'History cleared');
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.search_off_rounded),
              title: const Text('Clear recent searches'),
              onTap: () async {
                await scope.library.clearRecentSearches();
                if (context.mounted) _toast(context, 'Recent searches cleared');
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_sweep_rounded),
              title: const Text('Clear artwork cache'),
              onTap: () async {
                await ArtworkService.instance.clearCache();
                if (context.mounted) _toast(context, 'Artwork cache cleared');
              },
            ),
            ListTile(
              leading: const Icon(Icons.folder_delete_rounded),
              title: const Text('Delete all downloads'),
              onTap: () async {
                if (await _confirm(context, 'Delete all downloads?',
                    'Offline files will be removed.')) {
                  await DownloadManager.instance.deleteAll();
                  if (context.mounted) _toast(context, 'Downloads deleted');
                }
              },
            ),

            _section('About'),
            const ListTile(
              title: Text('RYU Music'),
              subtitle: Text('Your Personal Music Experience • v1.0.0'),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Text(
                'Theme: dark only. Accent colors and light mode are not implemented yet.',
                style: TextStyle(color: RyuColors.textSecondary, fontSize: 12),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _section(String t) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 24, 20, 4),
        child: Text(t.toUpperCase(),
            style: const TextStyle(
                fontSize: 12, letterSpacing: 1.2, fontWeight: FontWeight.w800,
                color: RyuColors.textSecondary)),
      );

  Widget _nav(BuildContext c, IconData icon, String title, String sub, Widget page) =>
      ListTile(
        leading: Icon(icon, color: RyuColors.violet),
        title: Text(title),
        subtitle: Text(sub),
        trailing: const Icon(Icons.chevron_right_rounded),
        onTap: () => Navigator.of(c).push(MaterialPageRoute(builder: (_) => page)),
      );
}
