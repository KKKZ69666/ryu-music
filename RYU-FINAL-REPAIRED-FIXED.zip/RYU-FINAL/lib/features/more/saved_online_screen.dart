import 'package:flutter/material.dart';
import '../../core/ryu_scope.dart';
import '../../shared/widgets/online_song_tile.dart';

class SavedOnlineScreen extends StatelessWidget {
  const SavedOnlineScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final scope = RyuScope.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Saved online songs')),
      body: ListenableBuilder(
        listenable: scope.library,
        builder: (context, _) {
          final songs = scope.library.savedOnlineSongs;
          if (songs.isEmpty) {
            return const Center(
                child: Padding(
              padding: EdgeInsets.all(32),
              child: Text(
                  'Songs you save from the Online tab appear here.',
                  textAlign: TextAlign.center),
            ));
          }
          return ListView.builder(
            padding: const EdgeInsets.only(bottom: 160),
            itemCount: songs.length,
            itemBuilder: (_, i) => OnlineSongTile(
              song: songs[i],
              onTap: () => scope.audio.playSongs(songs,
                  initialIndex: i, contextLabel: 'Saved online'),
            ),
          );
        },
      ),
    );
  }
}
