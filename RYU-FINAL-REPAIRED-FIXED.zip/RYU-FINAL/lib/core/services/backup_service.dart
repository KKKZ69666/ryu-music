import 'dart:convert';
import 'package:flutter/services.dart';
import '../controllers/library_controller.dart';
import '../models/history_entry.dart';
import '../models/playlist.dart';
import '../models/song.dart';
import 'app_settings.dart';
import 'storage_service.dart';

class BackupResult {
  const BackupResult(this.message, {this.ok = true});
  final String message;
  final bool ok;
}

/// Export/import of user data (favorites, playlists, history, play counts,
/// lyrics, settings, online track metadata) as a JSON file.
class BackupService {
  BackupService._();
  static final BackupService instance = BackupService._();

  static const _channel = MethodChannel('com.ryu.music/media_store');
  static const formatVersion = 1;

  Map<String, dynamic> buildBackup(LibraryController lib) {
    final st = StorageService.instance;
    final referenced = <int>{
      ...lib.favoriteIds,
      for (final p in lib.playlists) ...p.songIds,
      ...lib.playCounts.keys,
    };
    final tracks = <Map<String, dynamic>>[];
    for (final id in referenced) {
      final s = lib.songById(id);
      if (s == null) continue;
      tracks.add({
        'id': s.id,
        'provider': s.provider,
        'remoteId': s.remoteId,
        'title': s.title,
        'artist': s.artist,
        'album': s.album,
        'durationMs': s.durationMs,
        'artworkUrl': s.artworkUrl,
        if (s.isOnline) 'uri': s.uri,
        if (s.isOnline) 'downloadUrl': s.downloadUrl,
        'saved': lib.isSavedOnline(s.id),
      });
    }
    final lyrics = <String, dynamic>{};
    for (final id in referenced) {
      final l = st.loadSongLyrics(id);
      if (l != null && (l['rawText'] ?? '').isNotEmpty) lyrics['$id'] = l;
    }
    return {
      'app': 'RYU Music',
      'formatVersion': formatVersion,
      'exportedAt': DateTime.now().toIso8601String(),
      'tracks': tracks,
      'favorites': lib.favoriteIds.toList(),
      'playlists': lib.playlists.map((p) => p.toJson()).toList(),
      'history': lib.history.map((h) => h.toJson()).toList(),
      'playCounts': lib.playCounts.map((k, v) => MapEntry('$k', v)),
      'lyrics': lyrics,
      'settings': {
        for (final k in AppSettings.backupKeys)
          if (st.getSetting(k) != null) k: st.getSetting(k),
      },
    };
  }

  Future<BackupResult> export(LibraryController lib) async {
    try {
      final json = const JsonEncoder.withIndent('  ').convert(buildBackup(lib));
      final d = DateTime.now();
      final name =
          'ryu-backup-${d.year}${d.month.toString().padLeft(2, '0')}${d.day.toString().padLeft(2, '0')}.json';
      final ok = await _channel.invokeMethod<bool>(
          'saveTextFile', {'name': name, 'content': json});
      return ok == true
          ? BackupResult('Backup saved ($name)')
          : const BackupResult('Export cancelled', ok: false);
    } catch (e) {
      return BackupResult('Export failed: $e', ok: false);
    }
  }

  Future<BackupResult> importFromDevice(LibraryController lib) async {
    try {
      final text = await _channel.invokeMethod<String>('pickTextFile');
      if (text == null || text.trim().isEmpty) {
        return const BackupResult('Import cancelled', ok: false);
      }
      return await restore(lib, text);
    } catch (e) {
      return BackupResult('Import failed: $e', ok: false);
    }
  }

  /// Merge a backup into current data. Never deletes existing data.
  Future<BackupResult> restore(LibraryController lib, String jsonText) async {
    final Map<String, dynamic> data;
    try {
      data = jsonDecode(jsonText) as Map<String, dynamic>;
    } catch (_) {
      return const BackupResult('Not a valid RYU backup file', ok: false);
    }
    if (data['app'] != 'RYU Music' || data['formatVersion'] is! num) {
      return const BackupResult('Not a valid RYU backup file', ok: false);
    }
    if ((data['formatVersion'] as num) > formatVersion) {
      return const BackupResult('Backup was made by a newer RYU version',
          ok: false);
    }
    final st = StorageService.instance;

    // 1) Resolve ids: online ids are deterministic; local ids are remapped by
    //    title+artist when the MediaStore id differs on this device.
    final remap = <int, int>{};
    final onlineToSave = <Song>[];
    final savedFlags = <int, bool>{};
    final localByKey = <String, Song>{
      for (final s in lib.songs) '${s.title.toLowerCase()}|${s.artist.toLowerCase()}': s
    };
    for (final t in (data['tracks'] as List? ?? const [])
        .whereType<Map<String, dynamic>>()) {
      final id = (t['id'] as num?)?.toInt();
      if (id == null) continue;
      final provider = (t['provider'] as String?) ?? 'local';
      if (provider != 'local' && t['remoteId'] != null) {
        final s = Song.online(
          provider: provider,
          remoteId: t['remoteId'] as String,
          title: (t['title'] as String?) ?? 'Unknown Title',
          artist: (t['artist'] as String?) ?? 'Unknown Artist',
          album: (t['album'] as String?) ?? '',
          durationMs: (t['durationMs'] as num?)?.toInt() ?? 0,
          streamUrl: (t['uri'] as String?) ?? '',
          artworkUrl: t['artworkUrl'] as String?,
          downloadUrl: t['downloadUrl'] as String?,
        );
        if (s.uri.isNotEmpty) {
          onlineToSave.add(s);
          savedFlags[s.id] = t['saved'] == true;
          remap[id] = s.id;
        }
      } else {
        final cur = lib.songById(id);
        final title = ((t['title'] as String?) ?? '').toLowerCase();
        final artist = ((t['artist'] as String?) ?? '').toLowerCase();
        if (cur != null && cur.title.toLowerCase() == title) {
          remap[id] = id;
        } else {
          final m = localByKey['$title|$artist'];
          remap[id] = m?.id ?? id;
        }
      }
    }
    int mapId(int id) => remap[id] ?? id;

    for (final s in onlineToSave) {
      await lib.registerSongs([s], save: savedFlags[s.id] == true ? true : null);
    }

    // 2) Favorites (union)
    final favs = {...lib.favoriteIds};
    for (final e in (data['favorites'] as List? ?? const [])) {
      if (e is num) favs.add(mapId(e.toInt()));
    }
    await st.saveFavorites(favs);

    // 3) Playlists (add those whose id is not present)
    final pls = [...lib.playlists];
    var addedPl = 0;
    for (final p in (data['playlists'] as List? ?? const [])
        .whereType<Map<String, dynamic>>()) {
      final pl = RyuPlaylist.fromJson(p);
      if (pl.id.isEmpty || pls.any((x) => x.id == pl.id)) continue;
      pls.add(pl.copyWith(songIds: pl.songIds.map(mapId).toList()));
      addedPl++;
    }
    await st.savePlaylists(pls);

    // 4) Play counts (max) and history (merge, newest first, cap 200)
    final counts = {...lib.playCounts};
    (data['playCounts'] as Map<String, dynamic>? ?? const {}).forEach((k, v) {
      final id = int.tryParse(k);
      if (id != null && v is num) {
        final m = mapId(id);
        final cur = counts[m] ?? 0;
        if (v.toInt() > cur) counts[m] = v.toInt();
      }
    });
    await st.savePlayCounts(counts);

    final hist = [...lib.history];
    final seen = {for (final h in hist) '${h.songId}@${h.playedAt.toIso8601String()}'};
    for (final h in (data['history'] as List? ?? const [])
        .whereType<Map<String, dynamic>>()) {
      final e = HistoryEntry.fromJson(h);
      final mapped = HistoryEntry(songId: mapId(e.songId), playedAt: e.playedAt);
      if (seen.add('${mapped.songId}@${mapped.playedAt.toIso8601String()}')) {
        hist.add(mapped);
      }
    }
    hist.sort((a, b) => b.playedAt.compareTo(a.playedAt));
    await st.saveHistory(hist.take(200).toList());

    // 5) Lyrics (only if none stored) and settings
    final lyr = data['lyrics'] as Map<String, dynamic>? ?? const {};
    for (final e in lyr.entries) {
      final id = int.tryParse(e.key);
      final v = e.value;
      if (id == null || v is! Map) continue;
      final target = mapId(id);
      final existing = st.loadSongLyrics(target);
      if (existing == null || (existing['rawText'] ?? '').isEmpty) {
        await st.saveSongLyrics(
          songId: target,
          rawText: (v['rawText'] as String?) ?? '',
          sourceName: (v['source'] as String?) ?? 'importedFile',
        );
      }
    }
    final settings = data['settings'];
    if (settings is Map) {
      for (final k in AppSettings.backupKeys) {
        final v = settings[k];
        if (v is String) await st.setSetting(k, v);
      }
      AppSettings.instance.reload();
    }

    await lib.reloadFromStorage();
    return BackupResult(
        'Restored: ${favs.length} favorites, $addedPl new playlists, ${onlineToSave.length} online tracks');
  }
}
