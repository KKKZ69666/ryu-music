import 'package:flutter/foundation.dart';
import 'storage_service.dart';

class TopEntry {
  const TopEntry(this.label, this.sub, this.listenedMs, this.plays, {this.songId});
  final String label;
  final String sub;
  final int listenedMs;
  final int plays;
  final int? songId;
}

class Bucket {
  const Bucket(this.label, this.listenedMs, this.plays);
  final String label;
  final int listenedMs;
  final int plays;
}

class StatsSummary {
  const StatsSummary(this.totalMs, this.plays, this.topTracks, this.topArtists);
  final int totalMs;
  final int plays;
  final List<TopEntry> topTracks;
  final List<TopEntry> topArtists;
}

/// Real listening analytics: one row per play instance in `listen_events`,
/// with the actual milliseconds the track was audible (paused time excluded).
class AnalyticsService {
  AnalyticsService._();
  static final AnalyticsService instance = AnalyticsService._();

  /// Minimum audible time before a play is counted.
  static const minCountMs = 5000;

  Future<int?> insertEvent(int songId, DateTime start, int ms) async {
    final db = StorageService.instance.db;
    if (db == null) return null;
    try {
      return await db.insert('listen_events', {
        'song_id': songId,
        'started_at': start.millisecondsSinceEpoch,
        'listened_ms': ms,
      });
    } catch (e) {
      debugPrint('RYU: analytics insert failed: $e');
      return null;
    }
  }

  Future<void> updateEvent(int rowId, int ms) async {
    final db = StorageService.instance.db;
    try {
      await db?.update('listen_events', {'listened_ms': ms},
          where: 'id = ?', whereArgs: [rowId]);
    } catch (_) {}
  }

  Future<void> clear() async {
    try {
      await StorageService.instance.db?.delete('listen_events');
    } catch (_) {}
  }

  Future<StatsSummary> summary({DateTime? since, int limit = 10}) async {
    final db = StorageService.instance.db;
    if (db == null) return const StatsSummary(0, 0, [], []);
    final from = (since ?? DateTime.fromMillisecondsSinceEpoch(0)).millisecondsSinceEpoch;
    final tot = await db.rawQuery(
        'SELECT COALESCE(SUM(listened_ms),0) ms, COUNT(*) c FROM listen_events WHERE started_at >= ?',
        [from]);
    final tracks = await db.rawQuery('''
      SELECT t.id id, t.title title, t.artist artist,
             SUM(e.listened_ms) ms, COUNT(*) c
      FROM listen_events e JOIN tracks t ON t.id = e.song_id
      WHERE e.started_at >= ? GROUP BY t.id ORDER BY c DESC, ms DESC LIMIT ?''',
        [from, limit]);
    final artists = await db.rawQuery('''
      SELECT t.artist artist, SUM(e.listened_ms) ms, COUNT(*) c
      FROM listen_events e JOIN tracks t ON t.id = e.song_id
      WHERE e.started_at >= ? GROUP BY t.artist ORDER BY ms DESC LIMIT ?''',
        [from, limit]);
    return StatsSummary(
      (tot.first['ms'] as num).toInt(),
      (tot.first['c'] as num).toInt(),
      tracks
          .map((r) => TopEntry(r['title'] as String? ?? '?',
              r['artist'] as String? ?? '', (r['ms'] as num).toInt(),
              (r['c'] as num).toInt(),
              songId: (r['id'] as num).toInt()))
          .toList(),
      artists
          .map((r) => TopEntry(r['artist'] as String? ?? '?', '',
              (r['ms'] as num).toInt(), (r['c'] as num).toInt()))
          .toList(),
    );
  }

  /// mode: 'day' (last 14 days), 'week' (last 12 weeks), 'month' (last 12 months)
  Future<List<Bucket>> buckets(String mode, {DateTime? now}) async {
    final db = StorageService.instance.db;
    final n = now ?? DateTime.now();
    final starts = bucketStarts(mode, n);
    if (db == null) return [for (final s in starts) Bucket(_label(mode, s), 0, 0)];
    final rows = await db.query('listen_events',
        columns: ['started_at', 'listened_ms'],
        where: 'started_at >= ?',
        whereArgs: [starts.first.millisecondsSinceEpoch]);
    return aggregate(mode, starts, rows
        .map((r) => (
              DateTime.fromMillisecondsSinceEpoch((r['started_at'] as num).toInt()),
              (r['listened_ms'] as num).toInt()
            ))
        .toList());
  }

  /// Pure helpers (unit-tested).
  @visibleForTesting
  static List<DateTime> bucketStarts(String mode, DateTime now) {
    final today = DateTime(now.year, now.month, now.day);
    switch (mode) {
      case 'week':
        final monday = today.subtract(Duration(days: today.weekday - 1));
        return [for (var i = 11; i >= 0; i--) monday.subtract(Duration(days: 7 * i))];
      case 'month':
        return [for (var i = 11; i >= 0; i--) DateTime(now.year, now.month - i, 1)];
      default:
        return [for (var i = 13; i >= 0; i--) today.subtract(Duration(days: i))];
    }
  }

  @visibleForTesting
  static List<Bucket> aggregate(
      String mode, List<DateTime> starts, List<(DateTime, int)> events) {
    final ms = List<int>.filled(starts.length, 0);
    final plays = List<int>.filled(starts.length, 0);
    for (final (t, m) in events) {
      for (var i = starts.length - 1; i >= 0; i--) {
        if (!t.isBefore(starts[i])) {
          ms[i] += m;
          plays[i] += 1;
          break;
        }
      }
    }
    return [for (var i = 0; i < starts.length; i++) Bucket(_label(mode, starts[i]), ms[i], plays[i])];
  }

  static String _label(String mode, DateTime d) {
    const mo = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
    if (mode == 'month') return mo[d.month - 1];
    return '${d.day}/${d.month}';
  }
}
