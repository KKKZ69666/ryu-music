import 'package:flutter/foundation.dart';
import 'storage_service.dart';

/// User settings, persisted in SQLite (settings table). Every field here is
/// read by real code paths (see usages) — no placebo toggles.
class AppSettings extends ChangeNotifier {
  AppSettings._();
  static final AppSettings instance = AppSettings._();

  final StorageService _s = StorageService.instance;

  bool get autoFetchLyrics => _s.getSetting('autoFetchLyrics') != '0';
  bool get resumePlayback => _s.getSetting('resumePlayback') != '0';
  double get lyricsScale =>
      (double.tryParse(_s.getSetting('lyricsScale') ?? '') ?? 1.0)
          .clamp(0.8, 1.4);
  int get lyricsOffsetMs =>
      (int.tryParse(_s.getSetting('lyricsOffsetMs') ?? '') ?? 0)
          .clamp(-3000, 3000);
  double get volume =>
      (double.tryParse(_s.getSetting('volume') ?? '') ?? 1.0).clamp(0.0, 1.0);

  /// Notify listeners after settings were changed in bulk (backup restore).
  void reload() => notifyListeners();

  Future<void> _set(String k, String v) async {
    await _s.setSetting(k, v);
    notifyListeners();
  }

  Future<void> setAutoFetchLyrics(bool v) => _set('autoFetchLyrics', v ? '1' : '0');
  Future<void> setResumePlayback(bool v) => _set('resumePlayback', v ? '1' : '0');
  Future<void> setLyricsScale(double v) => _set('lyricsScale', v.toStringAsFixed(2));
  Future<void> setLyricsOffsetMs(int v) => _set('lyricsOffsetMs', '$v');
  Future<void> setVolume(double v) => _set('volume', v.toStringAsFixed(2));

  /// Keys included in backups.
  static const backupKeys = [
    'autoFetchLyrics',
    'resumePlayback',
    'lyricsScale',
    'lyricsOffsetMs',
    'volume',
    'shuffle',
    'repeat',
  ];
}
