import 'dart:convert';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../models/lyric_line.dart';
import '../models/song.dart';
import 'storage_service.dart';

class LrclibCandidate {
  const LrclibCandidate({
    required this.id,
    required this.title,
    required this.artist,
    required this.album,
    required this.durationSec,
    required this.plainLyrics,
    required this.syncedLyrics,
  });

  final int id;
  final String title;
  final String artist;
  final String album;
  final double durationSec;
  final String plainLyrics;
  final String syncedLyrics;
  bool get isSynced => syncedLyrics.trim().isNotEmpty;

  factory LrclibCandidate.fromJson(Map<String, dynamic> json) {
    return LrclibCandidate(
      id: (json['id'] as num?)?.toInt() ?? 0,
      title: (json['trackName'] ?? '').toString(),
      artist: (json['artistName'] ?? '').toString(),
      album: (json['albumName'] ?? '').toString(),
      durationSec: (json['duration'] as num?)?.toDouble() ?? 0,
      plainLyrics: (json['plainLyrics'] ?? '').toString(),
      syncedLyrics: (json['syncedLyrics'] ?? '').toString(),
    );
  }
}

/// Lyrics are cached per song and can be sourced from LRCLIB, imported LRC,
/// or text entered by the user. YouTube catalog metadata is not treated as an
/// audio stream and is not needed to retrieve lyrics.
class LyricsService {
  LyricsService._();
  static final LyricsService instance = LyricsService._();

  Future<LyricsDocument?> loadLyricsForSong(Song song) async {
    final saved = await StorageService.instance.fetchSongLyrics(song.id);
    if (saved == null || (saved['rawText'] ?? '').isEmpty) return null;
    final raw = saved['rawText']!;
    final source = LyricsSource.values.firstWhere(
      (s) => s.name == saved['source'],
      orElse: () => LyricsSource.manualInput,
    );
    return _documentFromText(raw, source: source);
  }

  Future<void> _save(Song song, LyricsDocument doc) async {
    await StorageService.instance.saveSongLyrics(
      songId: song.id,
      rawText: doc.rawText,
      sourceName: doc.source.name,
    );
  }

  Future<LyricsDocument?> autoFetch(Song song) => fetchFromLrclib(song);

  Future<List<LrclibCandidate>> searchCandidates(Song song) async {
    final uri = Uri.https('lrclib.net', '/api/search', {
      'track_name': song.title,
      'artist_name': song.artist,
    });
    final response = await http.get(uri, headers: const {'User-Agent': 'RYU-Music/1.0'})
        .timeout(const Duration(seconds: 12));
    if (response.statusCode != 200) return [];
    final decoded = jsonDecode(utf8.decode(response.bodyBytes));
    if (decoded is! List) return [];
    return decoded.whereType<Map>().map((e) => LrclibCandidate.fromJson(
      Map<String, dynamic>.from(e),
    )).toList();
  }

  Future<LyricsDocument?> fetchFromLrclib(Song song) async {
    try {
      final candidates = await searchCandidates(song);
      if (candidates.isEmpty) return null;
      final candidate = candidates.firstWhere(
        (c) => c.isSynced || c.plainLyrics.trim().isNotEmpty,
        orElse: () => candidates.first,
      );
      return applyCandidate(song, candidate);
    } catch (_) {
      return null;
    }
  }

  Future<LyricsDocument?> applyCandidate(Song song, LrclibCandidate candidate) async {
    final raw = candidate.isSynced ? candidate.syncedLyrics : candidate.plainLyrics;
    if (raw.trim().isEmpty) return null;
    final doc = _documentFromText(raw,
      source: LyricsSource.lrclibOnline,
    );
    await _save(song, doc);
    return doc;
  }

  Future<LyricsDocument?> saveCustomLyrics({required Song song, required String rawText}) async {
    if (rawText.trim().isEmpty) return null;
    final doc = _documentFromText(rawText, source: LyricsSource.manualInput);
    await _save(song, doc);
    return doc;
  }

  Future<LyricsDocument?> importLrcFromDevice(Song song) async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['lrc', 'txt'],
        withData: true,
      );
      if (result == null || result.files.isEmpty) return null;
      final bytes = result.files.single.bytes;
      if (bytes == null) return null;
      final raw = utf8.decode(bytes, allowMalformed: true);
      if (raw.trim().isEmpty) return null;
      final doc = _documentFromText(raw, source: LyricsSource.importedFile);
      await _save(song, doc);
      return doc;
    } catch (error) {
      debugPrint('RYU lyrics import failed: $error');
      rethrow;
    }
  }

  Future<void> clearSavedLyrics(int songId) async {
    await StorageService.instance.clearSongLyrics(songId);
  }

  LyricsDocument _documentFromText(
    String raw, {
    required LyricsSource source,
  }) {
    final lines = <LyricLine>[];
    final timestampPattern = RegExp(r'^\[(\d{1,2}):(\d{2})(?:\.(\d{1,3}))?\](.*)$');
    for (final original in raw.split(RegExp(r'\r?\n'))) {
      final line = original.trimRight();
      final match = timestampPattern.firstMatch(line);
      if (match != null) {
        final minutes = int.tryParse(match.group(1)!) ?? 0;
        final seconds = int.tryParse(match.group(2)!) ?? 0;
        final fraction = (match.group(3) ?? '0').padRight(3, '0').substring(0, 3);
        final millis = int.tryParse(fraction) ?? 0;
        lines.add(LyricLine(
          timestamp: Duration(minutes: minutes, seconds: seconds, milliseconds: millis),
          text: match.group(4)!.trim(),
        ));
      } else if (line.trim().isNotEmpty && !line.startsWith('[')) {
        lines.add(LyricLine(text: line.trim()));
      }
    }
    lines.sort((a, b) {
      if (a.timestamp == null) return b.timestamp == null ? 0 : 1;
      if (b.timestamp == null) return -1;
      return a.timestamp!.compareTo(b.timestamp!);
    });
    return LyricsDocument(lines: lines, source: source, rawText: raw);
  }
}
