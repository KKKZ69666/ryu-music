import '../utils/uri_utils.dart';
import 'dart:async';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import '../models/song.dart';
import 'storage_service.dart';

enum DownloadStatus { queued, downloading, paused, completed, failed }

class DownloadTask {
  DownloadTask(this.song, {this.status = DownloadStatus.queued});
  final Song song;
  DownloadStatus status;
  int received = 0;
  int total = 0;
  String? path;
  String? error;

  double? get progress =>
      total > 0 ? (received / total).clamp(0.0, 1.0).toDouble() : null;
}

/// Downloads only tracks whose provider explicitly supplied a download URL
/// ([Song.downloadUrl]). Pause/resume uses HTTP Range when the server allows.
/// Downloads run while the app process is alive (no background service).
class DownloadManager extends ChangeNotifier {
  DownloadManager._();
  static final DownloadManager instance = DownloadManager._();

  static const _maxParallel = 2;

  final Map<int, DownloadTask> _tasks = {};
  final Map<int, http.Client> _clients = {};
  final Set<int> _stopRequested = {};
  final Set<int> _cancelRequested = {};
  Directory? _dir;

  List<DownloadTask> get tasks {
    final list = _tasks.values.toList();
    list.sort((a, b) => a.song.title.toLowerCase().compareTo(b.song.title.toLowerCase()));
    return list;
  }

  DownloadTask? taskFor(int songId) => _tasks[songId];

  static bool canDownload(Song s) =>
      s.isOnline && (s.downloadUrl ?? '').isNotEmpty;

  Future<Directory> _downloadDir() async {
    if (_dir != null) return _dir!;
    final base = await getApplicationDocumentsDirectory();
    final d = Directory('${base.path}/downloads');
    if (!await d.exists()) await d.create(recursive: true);
    return _dir = d;
  }

  /// Load persisted tasks; verify completed files still exist and are intact.
  Future<void> init() async {
    final db = StorageService.instance.db;
    if (db == null) return;
    try {
      final rows = await db.query('downloads');
      final songs = {
        for (final (s, _) in await StorageService.instance.loadOnlineTracks())
          s.id: s
      };
      for (final r in rows) {
        final id = (r['song_id'] as num).toInt();
        final song = songs[id];
        if (song == null) continue;
        final t = DownloadTask(song);
        t.path = r['path'] as String?;
        t.received = (r['received'] as num?)?.toInt() ?? 0;
        t.total = (r['total'] as num?)?.toInt() ?? 0;
        t.error = r['error'] as String?;
        final st = r['status'] as String? ?? 'failed';
        t.status = DownloadStatus.values.firstWhere((e) => e.name == st,
            orElse: () => DownloadStatus.failed);
        if (t.status == DownloadStatus.completed) {
          final f = t.path == null ? null : File(t.path!);
          if (f == null || !f.existsSync() || f.lengthSync() == 0) {
            t.status = DownloadStatus.failed;
            t.error = 'File missing or corrupt';
          }
        } else if (t.status == DownloadStatus.downloading ||
            t.status == DownloadStatus.queued) {
          t.status = DownloadStatus.paused; // interrupted by app exit
        }
        _tasks[id] = t;
      }
      notifyListeners();
    } catch (e) {
      debugPrint('RYU: downloads init failed: $e');
    }
  }

  /// file:// URI to play instead of streaming, or null.
  Uri? localUriFor(int songId) {
    final t = _tasks[songId];
    if (t == null || t.status != DownloadStatus.completed || t.path == null) {
      return null;
    }
    final f = File(t.path!);
    if (!f.existsSync() || f.lengthSync() == 0) return null;
    return Uri.file(t.path!);
  }

  bool isDownloaded(int songId) => localUriFor(songId) != null;

  Future<void> _persist(DownloadTask t) async {
    final db = StorageService.instance.db;
    if (db == null) return;
    try {
      await db.insert(
          'downloads',
          {
            'song_id': t.song.id,
            'status': t.status.name,
            'path': t.path,
            'received': t.received,
            'total': t.total,
            'error': t.error,
            'updated_at': DateTime.now().millisecondsSinceEpoch,
          },
          conflictAlgorithm: ConflictAlgorithm.replace);
    } catch (e) {
      debugPrint('RYU: download persist failed: $e');
    }
  }

  Future<void> enqueue(Song song) async {
    if (!canDownload(song)) return;
    final existing = _tasks[song.id];
    if (existing != null &&
        (existing.status == DownloadStatus.downloading ||
            existing.status == DownloadStatus.queued ||
            existing.status == DownloadStatus.completed)) {
      return;
    }
    await StorageService.instance.upsertTracks([song]);
    final t = existing ?? DownloadTask(song);
    t.status = DownloadStatus.queued;
    t.error = null;
    _tasks[song.id] = t;
    await _persist(t);
    notifyListeners();
    _pump();
  }

  void _pump() {
    final running =
        _tasks.values.where((t) => t.status == DownloadStatus.downloading).length;
    var free = _maxParallel - running;
    for (final t in _tasks.values) {
      if (free <= 0) break;
      if (t.status == DownloadStatus.queued) {
        free--;
        unawaited(_run(t));
      }
    }
  }

  static String _safeName(Song s) {
    final raw = '${s.provider}_${s.remoteId ?? s.id}';
    return raw.replaceAll(RegExp(r'[^A-Za-z0-9_\-]'), '_');
  }

  Future<void> _run(DownloadTask t) async {
    final id = t.song.id;
    t.status = DownloadStatus.downloading;
    t.error = null;
    notifyListeners();
    final client = http.Client();
    _clients[id] = client;
    IOSink? sink;
    try {
      final dir = await _downloadDir();
      final finalPath = '${dir.path}/${_safeName(t.song)}.mp3';
      final partFile = File('$finalPath.part');
      var start = 0;
      if (await partFile.exists()) start = await partFile.length();

      final req = http.Request(
        'GET',
        Uri.parse(UriUtils.preferHttps(t.song.downloadUrl!)),
      );
      req.headers['User-Agent'] = 'RYU-Music/1.0 (Android)';
      if (start > 0) req.headers['Range'] = 'bytes=$start-';
      final res = await client.send(req).timeout(const Duration(seconds: 20));

      if (res.statusCode != 200 && res.statusCode != 206) {
        throw HttpException('Server returned ${res.statusCode}');
      }
      final resumed = res.statusCode == 206 && start > 0;
      if (!resumed) start = 0; // server ignored Range -> restart from zero
      final len = res.contentLength ?? 0;
      t.total = len > 0 ? start + len : 0;
      t.received = start;
      sink = partFile.openWrite(mode: resumed ? FileMode.append : FileMode.write);

      var lastNotify = 0;
      await for (final chunk in res.stream) {
        if (_stopRequested.contains(id) || _cancelRequested.contains(id)) break;
        sink.add(chunk);
        t.received += chunk.length;
        final now = DateTime.now().millisecondsSinceEpoch;
        if (now - lastNotify > 250) {
          lastNotify = now;
          notifyListeners();
        }
      }
      await sink.flush();
      await sink.close();
      sink = null;

      if (_cancelRequested.remove(id)) {
        if (await partFile.exists()) await partFile.delete();
        _tasks.remove(id);
        await _delete(id);
      } else if (_stopRequested.remove(id)) {
        t.status = DownloadStatus.paused;
        await _persist(t);
      } else {
        final size = await partFile.length();
        if (size == 0 || (t.total > 0 && size != t.total)) {
          await partFile.delete();
          t.received = 0;
          throw const FormatException('Incomplete or corrupt file');
        }
        final dest = File(finalPath);
        if (await dest.exists()) await dest.delete();
        await partFile.rename(finalPath);
        t.path = finalPath;
        t.received = size;
        t.total = size;
        t.status = DownloadStatus.completed;
        await _persist(t);
      }
    } catch (e) {
      try {
        await sink?.close();
      } catch (_) {}
      if (_cancelRequested.remove(id)) {
        _tasks.remove(id);
        await _delete(id);
      } else if (_stopRequested.remove(id)) {
        t.status = DownloadStatus.paused;
        await _persist(t);
      } else {
        t.status = DownloadStatus.failed;
        t.error = e is SocketException || e is http.ClientException
            ? 'Connection lost'
            : e.toString();
        await _persist(t);
      }
    } finally {
      _clients.remove(id)?.close();
      notifyListeners();
      _pump();
    }
  }

  void pause(int songId) {
    final t = _tasks[songId];
    if (t == null) return;
    if (t.status == DownloadStatus.downloading) {
      _stopRequested.add(songId);
      _clients.remove(songId)?.close();
    } else if (t.status == DownloadStatus.queued) {
      t.status = DownloadStatus.paused;
      _persist(t);
      notifyListeners();
    }
  }

  Future<void> resume(int songId) async {
    final t = _tasks[songId];
    if (t == null) return;
    if (t.status == DownloadStatus.paused || t.status == DownloadStatus.failed) {
      t.status = DownloadStatus.queued;
      t.error = null;
      await _persist(t);
      notifyListeners();
      _pump();
    }
  }

  Future<void> retry(int songId) => resume(songId);

  /// Cancel an in-progress download and drop partial data.
  Future<void> cancel(int songId) async {
    final t = _tasks[songId];
    if (t == null) return;
    if (t.status == DownloadStatus.downloading) {
      _cancelRequested.add(songId);
      _clients.remove(songId)?.close();
      return; // _run cleans up
    }
    await remove(songId);
  }

  /// Delete a task and its file(s).
  Future<void> remove(int songId) async {
    final t = _tasks.remove(songId);
    if (t?.path != null) {
      try {
        final f = File(t!.path!);
        if (await f.exists()) await f.delete();
      } catch (_) {}
    }
    try {
      final dir = await _downloadDir();
      final part = File('${dir.path}/${_safeName(t?.song ?? Song.online(provider: 'x', remoteId: '$songId', title: '', artist: '', streamUrl: ''))}.mp3.part');
      if (await part.exists()) await part.delete();
    } catch (_) {}
    await _delete(songId);
    notifyListeners();
  }

  Future<void> _delete(int songId) async {
    final db = StorageService.instance.db;
    try {
      await db?.delete('downloads', where: 'song_id = ?', whereArgs: [songId]);
    } catch (_) {}
  }

  Future<int> usedBytes() async {
    try {
      final dir = await _downloadDir();
      var sum = 0;
      await for (final e in dir.list()) {
        if (e is File) sum += await e.length();
      }
      return sum;
    } catch (_) {
      return 0;
    }
  }

  Future<void> deleteAll() async {
    for (final id in _tasks.keys.toList()) {
      if (_tasks[id]?.status == DownloadStatus.downloading) {
        _cancelRequested.add(id);
        _clients.remove(id)?.close();
      } else {
        await remove(id);
      }
    }
  }
}
