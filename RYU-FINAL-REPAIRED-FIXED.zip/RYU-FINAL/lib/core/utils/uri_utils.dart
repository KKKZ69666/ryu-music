class UriUtils {
  UriUtils._();

  /// Upgrades `http://` URLs to `https://` so Android builds with
  /// `usesCleartextTraffic="false"` prioritize encrypted HTTPS connections
  /// without enabling global cleartext traffic.
  static String preferHttps(String url) {
    final trimmed = url.trim();
    if (trimmed.isEmpty) return trimmed;
    final uri = Uri.tryParse(trimmed);
    if (uri != null && uri.scheme.toLowerCase() == 'http') {
      if (uri.hasPort && uri.port == 80) {
        return Uri(
          scheme: 'https',
          userInfo: uri.userInfo,
          host: uri.host,
          path: uri.path,
          query: uri.hasQuery ? uri.query : null,
          fragment: uri.hasFragment ? uri.fragment : null,
        ).toString();
      }
      return uri.replace(scheme: 'https').toString();
    }
    return trimmed;
  }

  static String? preferHttpsNullable(String? url) {
    if (url == null) return null;
    final trimmed = url.trim();
    if (trimmed.isEmpty) return null;
    return preferHttps(trimmed);
  }
}
