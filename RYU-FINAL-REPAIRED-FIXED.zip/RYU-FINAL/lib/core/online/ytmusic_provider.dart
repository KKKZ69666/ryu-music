import '../utils/uri_utils.dart';
import '../models/song.dart';
import 'music_provider.dart';
import 'online_models.dart';
import 'package:dart_ytmusic_api/yt_music.dart';
import 'package:dart_ytmusic_api/types.dart'
    show SongDetailed, ArtistDetailed, AlbumDetailed, PlaylistDetailed, SongFull;

/// YouTube Music catalog integration. This provider exposes metadata only;
/// it never extracts, fabricates, or plays YouTube audio stream URLs.
class YTMusicProvider extends MusicProvider {
  final YTMusic _yt = YTMusic();
  bool _initialized = false;
  Future<YTMusic>? _initializing;

  @override
  String get id => 'ytmusic';
  @override
  String get displayName => 'Catalog';
  @override
  bool get isAvailable => true;
  @override
  String? get unavailableReason => null;
  @override
  bool get supportsDownload => false;
  @override
  String get licenseNote =>
      'Catalog metadata only; audio playback is not provided. dart_ytmusic_api is GPL-3.0.';

  Future<void> _ensureInit() async {
    if (_initialized) return;
    _initializing ??= _yt.initialize();
    try {
      await _initializing;
      _initialized = true;
    } finally {
      _initializing = null;
    }
  }

  static String? _thumbnail(List<dynamic> thumbnails) {
    if (thumbnails.isEmpty) return null;
    thumbnails.sort((a, b) {
      final dynamic x = a;
      final dynamic y = b;
      return ((y.width as int?) ?? 0).compareTo((x.width as int?) ?? 0);
    });
    final dynamic best = thumbnails.first;
    return UriUtils.preferHttpsNullable(best.url as String?);
  }

  static Song _song(dynamic item, {String provider = 'ytmusic'}) {
    final String videoId = item.videoId as String;
    final String title = (item.name as String?) ?? 'Unknown Title';
    final dynamic artist = item.artist;
    final dynamic album = item is SongDetailed ? item.album : null;
    final List<dynamic> thumbs = List<dynamic>.from(item.thumbnails as List);
    final duration = item.duration;
    return Song.online(
      provider: provider,
      remoteId: videoId,
      title: title,
      artist: (artist?.name as String?) ?? 'Unknown Artist',
      album: (album?.name as String?) ?? '',
      durationMs: duration is int ? duration * 1000 : 0,
      streamUrl: 'ytmusic://catalog/$videoId',
      artworkUrl: _thumbnail(thumbs),
    );
  }

  static PagedResult<T> _page<T>(List<T> values, int offset, int limit) {
    final safeOffset = offset.clamp(0, values.length).toInt();
    final end = (safeOffset + limit).clamp(safeOffset, values.length).toInt();
    return PagedResult(values.sublist(safeOffset, end), hasMore: end < values.length);
  }

  @override
  Future<PagedResult<Song>> searchTracks(String q, {int offset = 0, int limit = 20}) async {
    await _ensureInit();
    try {
      final results = await _yt.searchSongs(q);
      return _page(results.map((e) => _song(e)).toList(), offset, limit);
    } catch (e) {
      throw ProviderException('Catalog search failed: $e');
    }
  }

  Future<PagedResult<Song>> searchVideos(String q, {int offset = 0, int limit = 20}) async {
    await _ensureInit();
    try {
      final results = await _yt.searchVideos(q);
      return _page(results.map((e) => _song(e, provider: 'ytmusic_video')).toList(), offset, limit);
    } catch (e) {
      throw ProviderException('Catalog video search failed: $e');
    }
  }

  @override
  Future<PagedResult<OnlineArtist>> searchArtists(String q, {int offset = 0, int limit = 20}) async {
    await _ensureInit();
    try {
      final results = await _yt.searchArtists(q);
      final items = results.map((e) => OnlineArtist(
        provider: id, id: e.artistId, name: e.name,
        imageUrl: _thumbnail(List<dynamic>.from(e.thumbnails)),
      )).toList();
      return _page(items, offset, limit);
    } catch (e) {
      throw ProviderException('Catalog artist search failed: $e');
    }
  }

  @override
  Future<PagedResult<OnlineAlbum>> searchAlbums(String q, {int offset = 0, int limit = 20}) async {
    await _ensureInit();
    try {
      final results = await _yt.searchAlbums(q);
      final items = results.map((e) => OnlineAlbum(
        provider: id, id: e.albumId, name: e.name, artist: e.artist.name,
        imageUrl: _thumbnail(List<dynamic>.from(e.thumbnails)),
      )).toList();
      return _page(items, offset, limit);
    } catch (e) {
      throw ProviderException('Catalog album search failed: $e');
    }
  }

  @override
  Future<PagedResult<OnlinePlaylist>> searchPlaylists(String q, {int offset = 0, int limit = 20}) async {
    await _ensureInit();
    try {
      final results = await _yt.searchPlaylists(q);
      final items = results.map((e) => OnlinePlaylist(
        provider: id, id: e.playlistId, name: e.name, owner: e.artist.name,
        imageUrl: _thumbnail(List<dynamic>.from(e.thumbnails)),
      )).toList();
      return _page(items, offset, limit);
    } catch (e) {
      throw ProviderException('Catalog playlist search failed: $e');
    }
  }

  @override
  Future<List<Song>> artistTracks(OnlineArtist artist, {int limit = 50}) async {
    await _ensureInit();
    try {
      final songs = await _yt.getArtistSongs(artist.id);
      return songs.take(limit).map((e) => _song(e)).toList();
    } catch (e) {
      throw ProviderException('Catalog artist tracks failed: $e');
    }
  }

  @override
  Future<List<Song>> albumTracks(OnlineAlbum album) async {
    await _ensureInit();
    try {
      final result = await _yt.getAlbum(album.id);
      return result.songs.map((e) => _song(e)).toList();
    } catch (e) {
      throw ProviderException('Catalog album tracks failed: $e');
    }
  }

  @override
  Future<List<Song>> playlistTracks(OnlinePlaylist playlist) async {
    await _ensureInit();
    try {
      final videos = await _yt.getPlaylistVideos(playlist.id);
      return videos.map((e) => _song(e)).toList();
    } catch (e) {
      throw ProviderException('Catalog playlist tracks failed: $e');
    }
  }

  @override
  Future<List<Song>> trending({int limit = 20}) async {
    await _ensureInit();
    try {
      final sections = await _yt.getHomeSections();
      final songs = <Song>[];
      for (final section in sections) {
        for (final item in section.contents) {
          if (item is SongDetailed) songs.add(_song(item));
          if (songs.length >= limit) return songs;
        }
      }
      return songs;
    } catch (_) {
      return [];
    }
  }

  Future<List<String>> getSearchSuggestions(String query) async {
    if (query.trim().isEmpty) return [];
    await _ensureInit();
    try { return await _yt.getSearchSuggestions(query); } catch (_) { return []; }
  }

  /// Detail lookup intentionally returns typed metadata rather than raw maps.
  Future<SongFull?> getSongDetail(String videoId) async {
    await _ensureInit();
    try { return await _yt.getSong(videoId); } catch (_) { return null; }
  }

  Future<List<String>?> getLyrics(String videoId) async {
    await _ensureInit();
    try {
      final text = await _yt.getLyrics(videoId);
      if (text == null || text.trim().isEmpty) return null;
      return text.split('\n');
    } catch (_) { return null; }
  }

  /// The package returns a TimedLyricsRes object, not a list of maps.
  Future<List<Map<String, dynamic>>?> getTimedLyrics(String videoId) async {
    await _ensureInit();
    try {
      final result = await _yt.getTimedLyrics(videoId);
      if (result == null) return null;
      return result.timedLyricsData.map((line) => <String, dynamic>{
        'time': line.cueRange?.startTimeMilliseconds ?? 0,
        'text': line.lyricLine ?? '',
      }).toList();
    } catch (_) { return null; }
  }

  Future<List<Song>> getUpNexts(String videoId) async {
    await _ensureInit();
    try {
      final results = await _yt.getUpNexts(videoId);
      return results.map((e) => Song.online(
        provider: id,
        remoteId: e.videoId,
        title: e.title,
        artist: e.artists.name,
        album: e.album?.name ?? '',
        durationMs: e.duration * 1000,
        streamUrl: 'ytmusic://catalog/${e.videoId}',
        artworkUrl: _thumbnail(List<dynamic>.from(e.thumbnails)),
      )).toList();
    } catch (_) { return []; }
  }

  /// Convert typed HomeSection values into the small map contract consumed by HomeScreen.
  Future<List<Map<String, dynamic>>> getHomeSections() async {
    await _ensureInit();
    try {
      final sections = await _yt.getHomeSections();
      return sections.map((section) {
        final contents = <Map<String, dynamic>>[];
        for (final dynamic item in section.contents) {
          if (item is SongDetailed) {
            contents.add({'videoId': item.videoId, 'name': item.name,
              'artist': item.artist.name, 'thumbnails': item.thumbnails.map((t) => {'url': t.url, 'width': t.width}).toList()});
          } else if (item is ArtistDetailed) {
            contents.add({'artistId': item.artistId, 'name': item.name,
              'thumbnails': item.thumbnails.map((t) => {'url': t.url, 'width': t.width}).toList()});
          } else if (item is AlbumDetailed) {
            contents.add({'albumId': item.albumId, 'name': item.name, 'artist': item.artist.name,
              'thumbnails': item.thumbnails.map((t) => {'url': t.url, 'width': t.width}).toList()});
          } else if (item is PlaylistDetailed) {
            contents.add({'playlistId': item.playlistId, 'name': item.name, 'artist': item.artist.name,
              'thumbnails': item.thumbnails.map((t) => {'url': t.url, 'width': t.width}).toList()});
          }
        }
        return <String, dynamic>{'title': section.title, 'contents': contents};
      }).toList();
    } catch (_) { return []; }
  }

  Future<List<OnlineAlbum>> getArtistAlbums(String artistId) async {
    await _ensureInit();
    try {
      final results = await _yt.getArtistAlbums(artistId);
      return results.map((e) => OnlineAlbum(provider: id, id: e.albumId,
        name: e.name, artist: e.artist.name,
        imageUrl: _thumbnail(List<dynamic>.from(e.thumbnails)))).toList();
    } catch (_) { return []; }
  }

  Future<List<OnlineAlbum>> getArtistSingles(String artistId) async {
    await _ensureInit();
    try {
      final results = await _yt.getArtistSingles(artistId);
      return results.map((e) => OnlineAlbum(provider: id, id: e.albumId,
        name: e.name, artist: e.artist.name,
        imageUrl: _thumbnail(List<dynamic>.from(e.thumbnails)))).toList();
    } catch (_) { return []; }
  }

  static String shareUrl(String videoId) => 'https://music.youtube.com/watch?v=$videoId';
}
