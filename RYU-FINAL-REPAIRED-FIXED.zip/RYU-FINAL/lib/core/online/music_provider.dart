import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import '../models/song.dart';
import 'online_models.dart';

/// Contract every online source implements. Adding a provider = implement this
/// and register it in [ProviderHub].
abstract class MusicProvider {
  String get id;
  String get displayName;

  /// False when credentials are missing (e.g. no Jamendo client id).
  bool get isAvailable;
  String? get unavailableReason;

  /// True only if the provider's terms allow saving files for offline use.
  bool get supportsDownload;
  String get licenseNote;

  Future<PagedResult<Song>> searchTracks(String q,
      {int offset = 0, int limit = 20});
  Future<PagedResult<OnlineArtist>> searchArtists(String q,
      {int offset = 0, int limit = 20});
  Future<PagedResult<OnlineAlbum>> searchAlbums(String q,
      {int offset = 0, int limit = 20});
  Future<PagedResult<OnlinePlaylist>> searchPlaylists(String q,
      {int offset = 0, int limit = 20});

  Future<List<Song>> artistTracks(OnlineArtist artist, {int limit = 50});
  Future<List<Song>> albumTracks(OnlineAlbum album);
  Future<List<Song>> playlistTracks(OnlinePlaylist playlist);
  Future<List<Song>> trending({int limit = 20});
}

const kUserAgent = 'RYU-Music/1.0 (Android)';

/// Shared JSON GET with timeout and friendly errors.
Future<Map<String, dynamic>> getJson(Uri uri,
    {Duration timeout = const Duration(seconds: 12)}) async {
  try {
    final res = await http.get(uri, headers: const {
      'Accept': 'application/json',
      'User-Agent': kUserAgent,
    }).timeout(timeout);
    if (res.statusCode == 429) {
      throw ProviderException('Rate limited, try again shortly');
    }
    if (res.statusCode < 200 || res.statusCode >= 300) {
      throw ProviderException('Server error (${res.statusCode})');
    }
    final decoded = jsonDecode(utf8.decode(res.bodyBytes));
    if (decoded is Map<String, dynamic>) return decoded;
    throw ProviderException('Unexpected response');
  } on SocketException {
    throw ProviderException('No internet connection');
  } on TimeoutException {
    throw ProviderException('Connection timed out');
  } on http.ClientException {
    throw ProviderException('No internet connection');
  } on FormatException {
    throw ProviderException('Invalid server response');
  }
}
