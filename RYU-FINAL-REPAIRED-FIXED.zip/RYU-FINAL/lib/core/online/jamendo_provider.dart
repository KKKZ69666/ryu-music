import '../utils/uri_utils.dart';
import '../models/song.dart';
import 'music_provider.dart';
import 'online_models.dart';

/// Jamendo (https://developer.jamendo.com) — Creative Commons music.
/// Needs a client id supplied at build time:
///   flutter build apk --dart-define=JAMENDO_CLIENT_ID=xxxx
/// Without it the provider is disabled (never crashes the app).
class JamendoProvider extends MusicProvider {
  static const _clientId = String.fromEnvironment('JAMENDO_CLIENT_ID');
  static const _base = 'https://api.jamendo.com/v3.0';

  @override
  String get id => 'jamendo';
  @override
  String get displayName => 'Jamendo';
  @override
  bool get isAvailable => _clientId.isNotEmpty;
  @override
  String? get unavailableReason => isAvailable
      ? null
      : 'Jamendo is disabled: build with --dart-define=JAMENDO_CLIENT_ID=<your id>';
  @override
  bool get supportsDownload => true;
  @override
  String get licenseNote =>
      'Creative Commons tracks. Download only when Jamendo marks a track as downloadable; follow each track\'s CC license.';

  Future<Map<String, dynamic>> _api(String path, Map<String, String> q) {
    if (!isAvailable) throw ProviderException(unavailableReason!);
    return getJson(Uri.parse('$_base$path').replace(queryParameters: {
      'client_id': _clientId,
      'format': 'json',
      ...q,
    }));
  }

  /// Pure parser (unit-tested).
  static Song? parseTrack(Map<String, dynamic> t,
      {String? fallbackArtist, String? fallbackAlbum, String? fallbackImage}) {
    final tid = t['id']?.toString();
    final audio = t['audio'] as String?;
    if (tid == null || audio == null || audio.isEmpty) return null;
    final allowed = t['audiodownload_allowed'] == true;
    final dl = t['audiodownload'] as String?;
    final image = (t['image'] as String?)?.isNotEmpty == true
        ? t['image'] as String
        : (t['album_image'] as String?) ?? fallbackImage;
    return Song.online(
      provider: 'jamendo',
      remoteId: tid,
      title: (t['name'] as String?) ?? 'Unknown Title',
      artist: (t['artist_name'] as String?) ?? fallbackArtist ?? 'Unknown Artist',
      album: (t['album_name'] as String?) ?? fallbackAlbum ?? '',
      durationMs: ((t['duration'] as num?)?.toInt() ?? 0) * 1000,
      streamUrl: UriUtils.preferHttps(audio),
      artworkUrl: UriUtils.preferHttpsNullable(image),
      downloadUrl: (allowed && dl != null && dl.isNotEmpty)
          ? UriUtils.preferHttps(dl)
          : null,
    );
  }

  List<Song> _songs(Map<String, dynamic> json,
      {String? artist, String? album, String? image}) {
    return ((json['results'] as List?) ?? const [])
        .whereType<Map<String, dynamic>>()
        .map((m) => parseTrack(m,
            fallbackArtist: artist, fallbackAlbum: album, fallbackImage: image))
        .whereType<Song>()
        .toList();
  }

  Map<String, String> _page(int offset, int limit) =>
      {'limit': '$limit', 'offset': '$offset'};

  @override
  Future<PagedResult<Song>> searchTracks(String q,
      {int offset = 0, int limit = 20}) async {
    final json = await _api('/tracks/', {
      ..._page(offset, limit),
      'search': q,
      'include': 'musicinfo',
      'audioformat': 'mp32',
      'imagesize': '300',
    });
    final raw = (json['results'] as List?)?.length ?? 0;
    return PagedResult(_songs(json), hasMore: raw >= limit);
  }

  @override
  Future<PagedResult<OnlineArtist>> searchArtists(String q,
      {int offset = 0, int limit = 20}) async {
    final json = await _api(
        '/artists/', {..._page(offset, limit), 'namesearch': q, 'imagesize': '300'});
    final raw = ((json['results'] as List?) ?? const [])
        .whereType<Map<String, dynamic>>()
        .toList();
    return PagedResult(
      raw
          .map((a) => OnlineArtist(
                provider: id,
                id: a['id'].toString(),
                name: (a['name'] as String?) ?? 'Unknown',
                imageUrl: UriUtils.preferHttpsNullable(a['image'] as String?),
              ))
          .toList(),
      hasMore: raw.length >= limit,
    );
  }

  @override
  Future<PagedResult<OnlineAlbum>> searchAlbums(String q,
      {int offset = 0, int limit = 20}) async {
    final json = await _api(
        '/albums/', {..._page(offset, limit), 'namesearch': q, 'imagesize': '300'});
    final raw = ((json['results'] as List?) ?? const [])
        .whereType<Map<String, dynamic>>()
        .toList();
    return PagedResult(
      raw
          .map((a) => OnlineAlbum(
                provider: id,
                id: a['id'].toString(),
                name: (a['name'] as String?) ?? 'Album',
                artist: (a['artist_name'] as String?) ?? '',
                imageUrl: UriUtils.preferHttpsNullable(a['image'] as String?),
              ))
          .toList(),
      hasMore: raw.length >= limit,
    );
  }

  @override
  Future<PagedResult<OnlinePlaylist>> searchPlaylists(String q,
      {int offset = 0, int limit = 20}) async {
    final json =
        await _api('/playlists/', {..._page(offset, limit), 'namesearch': q});
    final raw = ((json['results'] as List?) ?? const [])
        .whereType<Map<String, dynamic>>()
        .toList();
    return PagedResult(
      raw
          .map((p) => OnlinePlaylist(
                provider: id,
                id: p['id'].toString(),
                name: (p['name'] as String?) ?? 'Playlist',
                owner: (p['user_name'] as String?) ?? '',
              ))
          .toList(),
      hasMore: raw.length >= limit,
    );
  }

  @override
  Future<List<Song>> artistTracks(OnlineArtist artist, {int limit = 50}) async {
    final json = await _api('/tracks/', {
      'artist_id': artist.id,
      'limit': '$limit',
      'audioformat': 'mp32',
      'imagesize': '300',
      'order': 'popularity_total',
    });
    return _songs(json, artist: artist.name);
  }

  List<Song> _nested(Map<String, dynamic> json,
      {String? album, String? image}) {
    final results = (json['results'] as List?) ?? const [];
    if (results.isEmpty || results.first is! Map<String, dynamic>) return [];
    final first = results.first as Map<String, dynamic>;
    final tracks = (first['tracks'] as List?) ?? const [];
    final artist = first['artist_name'] as String?;
    return tracks
        .whereType<Map<String, dynamic>>()
        .map((m) => parseTrack(m,
            fallbackArtist: artist,
            fallbackAlbum: album ?? first['name'] as String?,
            fallbackImage: image ?? first['image'] as String?))
        .whereType<Song>()
        .toList();
  }

  @override
  Future<List<Song>> albumTracks(OnlineAlbum album) async {
    final json = await _api('/albums/tracks/',
        {'id': album.id, 'audioformat': 'mp32', 'imagesize': '300'});
    return _nested(json, album: album.name, image: album.imageUrl);
  }

  @override
  Future<List<Song>> playlistTracks(OnlinePlaylist playlist) async {
    final json = await _api('/playlists/tracks/',
        {'id': playlist.id, 'audioformat': 'mp32', 'imagesize': '300'});
    return _nested(json);
  }

  @override
  Future<List<Song>> trending({int limit = 20}) async {
    final json = await _api('/tracks/', {
      'limit': '$limit',
      'order': 'popularity_week',
      'audioformat': 'mp32',
      'imagesize': '300',
    });
    return _songs(json);
  }
}
