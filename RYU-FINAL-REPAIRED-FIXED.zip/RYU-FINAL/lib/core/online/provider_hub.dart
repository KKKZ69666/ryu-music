import 'audius_provider.dart';
import 'jamendo_provider.dart';
import 'music_provider.dart';
import 'ytmusic_provider.dart';

/// Registry of all providers. Add new providers to [all].
class ProviderHub {
  ProviderHub._();
  static final ProviderHub instance = ProviderHub._();

  final List<MusicProvider> all = [
    YTMusicProvider(),
    AudiusProvider(),
    JamendoProvider(),
  ];

  List<MusicProvider> get available => all.where((p) => p.isAvailable).toList();

  MusicProvider? byId(String id) {
    for (final p in all) {
      if (p.id == id) return p;
    }
    return null;
  }

  /// Quick access to the catalog provider.
  YTMusicProvider? get catalog {
    for (final p in all) {
      if (p is YTMusicProvider) return p;
    }
    return null;
  }
}
