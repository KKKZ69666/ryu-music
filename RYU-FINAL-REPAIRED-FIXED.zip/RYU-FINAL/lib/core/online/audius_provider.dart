import '../utils/uri_utils.dart';
import '../models/song.dart';
import 'music_provider.dart';
import 'online_models.dart';

/// Audius (https://audius.org) — open music network. Streaming only: RYU does
/// not offer file download for Audius tracks.
class AudiusProvider extends MusicProvider {
  static const _app = 'RYU-Music';
  String? _host;

  @override
  String get id => 'audius';
  @override
  String get displayName => 'Audius';
  @override
  bool get isAvailable => true;
  @override
  String? get unavailableReason => null;
  @override
  bool get supportsDownload => false;
  @override
  String get licenseNote =>
      'Streaming only. Audius artists control their tracks; RYU does not download them.';

  Future<String> _discover({bool refresh = false}) async {
    if (_host != null && !refresh) return _host!;
    final json = await getJson(Uri.parse('https://api.audius.co'));
    final rawHosts = (json['data'] as List?)?.whereType<String>().toList() ?? [];
    final hosts = rawHosts
        .map(UriUtils.preferHttps)
        .where((h) => h.startsWith('https://'))
        .toList();
    if (hosts.isEmpty) throw ProviderException('Audius is unavailable');
    hosts.shuffle();
    return _host = hosts.first;
  }

  Future<Map<String, dynamic>> _api(String path, Map<String, String> q) async {
    for (var attempt = 0; attempt < 2; attempt++) {
      final host = await _discover(refresh: attempt > 0);
      try {
        return await getJson(Uri.parse('$host$path')
            .replace(queryParameters: {...q, 'app_name': _app}));
      } on ProviderException {
        if (attempt == 1) rethrow;
      }
    }
    throw ProviderException('Audius is unavailable');
  }

  /// Pure parser (unit-tested).
  static Song? parseTrack(Map<String, dynamic> t, String host) {
    final tid = t['id']?.toString();
    if (tid == null || tid.isEmpty) return null;
    if (t['is_streamable'] == false) return null;
    final access = t['access'];
    if (access is Map && access['stream'] == false) return null;
    final user = t['user'] as Map<String, dynamic>?;
    return Song.online(
      provider: 'audius',
      remoteId: tid,
      title: (t['title'] as String?) ?? 'Unknown Title',
      artist: (user?['name'] as String?) ?? 'Unknown Artist',
      album: '',
      durationMs: ((t['duration'] as num?)?.toInt() ?? 0) * 1000,
      streamUrl: UriUtils.preferHttps('$host/v1/tracks/$tid/stream?app_name=$_app'),
      artworkUrl: _art(t['artwork']),
    );
  }

  static String? _art(Object? a) {
    if (a is Map) {
      return UriUtils.preferHttpsNullable(
        (a['480x480'] ?? a['1000x1000'] ?? a['150x150']) as String?,
      );
    }
    return null;
  }

  Future<List<Song>> _tracks(Map<String, dynamic> json, String host) async {
    final data = (json['data'] as List?) ?? const [];
    return data
        .whereType<Map<String, dynamic>>()
        .map((m) => parseTrack(m, host))
        .whereType<Song>()
        .toList();
  }

  @override
  Future<PagedResult<Song>> searchTracks(String q,
      {int offset = 0, int limit = 20}) async {
    final json = await _api('/v1/tracks/search',
        {'query': q, 'limit': '$limit', 'offset': '$offset'});
    final items = await _tracks(json, await _discover());
    return PagedResult(items, hasMore: ((json['data'] as List?)?.length ?? 0) >= limit);
  }

  @override
  Future<PagedResult<OnlineArtist>> searchArtists(String q,
      {int offset = 0, int limit = 20}) async {
    final json = await _api('/v1/users/search',
        {'query': q, 'limit': '$limit', 'offset': '$offset'});
    final raw = (json['data'] as List?) ?? const [];
    final items = raw.whereType<Map<String, dynamic>>().map((u) {
      final pic = u['profile_picture'];
      return OnlineArtist(
        provider: id,
        id: u['id'].toString(),
        name: (u['name'] as String?) ?? (u['handle'] as String?) ?? 'Unknown',
        imageUrl: pic is Map
            ? UriUtils.preferHttpsNullable((pic['480x480'] ?? pic['150x150']) as String?)
            : null,
      );
    }).toList();
    return PagedResult(items, hasMore: raw.length >= limit);
  }

  Future<List<Map<String, dynamic>>> _playlistRows(String q, int offset,
      int limit, bool album) async {
    final json = await _api('/v1/playlists/search',
        {'query': q, 'limit': '$limit', 'offset': '$offset'});
    return ((json['data'] as List?) ?? const [])
        .whereType<Map<String, dynamic>>()
        .where((p) => (p['is_album'] == true) == album)
        .toList();
  }

  @override
  Future<PagedResult<OnlineAlbum>> searchAlbums(String q,
      {int offset = 0, int limit = 20}) async {
    final rows = await _playlistRows(q, offset, limit, true);
    return PagedResult(
      rows
          .map((p) => OnlineAlbum(
                provider: id,
                id: p['id'].toString(),
                name: (p['playlist_name'] as String?) ?? 'Album',
                artist: ((p['user'] as Map?)?['name'] as String?) ?? '',
                imageUrl: _art(p['artwork']),
              ))
          .toList(),
      hasMore: rows.length >= limit ~/ 2,
    );
  }

  @override
  Future<PagedResult<OnlinePlaylist>> searchPlaylists(String q,
      {int offset = 0, int limit = 20}) async {
    final rows = await _playlistRows(q, offset, limit, false);
    return PagedResult(
      rows
          .map((p) => OnlinePlaylist(
                provider: id,
                id: p['id'].toString(),
                name: (p['playlist_name'] as String?) ?? 'Playlist',
                owner: ((p['user'] as Map?)?['name'] as String?) ?? '',
                imageUrl: _art(p['artwork']),
              ))
          .toList(),
      hasMore: rows.length >= limit ~/ 2,
    );
  }

  @override
  Future<List<Song>> artistTracks(OnlineArtist artist, {int limit = 50}) async {
    final json = await _api('/v1/users/${artist.id}/tracks', {'limit': '$limit'});
    return _tracks(json, await _discover());
  }

  @override
  Future<List<Song>> albumTracks(OnlineAlbum album) async {
    final json = await _api('/v1/playlists/${album.id}/tracks', {});
    return _tracks(json, await _discover());
  }

  @override
  Future<List<Song>> playlistTracks(OnlinePlaylist playlist) async {
    final json = await _api('/v1/playlists/${playlist.id}/tracks', {});
    return _tracks(json, await _discover());
  }

  @override
  Future<List<Song>> trending({int limit = 20}) async {
    final json = await _api('/v1/tracks/trending', {'limit': '$limit'});
    return _tracks(json, await _discover());
  }
}
