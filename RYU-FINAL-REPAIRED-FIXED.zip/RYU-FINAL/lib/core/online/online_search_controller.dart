import 'dart:async';
import 'dart:convert';
import 'package:flutter/foundation.dart';
import '../models/song.dart';
import '../services/storage_service.dart';
import 'music_provider.dart';
import 'online_models.dart';
import 'provider_hub.dart';
import 'ytmusic_provider.dart';

enum OnlineSearchType { songs, videos, artists, albums, playlists }

/// Debounced, paginated, multi-provider search state.
class OnlineSearchController extends ChangeNotifier {
  OnlineSearchController({List<MusicProvider>? providers})
      : _providers = providers ?? ProviderHub.instance.all;

  final List<MusicProvider> _providers;
  static const pageSize = 20;

  String _query = '';
  OnlineSearchType _type = OnlineSearchType.songs;
  String? _providerFilter; // null = all
  OnlineSort _sort = OnlineSort.relevance;

  final List<Song> _songs = [];
  final List<OnlineVideo> _videos = [];
  final List<OnlineArtist> _artists = [];
  final List<OnlineAlbum> _albums = [];
  final List<OnlinePlaylist> _playlists = [];
  final List<Song> _trending = [];
  List<String> _suggestions = [];

  final Map<String, int> _offset = {};
  final Map<String, bool> _more = {};
  final Map<String, String> _errors = {};

  bool _loading = false;
  bool _loadingTrending = false;
  bool _loadingSuggestions = false;
  int _token = 0;
  Timer? _debounce;
  bool _disposed = false;

  String get query => _query;
  OnlineSearchType get type => _type;
  String? get providerFilter => _providerFilter;
  OnlineSort get sort => _sort;
  bool get loading => _loading;
  bool get loadingTrending => _loadingTrending;
  bool get loadingSuggestions => _loadingSuggestions;
  Map<String, String> get errors => Map.unmodifiable(_errors);
  List<MusicProvider> get providers => _providers;
  List<Song> get trending => List.unmodifiable(_trending);
  List<OnlineVideo> get videos => List.unmodifiable(_videos);
  List<OnlineArtist> get artists => List.unmodifiable(_artists);
  List<OnlineAlbum> get albums => List.unmodifiable(_albums);
  List<OnlinePlaylist> get playlists => List.unmodifiable(_playlists);
  List<String> get suggestions => List.unmodifiable(_suggestions);
  bool get hasMore => _active.any((p) => _more[p.id] ?? true) && _query.isNotEmpty;

  List<Song> get songs => sortSongs(_songs, _sort);

  int get resultCount => switch (_type) {
        OnlineSearchType.songs => _songs.length,
        OnlineSearchType.videos => _videos.length,
        OnlineSearchType.artists => _artists.length,
        OnlineSearchType.albums => _albums.length,
        OnlineSearchType.playlists => _playlists.length,
      };

  List<MusicProvider> get _active => _providers
      .where((p) => p.isAvailable && (_providerFilter == null || p.id == _providerFilter))
      .toList();

  @visibleForTesting
  static List<Song> sortSongs(List<Song> input, OnlineSort sort) {
    final l = List<Song>.from(input);
    switch (sort) {
      case OnlineSort.relevance:
        break;
      case OnlineSort.title:
        l.sort((a, b) => a.title.toLowerCase().compareTo(b.title.toLowerCase()));
      case OnlineSort.artist:
        l.sort((a, b) => a.artist.toLowerCase().compareTo(b.artist.toLowerCase()));
      case OnlineSort.shortest:
        l.sort((a, b) => a.durationMs.compareTo(b.durationMs));
      case OnlineSort.longest:
        l.sort((a, b) => b.durationMs.compareTo(a.durationMs));
    }
    return l;
  }

  /// Round-robin merge so one provider does not dominate the list.
  @visibleForTesting
  static List<T> interleave<T>(List<List<T>> lists) {
    final out = <T>[];
    var i = 0;
    var added = true;
    while (added) {
      added = false;
      for (final l in lists) {
        if (i < l.length) {
          out.add(l[i]);
          added = true;
        }
      }
      i++;
    }
    return out;
  }

  void _n() {
    if (!_disposed) notifyListeners();
  }

  void setQuery(String q) {
    _query = q.trim();
    _debounce?.cancel();
    if (_query.isEmpty) {
      _token++;
      _clearResults();
      _suggestions = [];
      _loading = false;
      _n();
      return;
    }
    _debounce = Timer(const Duration(milliseconds: 450), () {
      _fetchSuggestions();
      _search(reset: true);
    });
  }

  /// Run immediately (keyboard submit).
  void submit() {
    _debounce?.cancel();
    if (_query.isNotEmpty) {
      _fetchSuggestions();
      _search(reset: true);
    }
  }

  void setType(OnlineSearchType t) {
    if (_type == t) return;
    _type = t;
    if (_query.isNotEmpty) {
      _search(reset: true);
    } else {
      _n();
    }
  }

  void setProviderFilter(String? id) {
    if (_providerFilter == id) return;
    _providerFilter = id;
    if (_query.isNotEmpty) {
      _search(reset: true);
    } else {
      _n();
    }
  }

  void setSort(OnlineSort s) {
    _sort = s;
    _n();
  }

  void _clearResults() {
    _songs.clear();
    _videos.clear();
    _artists.clear();
    _albums.clear();
    _playlists.clear();
    _offset.clear();
    _more.clear();
    _errors.clear();
  }

  Future<void> loadMore() async {
    if (_loading || !hasMore) return;
    await _search(reset: false);
  }

  Future<void> retry() => _search(reset: true);

  Future<void> _search({required bool reset}) async {
    final token = ++_token;
    if (reset) _clearResults();
    _errors.clear();
    _loading = true;
    _n();

    final type = _type;
    final q = _query;
    final targets = _active.where((p) => _more[p.id] ?? true).toList();

    // Try cache for YTMusic on first page.
    if (reset) {
      for (final p in targets.whereType<YTMusicProvider>()) {
        final cached = await StorageService.instance.getSearchCache(q, type.name, p.id);
        if (cached != null && cached.isNotEmpty) {
          try {
            final decoded = jsonDecode(cached) as Map<String, dynamic>;
            final items = (decoded['items'] as List<dynamic>?) ?? [];
            final hasMore = (decoded['hasMore'] as bool?) ?? false;
            if (items.isNotEmpty) {
              switch (type) {
                case OnlineSearchType.songs:
                  _songs.addAll(items.map((e) => Song.fromMap(e)).whereType<Song>());
                case OnlineSearchType.videos:
                  _videos.addAll(items.map((e) => OnlineVideo(
                    provider: e['provider']?.toString() ?? 'ytmusic',
                    id: e['id']?.toString() ?? '',
                    title: e['title']?.toString() ?? '',
                    artist: e['artist']?.toString() ?? '',
                    durationMs: (e['durationMs'] as num?)?.toInt() ?? 0,
                    imageUrl: e['imageUrl']?.toString(),
                  )));
                case OnlineSearchType.artists:
                  _artists.addAll(items.map((e) => OnlineArtist(
                    provider: e['provider']?.toString() ?? 'ytmusic',
                    id: e['id']?.toString() ?? '',
                    name: e['name']?.toString() ?? '',
                    imageUrl: e['imageUrl']?.toString(),
                  )));
                case OnlineSearchType.albums:
                  _albums.addAll(items.map((e) => OnlineAlbum(
                    provider: e['provider']?.toString() ?? 'ytmusic',
                    id: e['id']?.toString() ?? '',
                    name: e['name']?.toString() ?? '',
                    artist: e['artist']?.toString() ?? '',
                    imageUrl: e['imageUrl']?.toString(),
                  )));
                case OnlineSearchType.playlists:
                  _playlists.addAll(items.map((e) => OnlinePlaylist(
                    provider: e['provider']?.toString() ?? 'ytmusic',
                    id: e['id']?.toString() ?? '',
                    name: e['name']?.toString() ?? '',
                    owner: e['owner']?.toString() ?? '',
                    imageUrl: e['imageUrl']?.toString(),
                  )));
              }
              _offset[p.id] = pageSize;
              _more[p.id] = hasMore;
            }
          } catch (_) {}
        }
      }
      final hadCache = _songs.isNotEmpty || _videos.isNotEmpty || _artists.isNotEmpty || _albums.isNotEmpty || _playlists.isNotEmpty;
      if (hadCache) {
        _loading = false;
        _n();
        // Still fetch fresh data below, but show cached results immediately.
      }
    }

    final batches = await Future.wait<(MusicProvider, PagedResult<Object>?, String?)>(targets.map((p) async {
      final off = _offset[p.id] ?? 0;
      try {
        // YTMusicProvider has native video search; others fall back to tracks.
        if (type == OnlineSearchType.videos && p is YTMusicProvider) {
          final PagedResult<Object> r = await p.searchVideos(q, offset: off, limit: pageSize);
          return (p, r, null);
        }
        final PagedResult<Object> r = switch (type) {
          OnlineSearchType.songs => await p.searchTracks(q, offset: off, limit: pageSize),
          OnlineSearchType.videos => await p.searchTracks(q, offset: off, limit: pageSize),
          OnlineSearchType.artists => await p.searchArtists(q, offset: off, limit: pageSize),
          OnlineSearchType.albums => await p.searchAlbums(q, offset: off, limit: pageSize),
          OnlineSearchType.playlists => await p.searchPlaylists(q, offset: off, limit: pageSize),
        };
        return (p, r, null);
      } catch (e) {
        return (p, null, e.toString());
      }
    }));

    if (token != _token || _disposed) return; // superseded by a newer search

    final songBatches = <List<Song>>[];
    final videoBatches = <List<OnlineVideo>>[];
    final artistBatches = <List<OnlineArtist>>[];
    final albumBatches = <List<OnlineAlbum>>[];
    final playlistBatches = <List<OnlinePlaylist>>[];
    for (final (p, r, err) in batches) {
      if (err != null || r == null) {
        _errors[p.id] = err ?? 'Unknown error';
        continue;
      }
      _offset[p.id] = (_offset[p.id] ?? 0) + pageSize;
      _more[p.id] = r.hasMore && r.items.isNotEmpty;
      switch (type) {
        case OnlineSearchType.songs:
          songBatches.add(r.items.cast<Song>());
        case OnlineSearchType.videos:
          if (p is YTMusicProvider) {
            videoBatches.add(r.items.cast<Song>().map((s) => OnlineVideo(
              provider: s.provider,
              id: s.remoteId ?? s.id.toString(),
              title: s.title,
              artist: s.artist,
              durationMs: s.durationMs,
              imageUrl: s.artworkUrl,
            )).toList());
          } else {
            songBatches.add(r.items.cast<Song>());
          }
        case OnlineSearchType.artists:
          artistBatches.add(r.items.cast<OnlineArtist>());
        case OnlineSearchType.albums:
          albumBatches.add(r.items.cast<OnlineAlbum>());
        case OnlineSearchType.playlists:
          playlistBatches.add(r.items.cast<OnlinePlaylist>());
      }
    }
    final seen = _songs.map((s) => s.id).toSet();
    _songs.addAll(interleave(songBatches).where((s) => seen.add(s.id)));
    _videos.addAll(interleave(videoBatches));
    _artists.addAll(interleave(artistBatches));
    _albums.addAll(interleave(albumBatches));
    _playlists.addAll(interleave(playlistBatches));
    _loading = false;
    _n();

    // Cache YTMusic first-page results.
    if (reset) {
      for (final (p, r, err) in batches) {
        if (err != null || r == null || r.items.isEmpty) continue;
        if (p is! YTMusicProvider) continue;
        try {
          final cacheData = {
            'items': r.items.map((e) {
              if (e is Song) {
                return {
                  ...e.toMap(),
                  'provider': e.provider,
                  'remoteId': e.remoteId,
                  'artworkUrl': e.artworkUrl,
                };
              } else if (e is OnlineArtist) {
                return {'provider': e.provider, 'id': e.id, 'name': e.name, 'imageUrl': e.imageUrl};
              } else if (e is OnlineAlbum) {
                return {'provider': e.provider, 'id': e.id, 'name': e.name, 'artist': e.artist, 'imageUrl': e.imageUrl};
              } else if (e is OnlinePlaylist) {
                return {'provider': e.provider, 'id': e.id, 'name': e.name, 'owner': e.owner, 'imageUrl': e.imageUrl};
              }
              return {};
            }).toList(),
            'hasMore': r.hasMore,
          };
          await StorageService.instance.setSearchCache(q, type.name, p.id, jsonEncode(cacheData));
        } catch (_) {}
      }
    }
  }

  /// Discovery content shown before the user types (only what providers return).
  Future<void> loadTrending() async {
    if (_loadingTrending) return;
    _loadingTrending = true;
    _n();
    final lists = await Future.wait(_providers.where((p) => p.isAvailable).map((p) async {
      try {
        return await p.trending(limit: 12);
      } catch (_) {
        return <Song>[];
      }
    }));
    _trending
      ..clear()
      ..addAll(interleave(lists));
    _loadingTrending = false;
    _n();
  }

  /// Fetch search suggestions from the catalog provider.
  Future<void> _fetchSuggestions() async {
    final catalog = ProviderHub.instance.catalog;
    if (catalog == null || _query.isEmpty) return;
    _loadingSuggestions = true;
    _n();
    try {
      final suggs = await catalog.getSearchSuggestions(_query);
      if (!_disposed) {
        _suggestions = suggs;
        _loadingSuggestions = false;
        _n();
      }
    } catch (_) {
      _loadingSuggestions = false;
      _n();
    }
  }

  /// Clear suggestions.
  void clearSuggestions() {
    _suggestions = [];
    _n();
  }

  @override
  void dispose() {
    _disposed = true;
    _debounce?.cancel();
    super.dispose();
  }
}
