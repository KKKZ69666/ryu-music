class OnlineArtist {
  const OnlineArtist({
    required this.provider,
    required this.id,
    required this.name,
    this.imageUrl,
  });
  final String provider;
  final String id;
  final String name;
  final String? imageUrl;
}

class OnlineAlbum {
  const OnlineAlbum({
    required this.provider,
    required this.id,
    required this.name,
    this.artist = '',
    this.imageUrl,
  });
  final String provider;
  final String id;
  final String name;
  final String artist;
  final String? imageUrl;
}

class OnlinePlaylist {
  const OnlinePlaylist({
    required this.provider,
    required this.id,
    required this.name,
    this.owner = '',
    this.imageUrl,
  });
  final String provider;
  final String id;
  final String name;
  final String owner;
  final String? imageUrl;
}

class OnlineVideo {
  const OnlineVideo({
    required this.provider,
    required this.id,
    required this.title,
    this.artist = '',
    this.durationMs = 0,
    this.imageUrl,
  });
  final String provider;
  final String id;
  final String title;
  final String artist;
  final int durationMs;
  final String? imageUrl;
}

class PagedResult<T> {
  const PagedResult(this.items, {required this.hasMore});
  final List<T> items;
  final bool hasMore;
}

enum OnlineSort {
  relevance('Relevance'),
  title('Title A–Z'),
  artist('Artist A–Z'),
  shortest('Shortest'),
  longest('Longest');

  const OnlineSort(this.label);
  final String label;
}

class ProviderException implements Exception {
  ProviderException(this.message);
  final String message;
  @override
  String toString() => message;
}
