# RYU Music — Progress

Base: `ryu-fixed.zip` (pre-Stage-A). All features below were implemented in ONE pass on top of it.

## Verification status (honest)
The authoring sandbox had **no Flutter/Dart SDK and no network**. Therefore:
- `flutter pub get`, `flutter analyze`, `flutter test` and the APK build were **NOT run**.
- Nothing has been executed on a device. Everything is statically reviewed only.
- `.github/workflows/build.yml` runs analyze (errors+warnings are blocking; infos are not), test and
  `flutter build apk --release`, and uploads logs + APK. Run it first and fix whatever it reports.

## Implemented (code written, unverified)
- SQLite (`StorageService`): schema v2, non-destructive SharedPreferences migration, fallback to prefs if DB fails.
- Unified `Song` (local + online): `provider`, `remoteId`, `key`, stable negative int ids for online tracks.
- Providers: `MusicProvider` interface, Audius (stream only), Jamendo (needs `--dart-define=JAMENDO_CLIENT_ID`; download only if track allows).
- Online search UI: debounce, songs/artists/albums/playlists, source filter, sort, infinite scroll, recent searches, trending, error/empty/loading states, artist/album/playlist detail pages.
- Streaming through just_audio; online artwork in lists/notification.
- Downloads: queue (2 parallel), progress, pause/resume (HTTP Range), cancel, retry, delete, size, integrity check, offline playback (file:// preferred when present).
- Lyrics: LRCLIB auto-fetch while playing (title+artist+duration), SQLite cache, 7-day "not found" cache, manual picker of matches, import/paste still work, offset + text size settings.
- Player: resume last session, volume, listening tracker (audible time).
- Library: saved online songs, online favorites/playlists (mixed with local).
- Analytics: real listening events; top tracks/artists; day/week/month bar charts.
- Settings ("More" tab): volume, resume, lyrics options, rescan, backup export/import (JSON via system file dialogs), clear history/searches/artwork cache/downloads.
- Android: new native channels `pickTextFile`, `saveTextFile`; app label "RYU Music".
- Tests: `test/online_test.dart` (parsers, ids, sort, interleave, analytics buckets, LRCLIB candidate).

## Known limitations
- Light mode / accent color: NOT implemented (UI uses fixed dark palette constants). Not shown in settings.
- Crossfade: unsupported by engine. Gapless: ExoPlayer default.
- Downloads only run while the app is alive (no background service).
- Audius: streaming only. Provider APIs were not exercised against live servers.
- Dynamic artwork color for online tracks: fallback palette.
- Release APK is signed with the debug key (as before).

## Audit fixes applied (5 fixes in source)
1. **Dart Analyzer closure parameter cleanup (`duplicate_definition` / `unnecessary_underscores`)**: Replaced repeated `_`/`__`/`___` closure parameters with explicit parameter names across `home_screen.dart`, `artist_detail_screen.dart`, `online_search_screen.dart`, `now_playing_screen.dart`, `queue_sheet.dart`, `artwork_image.dart`, and `song_options_sheet.dart`.
2. **HTTPS prioritization without global cleartext traffic (`AndroidManifest.xml`, `UriUtils`, `Song`, `AudiusProvider`, `JamendoProvider`, `AudioController`, `DownloadManager`, `ArtworkImage`, `OnlineSearchScreen`)**: Kept `android:usesCleartextTraffic="false"` and upgraded remote `http://` discovery, streaming, download, and artwork URLs to `https://`.
3. **GitHub Actions & Gradle Wrapper hardening (`.github/workflows/build.yml`, `build_apk.sh`, `android/gradlew`, `android/gradlew.bat`)**: Added `main`/`master` branch triggers, `set -o pipefail` on blocking `tee` steps, non-destructive Gradle wrapper bootstrap, and clean Gradle 8.7 POSIX `gradlew`.
4. **Audio playback & interruption resilience (`AudioController`)**: Restored user-configured volume (`AppSettings.instance.volume`) after audio ducking and normalized online playback/artwork URIs to HTTPS.
5. **Download cancellation & mixed library support (`DownloadManager`, `PlaylistDetailScreen`, `StorageService`)**: Closed active HTTP clients immediately on pause/cancel/deleteAll, included saved online tracks in the playlist song picker, and preserved negative online song IDs in legacy favorites fallback.
