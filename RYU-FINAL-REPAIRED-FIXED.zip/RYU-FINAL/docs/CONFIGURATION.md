# Configuration

## Jamendo client id
Never commit it. Local: `flutter run --dart-define=JAMENDO_CLIENT_ID=<id>`.
CI: add repository secret `JAMENDO_CLIENT_ID` (workflow passes it via `--dart-define`).
Without it Jamendo shows as disabled; Audius still works.

## Build
`flutter pub get && flutter analyze && flutter test && flutter build apk --release --dart-define=JAMENDO_CLIENT_ID=...`
Use a development branch (e.g. `dev/ryu-music`); do not overwrite `main`/`ryu-online-test`.

## Dependencies added
sqflite, path (plus existing just_audio, just_audio_background, audio_session, http, path_provider, shared_preferences, permission_handler, google_fonts).
