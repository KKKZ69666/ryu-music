import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/models/song.dart';
import '../../core/online/online_models.dart';
import '../../core/online/provider_hub.dart';
import '../../core/online/ytmusic_provider.dart';
import '../../core/ryu_scope.dart';
import '../../core/theme/ryu_colors.dart';
import '../../shared/widgets/online_song_tile.dart';

class OnlineDetailScreen extends StatefulWidget {
  const OnlineDetailScreen._({required this.mode, this.artist, this.album, this.playlist});

  factory OnlineDetailScreen.artist(OnlineArtist a) => OnlineDetailScreen._(mode: OnlineDetailMode.artist, artist: a);
  factory OnlineDetailScreen.album(OnlineAlbum a) => OnlineDetailScreen._(mode: OnlineDetailMode.album, album: a);
  factory OnlineDetailScreen.playlist(OnlinePlaylist p) => OnlineDetailScreen._(mode: OnlineDetailMode.playlist, playlist: p);

  final OnlineDetailMode mode;
  final OnlineArtist? artist;
  final OnlineAlbum? album;
  final OnlinePlaylist? playlist;

  @override
  State<OnlineDetailScreen> createState() => _OnlineDetailScreenState();
}

enum OnlineDetailMode { artist, album, playlist }

class _OnlineDetailScreenState extends State<OnlineDetailScreen> {
  final List<Song> _songs = [];
  bool _loading = true;
  String? _error;
  List<OnlineAlbum> _artistAlbums = [];
  List<OnlineAlbum> _artistSingles = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final provider = ProviderHub.instance.byId(_providerId);
      if (provider == null) {
        setState(() => _error = 'Provider unavailable');
        return;
      }
      switch (widget.mode) {
        case OnlineDetailMode.artist:
          final results = await provider.artistTracks(widget.artist!, limit: 50);
          if (provider is YTMusicProvider) {
            final albums = await provider.getArtistAlbums(widget.artist!.id);
            final singles = await provider.getArtistSingles(widget.artist!.id);
            setState(() {
              _songs.addAll(results);
              _artistAlbums = albums;
              _artistSingles = singles;
              _loading = false;
            });
          } else {
            setState(() {
              _songs.addAll(results);
              _loading = false;
            });
          }
        case OnlineDetailMode.album:
          final results = await provider.albumTracks(widget.album!);
          setState(() {
            _songs.addAll(results);
            _loading = false;
          });
        case OnlineDetailMode.playlist:
          final results = await provider.playlistTracks(widget.playlist!);
          setState(() {
            _songs.addAll(results);
            _loading = false;
          });
      }
    } catch (e) {
      setState(() {
        _error = e.toString();
        _loading = false;
      });
    }
  }

  String get _providerId {
    switch (widget.mode) {
      case OnlineDetailMode.artist:
        return widget.artist!.provider;
      case OnlineDetailMode.album:
        return widget.album!.provider;
      case OnlineDetailMode.playlist:
        return widget.playlist!.provider;
    }
  }

  bool get _isCatalog => _providerId == 'ytmusic' || _providerId == 'ytmusic_video';

  @override
  Widget build(BuildContext context) {
    final scope = RyuScope.of(context);
    String title;
    String subtitle;
    String? imageUrl;
    switch (widget.mode) {
      case OnlineDetailMode.artist:
        title = widget.artist!.name;
        subtitle = 'Artist';
        imageUrl = widget.artist!.imageUrl;
      case OnlineDetailMode.album:
        title = widget.album!.name;
        subtitle = widget.album!.artist;
        imageUrl = widget.album!.imageUrl;
      case OnlineDetailMode.playlist:
        title = widget.playlist!.name;
        subtitle = widget.playlist!.owner.isNotEmpty ? widget.playlist!.owner : 'Playlist';
        imageUrl = widget.playlist!.imageUrl;
    }

    final playableSongs = _songs.where((s) => s.isPlayable).toList();

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar.large(
            pinned: true,
            title: Text(title),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (imageUrl != null)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(16),
                      child: SizedBox(
                        width: 180,
                        height: 180,
                        child: Image.network(imageUrl,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) =>
                                Container(color: RyuColors.surfaceHigh)),
                      ),
                    ),
                  const SizedBox(height: 12),
                  Text(title,
                      style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
                  Text(subtitle,
                      style: const TextStyle(color: RyuColors.textSecondary, fontSize: 14)),
                  const SizedBox(height: 12),
                  Wrap(spacing: 8, children: [
                    if (playableSongs.isNotEmpty)
                      ElevatedButton.icon(
                        onPressed: () => scope.audio.playSongs(playableSongs,
                            contextLabel: title),
                        icon: const Icon(Icons.play_arrow_rounded),
                        label: const Text('Shuffle all'),
                      )
                    else if (_isCatalog)
                      ElevatedButton.icon(
                        onPressed: () async {
                          final id = widget.mode == OnlineDetailMode.artist
                              ? widget.artist?.id
                              : widget.mode == OnlineDetailMode.album
                                  ? widget.album?.id
                                  : widget.playlist?.id;
                          if (id != null && id.isNotEmpty) {
                            final url = Uri.parse(YTMusicProvider.shareUrl(id));
                            if (await canLaunchUrl(url)) {
                              await launchUrl(url, mode: LaunchMode.externalApplication);
                            }
                          }
                        },
                        icon: const Icon(Icons.open_in_new_rounded),
                        label: const Text('Open in service'),
                      ),
                  ]),
                  if (_isCatalog)
                    const Padding(
                      padding: EdgeInsets.only(top: 8),
                      child: Text(
                        'Some tracks may not be playable in RYU. '
                        'Catalog metadata is displayed for discovery.',
                        style: TextStyle(color: RyuColors.textSecondary, fontSize: 12),
                      ),
                    ),
                ],
              ),
            ),
          ),
          if (_loading)
            const SliverToBoxAdapter(
                child: Padding(
                    padding: EdgeInsets.all(32),
                    child: Center(child: CircularProgressIndicator())))
          else if (_error != null)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: RyuColors.surface,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(children: [
                    const Icon(Icons.wifi_off_rounded, color: RyuColors.textSecondary),
                    const SizedBox(width: 12),
                    Expanded(child: Text(_error!, style: const TextStyle(color: RyuColors.textSecondary))),
                    TextButton(onPressed: _load, child: const Text('Retry')),
                  ]),
                ),
              ),
            )
          else
            SliverList.builder(
              itemCount: _songs.length,
              itemBuilder: (_, i) {
                final s = _songs[i];
                return OnlineSongTile(
                  song: s,
                  onTap: () {
                    if (s.isPlayable) {
                      scope.audio.playSongs(_songs, initialIndex: i, contextLabel: title);
                    } else {
                      _showCatalogSheet(context, s);
                    }
                  },
                );
              },
            ),
          if (_artistAlbums.isNotEmpty) ...[
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(20, 24, 20, 8),
                child: Text('Albums',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              ),
            ),
            SliverList.builder(
              itemCount: _artistAlbums.length,
              itemBuilder: (_, i) {
                final a = _artistAlbums[i];
                return ListTile(
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => OnlineDetailScreen.album(a))),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: SizedBox(
                      width: 56,
                      height: 56,
                      child: a.imageUrl == null
                          ? Container(color: RyuColors.surfaceHigh)
                          : Image.network(a.imageUrl!,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) =>
                                  Container(color: RyuColors.surfaceHigh)),
                    ),
                  ),
                  title: Text(a.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(a.artist,
                      style: const TextStyle(color: RyuColors.textSecondary, fontSize: 12.5)),
                  trailing: const Icon(Icons.chevron_right_rounded, color: RyuColors.textSecondary),
                );
              },
            ),
          ],
          if (_artistSingles.isNotEmpty) ...[
            const SliverToBoxAdapter(
              child: Padding(
                padding: EdgeInsets.fromLTRB(20, 24, 20, 8),
                child: Text('Singles',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
              ),
            ),
            SliverList.builder(
              itemCount: _artistSingles.length,
              itemBuilder: (_, i) {
                final a = _artistSingles[i];
                return ListTile(
                  onTap: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => OnlineDetailScreen.album(a))),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 2),
                  leading: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: SizedBox(
                      width: 56,
                      height: 56,
                      child: a.imageUrl == null
                          ? Container(color: RyuColors.surfaceHigh)
                          : Image.network(a.imageUrl!,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) =>
                                  Container(color: RyuColors.surfaceHigh)),
                    ),
                  ),
                  title: Text(a.name, maxLines: 1, overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text(a.artist,
                      style: const TextStyle(color: RyuColors.textSecondary, fontSize: 12.5)),
                  trailing: const Icon(Icons.chevron_right_rounded, color: RyuColors.textSecondary),
                );
              },
            ),
          ],
          const SliverToBoxAdapter(child: SizedBox(height: 120)),
        ],
      ),
    );
  }

  void _showCatalogSheet(BuildContext context, Song song) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: RyuColors.surfaceHigh,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 36,
                    height: 4,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.25),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  song.title,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                ),
                const SizedBox(height: 4),
                Text(
                  song.artist,
                  style: const TextStyle(color: RyuColors.textSecondary, fontSize: 14),
                ),
                const SizedBox(height: 16),
                const Text(
                  'Audio playback is not available for this track in RYU. '
                  'You can open it in the official service.',
                  style: TextStyle(color: RyuColors.textSecondary, fontSize: 13),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () async {
                          Navigator.pop(ctx);
                          final url = Uri.parse(YTMusicProvider.shareUrl(song.remoteId ?? ''));
                          if (await canLaunchUrl(url)) {
                            await launchUrl(url, mode: LaunchMode.externalApplication);
                          }
                        },
                        icon: const Icon(Icons.open_in_new_rounded, size: 18),
                        label: const Text('Open in service'),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton(
                        onPressed: () => Navigator.pop(ctx),
                        child: const Text('Close'),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
