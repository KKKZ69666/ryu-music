import 'package:flutter_test/flutter_test.dart';
import 'package:ryu/core/models/song.dart';
import 'package:ryu/core/online/online_models.dart';
import 'package:ryu/core/online/online_search_controller.dart';
import 'package:ryu/core/online/music_provider.dart';
import 'package:ryu/core/online/ytmusic_provider.dart';
import 'package:ryu/core/online/saavn_provider.dart';

class _FakeProvider extends MusicProvider {
  final String _id;
  _FakeProvider(this._id);

  @override
  String get id => _id;
  @override
  String get displayName => _id;
  @override
  bool get isAvailable => true;
  @override
  String? get unavailableReason => null;
  @override
  bool get supportsDownload => false;
  @override
  String get licenseNote => '';

  @override
  Future<PagedResult<Song>> searchTracks(String q, {int offset = 0, int limit = 20}) async {
    final songs = List.generate(limit, (i) => Song.online(
      provider: id,
      remoteId: '${id}_$i',
      title: '$q song ${offset + i}',
      artist: 'Artist',
      durationMs: 180000,
      streamUrl: 'https://example.com/audio.mp3',
    ));
    return PagedResult(songs, hasMore: true);
  }

  @override
  Future<PagedResult<OnlineArtist>> searchArtists(String q, {int offset = 0, int limit = 20}) async =>
      const PagedResult([], hasMore: false);

  @override
  Future<PagedResult<OnlineAlbum>> searchAlbums(String q, {int offset = 0, int limit = 20}) async =>
      const PagedResult([], hasMore: false);

  @override
  Future<PagedResult<OnlinePlaylist>> searchPlaylists(String q, {int offset = 0, int limit = 20}) async =>
      const PagedResult([], hasMore: false);

  @override
  Future<List<Song>> artistTracks(OnlineArtist a, {int limit = 50}) async => [];
  @override
  Future<List<Song>> albumTracks(OnlineAlbum a) async => [];
  @override
  Future<List<Song>> playlistTracks(OnlinePlaylist p) async => [];
  @override
  Future<List<Song>> trending({int limit = 20}) async => [];
}

void main() {
  test('JioSaavn parser only marks real HTTPS CDN streams playable', () {
    final song = SaavnProvider.songFromJson({
      'id': 'saavn-123',
      'name': 'Example Track',
      'duration': '205',
      'artists': {
        'primary': [
          {'name': 'Example Artist'}
        ]
      },
      'album': {'name': 'Example Album'},
      'image': [
        {'url': 'https://cdn.example/art-50.jpg'},
        {'url': 'https://cdn.example/art-500.jpg'}
      ],
      'downloadUrl': [
        {'quality': '96kbps', 'url': 'https://cdn.example/audio-96.mp4'},
        {'quality': '320kbps', 'url': 'https://cdn.example/audio-320.mp4'}
      ],
    });

    expect(song, isNotNull);
    expect(song!.isPlayable, isTrue);
    expect(song.uri, 'https://cdn.example/audio-320.mp4');
    expect(song.durationMs, 205000);
    expect(song.artist, 'Example Artist');
    expect(song.artworkUrl, 'https://cdn.example/art-500.jpg');
  });

  test('JioSaavn parser rejects metadata without an actual stream URL', () {
    final song = SaavnProvider.songFromJson({
      'id': 'catalog-only',
      'name': 'Metadata Only',
      'artists': {'primary': []},
      'downloadUrl': [],
    });
    expect(song, isNotNull);
    expect(song!.isPlayable, isFalse);
    expect(
      SaavnProvider.playableUrl([
        {'quality': '320kbps', 'url': 'http://insecure.example/audio.mp3'}
      ]),
      isNull,
    );
  });

  group('OnlineSearchController', () {
    test('debounce and search', () async {
      final ctrl = OnlineSearchController(providers: [_FakeProvider('a')]);
      ctrl.setQuery('hello');
      await Future.delayed(const Duration(milliseconds: 600));
      expect(ctrl.resultCount, greaterThan(0));
      ctrl.dispose();
    });

    test('interleave', () {
      final a = [1, 2, 3];
      final b = [10, 20];
      expect(OnlineSearchController.interleave([a, b]), [1, 10, 2, 20, 3]);
    });

    test('sort', () {
      final songs = [
        Song.online(provider: 'x', remoteId: '1', title: 'Beta', artist: 'Z', durationMs: 200, streamUrl: 'https://example.com/beta.mp3'),
        Song.online(provider: 'x', remoteId: '2', title: 'Alpha', artist: 'A', durationMs: 100, streamUrl: 'https://example.com/alpha.mp3'),
      ];
      final sorted = OnlineSearchController.sortSongs(songs, OnlineSort.title);
      expect(sorted.first.title, 'Alpha');
    });
  });

  group('YTMusicProvider', () {
    test('id and displayName', () {
      final p = YTMusicProvider();
      expect(p.id, 'ytmusic');
      expect(p.displayName, 'Catalog');
      expect(p.supportsDownload, false);
    });

    test('Song isPlayable for catalog tracks', () {
      final catalogSong = Song.online(
        provider: 'ytmusic',
        remoteId: 'abc123',
        title: 'Test',
        artist: 'Artist',
        streamUrl: 'ytmusic://catalog/abc123',
      );
      expect(catalogSong.isPlayable, false);
      expect(catalogSong.catalogUrl, 'https://music.youtube.com/watch?v=abc123');
    });

    test('Song isPlayable for direct stream tracks', () {
      final streamSong = Song.online(
        provider: 'stream',
        remoteId: 'xyz',
        title: 'Test',
        artist: 'Artist',
        streamUrl: 'https://example.com/stream.mp3',
      );
      expect(streamSong.isPlayable, true);
    });
  });

  group('OnlineModels', () {
    test('OnlineVideo equality by fields', () {
      const v1 = OnlineVideo(provider: 'ytmusic', id: '1', title: 'T', artist: 'A');
      const v2 = OnlineVideo(provider: 'ytmusic', id: '1', title: 'T', artist: 'A');
      expect(v1.title, v2.title);
    });
  });
}
