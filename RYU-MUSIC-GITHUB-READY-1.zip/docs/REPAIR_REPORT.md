# RYU repair report

## Source

This repair modifies the supplied `RYU-YOUTUBE-INAPP-PLAYER-FIXED-1.zip` project in place. It is not a new Flutter project.

## Changes

- Added `SaavnProvider` with JioSaavn community API primary and fallback hosts.
- Added normalized mapping for song title, artist, album, duration, artwork, and actual stream URLs.
- Only actual HTTPS URLs returned by the API are treated as playable. Metadata-only songs receive a non-HTTP catalog marker and are rejected by `Song.isPlayable`.
- Registered JioSaavn and YouTube Music in the shared `ProviderHub`; the existing search controller merges both providers, applies per-provider timeout handling, and deduplicates by identity and normalized title/artist.
- Kept YouTube Music strictly metadata-only and removed `youtube_player_iframe` dependency and its player screen. Catalog entries no longer open YouTube or an external player.
- Fixed initial queue selection when non-playable catalog-only entries are filtered from a mixed result list.
- Tightened `Song.isPlayable` to require a valid HTTP(S) URI for online tracks and corrected numeric clamp conversions used by player, settings, progress, and queue indexes.
- Preserved the existing `just_audio`, `just_audio_background`, queue, shuffle, repeat, progress, Android media notification, library, favorites, playlists, history, and LRCLIB code.
- Added offline fixture tests for JioSaavn parsing and rejection of absent/insecure stream URLs.
- Updated project documentation to state provider limitations and verification status.
- Hardened the GitHub Actions workflow: read-only permissions, all-branch push/PR/manual triggers, Java 17 + Flutter stable, wrapper-JAR bootstrap without replacing the Android project, blocking analyze/test/build steps, and artifact upload for the APK and resolved lockfile.
- Updated Android Gradle Plugin from 8.5.2 to 8.6.1 to align compileSdk 35 support with Gradle 8.7.
- Added `docs/GITHUB_CI.md` with repository-root import instructions and production-signing caveats.

## Providers actually integrated in source

| Provider | Search/catalog | Direct audio URL | Role |
|---|---:|---:|---|
| JioSaavn community API (`saavn.dev`, fallback `saavn.sumit.co`) | Yes | Parsed from returned `downloadUrl[]` when present | Search + internal stream source |
| YouTube Music (`dart_ytmusic_api`) | Yes | No | Metadata/catalog only |
| LRCLIB | Lyrics lookup | Not applicable | Plain and synced lyrics |

Audius and Jamendo are not used.

## Validation performed

- ZIP extracted and project structure reviewed.
- Dart source and provider/playback integration paths inspected.
- Added local fixture tests for provider response mapping, selecting the highest advertised quality HTTPS stream, and rejecting metadata-only/insecure URLs.
- Android manifest XML parsed successfully.
- YAML configuration files parsed successfully.
- Relative Dart imports checked against files in the project.
- Confirmed no remaining `youtube_player_iframe` references in app source after removing the player.

## Not performed / not verified

- Flutter/Dart SDK is absent in this environment: `flutter analyze`, `flutter test`, and `flutter build apk --release` could not run.
- No APK was generated.
- Network requests to the community API hosts could not be made from this environment.
- No Android emulator/device was available to test real stream decoding, background playback, notification controls, queue transitions, or LRCLIB synchronization.
- Consequently, integration is implemented in source but **actual online playback remains unverified**. A real device test is required; APK build status and playback status must be reported separately.

## Distribution note

`dart_ytmusic_api` and community API services have their own licenses/terms and may change. Review their terms and the package's GPL-3.0 obligations before distributing a binary.


## GitHub readiness caveats

- The ZIP is prepared with repository files at its root (rather than nested under a second project directory).
- `pubspec.lock` is not included because dependency resolution could not be run without Flutter/Dart. CI generates it and uploads it as an artifact; commit the reviewed lockfile from a successful run for reproducible dependency resolution.
- `android/gradle/wrapper/gradle-wrapper.jar` is not included. The workflow generates this missing binary wrapper file from the Flutter SDK while preserving the project's existing wrapper properties and Android Gradle files.
- Release-mode APKs currently use the debug signing configuration and are for testing only, not store publication.
- No GitHub repository URL or authorization was supplied, so no remote branch was accessed or changed. The workflow itself has read-only permissions and performs no git push.
