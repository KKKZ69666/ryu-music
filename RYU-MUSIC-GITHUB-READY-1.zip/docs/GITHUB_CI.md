# GitHub CI handoff

- Workflow: `.github/workflows/build.yml`
- Triggers: every branch push, pull request, and manual `workflow_dispatch`.
- Permissions: read-only repository contents.
- It does not push commits, create tags, merge pull requests, or alter `main`.
- Toolchain: GitHub-hosted Ubuntu, Java 17, Flutter stable.
- Checks: `flutter pub get`, `flutter analyze`, `flutter test --reporter expanded`, and `flutter build apk --release`.
- Artifacts: installable test APK and the generated `pubspec.lock` when the build succeeds.
- If the wrapper JAR is absent, CI creates only that binary wrapper file from a temporary Flutter-created Android project; it does not replace the RYU Android project.

## Important release caveat

`android/app/build.gradle.kts` currently signs release-mode builds with the debug signing config. This is suitable only for CI/device testing, not Play Store or production distribution. Add a private keystore using GitHub Actions secrets and configure release signing before publishing.

## Current verification status

This source preparation environment has no Flutter or Dart executable. The workflow has been authored and its YAML syntax is checked locally, but GitHub Actions has not been run from this session. No successful analyze/test/APK result is claimed.
