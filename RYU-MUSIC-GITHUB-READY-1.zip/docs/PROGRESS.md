# Project progress and verification

## Online catalog, playable audio, and lyrics

- Search merges JioSaavn community API results with YouTube Music catalog metadata.
- JioSaavn adapter reads actual HTTPS CDN stream URLs from `downloadUrl`; a result without a real URL remains metadata-only and is rejected by `Song.isPlayable`.
- `saavn.dev` is the primary API endpoint and `saavn.sumit.co` is a fallback deployment. Both are unofficial community services, not guaranteed SLAs.
- `dart_ytmusic_api` remains a metadata/search provider only. No YouTube audio extraction, IFrame player, fabricated media URL, or external playback route is used.
- All eligible online tracks flow into the existing `just_audio` / `just_audio_background` queue.
- LRCLIB search, local/manual lyrics, and synced LRC parsing remain integrated.

## Verification status

- Source archive structure inspected and key Dart, Android, provider, playback, and lyrics files reviewed.
- Static fixture tests added for JioSaavn stream URL parsing and rejecting non-HTTPS / missing audio streams.
- Relative import and XML/YAML checks performed after modifications.
- `flutter analyze`, `flutter test`, `flutter build apk --release`, and device/network playback tests were **not run** because this environment does not contain the Flutter or Dart SDK and cannot reach the community API hosts.
- Therefore no APK is claimed and online playback is not yet runtime-verified. A successful APK build alone would not prove stream playback.


## GitHub CI handoff update

- Workflow now validates on any branch push, pull request, or manual dispatch and does not write to the repository.
- Android Gradle Plugin is 8.6.1 for compileSdk 35 / Gradle 8.7 alignment.
- CI bootstraps the absent Gradle wrapper JAR and uploads the resolved pubspec.lock with a successful APK build.
- CI itself has not yet run; no APK or passing Flutter test result is claimed.
