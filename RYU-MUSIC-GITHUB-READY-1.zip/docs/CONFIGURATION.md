# Online provider configuration

RYU currently uses the following community endpoints:

- JioSaavn API primary: `https://saavn.dev/api/search/songs`
- JioSaavn API fallback: `https://saavn.sumit.co/api/search/songs`
- YouTube Music catalog: `dart_ytmusic_api` (metadata only)
- Lyrics: `https://lrclib.net/api/search`

JioSaavn response mapping expects `data.results[]`, with `id`, `name`, `artists.primary[]`, `album`, `duration`, `image[]`, and `downloadUrl[]`. Only HTTPS URLs in `downloadUrl[]` are eligible for internal playback. If no URL is returned, the song is retained as a catalog result and is not playable.

All network calls have provider-level timeouts. Community services are unofficial and can change response shape, availability, or CDN URL validity. The app must not claim playback until a real Android device successfully plays a returned stream.

YouTube Music is deliberately catalog-only. The application does not extract protected streams and no IFrame or external app player is used.
