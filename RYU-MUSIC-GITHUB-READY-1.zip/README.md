# RYU Music

> Online music search merges JioSaavn community API results (playable only when a real HTTPS CDN URL is returned) with YouTube Music catalog metadata. All audio playback is handled by Flutter `just_audio` inside RYU; catalog-only YouTube results are never sent to an external player.

# RYU — Your Personal Music Experience

Pemutar musik lokal Android berdesain futuristik (*premium dark interface* dengan aksen *violet*, *indigo*, *blue*, dan efek *Liquid Glass*) yang dibangun menggunakan **Flutter**, **Dart**, dan integrasi native Android **`MediaStore`** + **`just_audio_background`**.

---

## Online Music & Provider Notes

- **JioSaavn community API** (`saavn.dev`, fallback `saavn.sumit.co`): searches songs and maps title, artist, album, duration, artwork, and actual CDN stream URLs. Results without a real HTTPS stream remain visible as metadata but are marked unplayable.
- **YouTube Music catalog** (`dart_ytmusic_api`): additional discovery/search metadata only. It does not provide a direct audio stream in this app.
- **Internal playback**: playable HTTP(S) sources are passed to `just_audio` / `just_audio_background`; there is no YouTube IFrame player or external-player playback path.
- **Lyrics**: LRCLIB search and synced LRC parsing remain available.

Both community APIs are unofficial and may change, rate-limit, or become unavailable. JioSaavn's returned media URLs are not guaranteed to remain valid indefinitely. RYU does not extract protected YouTube audio URLs.

## Verifikasi

The current source package has not been compiled or run on an Android device in this environment. See `docs/PROGRESS.md` and `docs/REPAIR_REPORT.md` for the exact checks completed and the outstanding runtime tests.

---

## Fitur Utama

- **Home**: Sapaan dinamis sesuai waktu, *Quick Playlists* (*Favorites*, *Shuffle All*, *Most Played*, *Recently Added*, dan playlist kustom), *Recently Played*, *Featured Albums*, serta *Recommendations* berbasis koleksi musik lokal nyata.
- **Music Player & Background Audio**:
  - Pemindaian audio lokal Android (`MediaStore`) lengkap dengan metadata & ekstraksi album cover resolusi tinggi.
  - Kontrol pemutaran lengkap (*Play*, *Pause*, *Next*, *Previous*, *Seek Bar*, *Shuffle*, *Repeat Off/All/One*).
  - *Queue* interaktif (ubah urutan antrean dengan *drag & drop*, geser untuk hapus, lompat ke lagu tertentu).
  - Pemutaran latar belakang (*background playback*) dengan *audio focus* (`audio_session`) serta kontrol media di *notification shade* & *lock screen* Android lengkap dengan *album art*.
- **Library & Search**:
  - Tab *Songs* (dengan opsi pengurutan), *Albums*, *Artists*, dan *Playlists*.
  - *Favorites* dan *Listening History* tersimpan persisten secara lokal (`shared_preferences`).
  - Manajemen playlist kustom lengkap (buat, ubah nama/deskripsi, tambah banyak lagu sekaligus, hapus lagu).
  - Pencarian instan lintas *Songs*, *Albums*, *Artists*, dan *Playlists* dengan riwayat pencarian (*Recent Searches*).
- **Now Playing & Apple Music-Inspired Synced Lyrics**:
  - *Dynamic ambient background* yang mengekstrak palet warna dominan dari *album artwork* lagu yang sedang diputar.
  - Tampilan lirik berukuran besar dengan *highlight* baris aktif, *auto-scroll* tersinkronisasi, tombol *Sync* saat pengguna menggulir manual, dan *tap baris lirik* untuk melompat ke timestamp tersebut.
  - Mendukung file `.lrc`/`.txt` pendamping di folder yang sama, tag lirik ID3v2 `USLT` tertanam pada file MP3, impor file `.lrc`/`.txt` dari penyimpanan perangkat, input/tempel lirik manual, serta pencarian opsional ke database terbuka [LRCLIB](https://lrclib.net/).

---

## Ringkasan Perbaikan Lengkap

1. **Gradle Wrapper & Build System (`android/gradlew`, `android/settings.gradle.kts`, `.github/workflows/build.yml`)**:
   - Memperbaiki skrip POSIX `android/gradlew` menggunakan standar resmi Gradle 8.7 (`eval set --` + `exec "$JAVACMD" "$@"`) dengan *line ending* Unix `LF` dan izin eksekusi `0755`, disertai *auto-bootstrap* non-destruktif untuk `gradle-wrapper.jar`.
   - Memperbarui `android/settings.gradle.kts` agar memvalidasi keberadaan path Flutter SDK (`local.properties`, `FLUTTER_ROOT`, `FLUTTER_HOME`, maupun `PATH`) sehingga aman di GitHub Actions (`ubuntu-latest`) maupun lokal Windows/macOS/Linux.
   - Menyediakan workflow final `.github/workflows/build.yml` (Java 17 Temurin, Flutter stable, `flutter pub get`, bootstrap aman `gradle-wrapper.jar`, `flutter analyze`, `flutter test`, `flutter build apk --release`, serta upload artefak `RYU-release-apk`).
2. **Stabilitas & Manajemen Antrean `AudioController` (`lib/core/controllers/audio_controller.dart`)**:
   - Memperbaiki *race condition* `currentIndexStream` saat pemuatan playlist baru (`_isSettingSource` guard) agar `_onSongChanged` dieksekusi secara deterministik satu kali.
   - Memperbaiki penanganan selesai antrean (`ProcessingState.completed` pada mode `Repeat Off`), navigasi `seekToNext()` / `seekToPrevious()` dengan dukungan *wrap-around* pada `Repeat All`, serta `seek()` sebelum durasi metadata terbaca.
   - Memperbaiki sinkronisasi `_originalQueue` saat *shuffle*, `playNextInQueue`, `addToQueue`, `moveQueueItem`, dan menghapus lagu yang sedang diputar pada `removeFromQueue`.
   - Menambahkan *pre-caching* artwork untuk lagu berikutnya dan proteksi `_disposed` terhadap pembaruan state asinkron.
3. **Responsivitas `NowPlayingScreen` (`lib/features/player/now_playing_screen.dart`)**:
   - Menggunakan `LayoutBuilder` yang menghitung ukuran *album artwork*, jarak vertikal, ukuran tombol transport, dan skala teks berdasarkan lebar sekaligus tinggi viewport aktual sehingga bebas *overflow* di layar kompak (`360x640`), *split-screen*, *accessibility font scale*, maupun orientasi *landscape*.
4. **Integrasi Native Android `MainActivity.kt` (`android/app/src/main/kotlin/com/ryu/music/MainActivity.kt`)**:
   - Menggunakan `ExecutorService` terkelola untuk pemindaian `MediaStore`, ekstraksi thumbnail dengan `bitmap.recycle()` di blok `finally`, pembacaan tag ID3v2 `USLT` (UTF-16/UTF-8/ISO-8859-1) yang akurat sesuai spesifikasi, serta penanganan aman `pickLrcFile` dengan deteksi BOM UTF-8/UTF-16.

---

## Cara Build APK via GitHub Actions

1. Ekstrak file ZIP ini dan unggah seluruh isi folder `ryu/` (termasuk `.github/workflows/build.yml` dan `.gitignore`) ke repositori GitHub Anda.
2. Buka tab **Actions** pada repositori GitHub Anda:
   - Workflow **Build Android APK** berjalan otomatis saat `push` ke branch `ryu-final-v2`, `main`/`master` atau dapat dijalankan manual via **Run workflow** (`workflow_dispatch`).
3. Unduh hasil kompilasi pada bagian **Artifacts -> `RYU-release-apk`** (`RYU-release.apk`).

---

## Cara Build APK Secara Lokal

```bash
# 1. Unduh dependency Flutter
flutter pub get

# 2. Lengkapi gradle-wrapper.jar secara aman (tanpa menimpa file proyek) & set izin eksekusi
mkdir -p android/gradle/wrapper
TMP_GW=$(mktemp -d)
flutter create "$TMP_GW/app" --platforms=android >/dev/null
cp "$TMP_GW/app/android/gradle/wrapper/gradle-wrapper.jar" android/gradle/wrapper/gradle-wrapper.jar
rm -rf "$TMP_GW"
chmod +x android/gradlew

# 3. Jalankan analisis statis & unit/widget test
flutter analyze
flutter test

# 4. Build Release APK
flutter build apk --release
```

File APK siap instal tersedia di `build/app/outputs/flutter-apk/app-release.apk`.

## GitHub repository setup

The ZIP contains the repository contents. Extract the files directly into the
root of the target GitHub repository (so `.github/`, `android/`, `lib/`,
`test/`, and `pubspec.yaml` are at repository root). The CI workflow runs on
pushes to any branch, pull requests, and manual dispatch. It does not push,
merge, or modify any branch. In particular, it does not write to `main`.

The Gradle wrapper JAR is generated in CI from the installed Flutter SDK when
missing; the project Gradle configuration and wrapper distribution version
remain in source control. CI resolves and uploads `pubspec.lock` as an artifact
because a lockfile could not be generated in the SDK-less preparation
environment. Commit that generated lockfile after reviewing the successful CI
run to pin transitive dependency versions.

The release build currently uses the Android debug signing configuration so
the APK can be installed for testing. It is not a Play Store / production
signing configuration. Configure a private release keystore through GitHub
Actions secrets before distributing a production build.
