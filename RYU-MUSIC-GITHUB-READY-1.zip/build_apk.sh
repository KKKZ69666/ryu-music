#!/usr/bin/env bash
set -euo pipefail

echo "=== [1/5] Mengunduh dependency Flutter (flutter pub get) ==="
flutter pub get

mkdir -p android/gradle/wrapper
if [ ! -f "android/gradlew" ] || [ ! -f "android/gradle/wrapper/gradle-wrapper.jar" ]; then
  echo "=== [2/5] Melengkapi Gradle Wrapper secara aman ==="
  TMP_GW=$(mktemp -d)
  if command -v gradle >/dev/null 2>&1; then
    (cd "$TMP_GW" && gradle wrapper --gradle-version 8.7 --distribution-type all)
    [ -f "android/gradlew" ] || cp "$TMP_GW/gradlew" android/gradlew
    [ -f "android/gradlew.bat" ] || cp "$TMP_GW/gradlew.bat" android/gradlew.bat
    cp "$TMP_GW/gradle/wrapper/gradle-wrapper.jar" android/gradle/wrapper/gradle-wrapper.jar
  else
    flutter create "$TMP_GW/app" --platforms=android --org com.ryu --project-name ryu >/dev/null
    [ -f "android/gradlew" ] || cp "$TMP_GW/app/android/gradlew" android/gradlew
    [ -f "android/gradlew.bat" ] || cp "$TMP_GW/app/android/gradlew.bat" android/gradlew.bat
    cp "$TMP_GW/app/android/gradle/wrapper/gradle-wrapper.jar" android/gradle/wrapper/gradle-wrapper.jar
  fi
  rm -rf "$TMP_GW"
else
  echo "=== [2/5] Gradle Wrapper sudah tersedia ==="
fi
chmod +x android/gradlew

echo "=== [3/5] Analisis statis (flutter analyze) ==="
flutter analyze

echo "=== [4/5] Menjalankan unit test (flutter test) ==="
flutter test

echo "=== [5/5] Build Release APK (flutter build apk --release) ==="
flutter build apk --release

cp build/app/outputs/flutter-apk/app-release.apk ./RYU-release.apk
echo ""
echo "SUKSES! File APK siap instalasi tersimpan di: $(pwd)/RYU-release.apk"
