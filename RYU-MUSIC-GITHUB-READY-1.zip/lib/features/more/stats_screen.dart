import 'package:flutter/material.dart';
import '../../core/services/analytics_service.dart';
import '../../core/theme/ryu_colors.dart';

String fmtDuration(int ms) {
  final m = ms ~/ 60000;
  if (m < 60) return '${m}m';
  return '${m ~/ 60}h ${m % 60}m';
}

class StatsScreen extends StatefulWidget {
  const StatsScreen({super.key});

  @override
  State<StatsScreen> createState() => _StatsScreenState();
}

class _StatsScreenState extends State<StatsScreen> {
  String _range = 'week'; // day, week, month, all (summary range)
  String _chart = 'day'; // day, week, month
  late Future<(StatsSummary, List<Bucket>)> _data;

  @override
  void initState() {
    super.initState();
    _data = _load();
  }

  DateTime? _since() {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    switch (_range) {
      case 'day':
        return today;
      case 'week':
        return today.subtract(const Duration(days: 6));
      case 'month':
        return today.subtract(const Duration(days: 29));
      default:
        return null;
    }
  }

  Future<(StatsSummary, List<Bucket>)> _load() async {
    final a = await AnalyticsService.instance.summary(since: _since());
    final b = await AnalyticsService.instance.buckets(_chart);
    return (a, b);
  }

  void _reload() => setState(() => _data = _load());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Listening stats')),
      body: FutureBuilder<(StatsSummary, List<Bucket>)>(
        future: _data,
        builder: (context, snap) {
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final (sum, buckets) = snap.data!;
          return ListView(padding: const EdgeInsets.fromLTRB(20, 8, 20, 160), children: [
            Wrap(spacing: 8, children: [
              for (final r in const [
                ('day', 'Today'),
                ('week', '7 days'),
                ('month', '30 days'),
                ('all', 'All time'),
              ])
                ChoiceChip(
                  label: Text(r.$2),
                  selected: _range == r.$1,
                  onSelected: (_) {
                    _range = r.$1;
                    _reload();
                  },
                ),
            ]),
            const SizedBox(height: 12),
            Row(children: [
              Expanded(child: _Stat('Listening time', fmtDuration(sum.totalMs))),
              const SizedBox(width: 12),
              Expanded(child: _Stat('Plays', '${sum.plays}')),
            ]),
            const SizedBox(height: 4),
            const Text('A play counts after 5 seconds of actual listening.',
                style: TextStyle(color: RyuColors.textSecondary, fontSize: 12)),
            const SizedBox(height: 20),
            Row(children: [
              const Expanded(
                  child: Text('Activity',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800))),
              SegmentedButton<String>(
                showSelectedIcon: false,
                segments: const [
                  ButtonSegment(value: 'day', label: Text('Day')),
                  ButtonSegment(value: 'week', label: Text('Week')),
                  ButtonSegment(value: 'month', label: Text('Month')),
                ],
                selected: {_chart},
                onSelectionChanged: (s) {
                  _chart = s.first;
                  _reload();
                },
              ),
            ]),
            const SizedBox(height: 12),
            SizedBox(height: 180, child: _BarChart(buckets)),
            const SizedBox(height: 24),
            const Text('Top tracks',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            if (sum.topTracks.isEmpty)
              const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Text('Play some music and your stats will appear here.',
                      style: TextStyle(color: RyuColors.textSecondary))),
            for (var i = 0; i < sum.topTracks.length; i++)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Text('${i + 1}',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                title: Text(sum.topTracks[i].label, maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text(sum.topTracks[i].sub),
                trailing: Text('${sum.topTracks[i].plays}× • ${fmtDuration(sum.topTracks[i].listenedMs)}'),
              ),
            const SizedBox(height: 16),
            const Text('Top artists',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            for (var i = 0; i < sum.topArtists.length; i++)
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: Text('${i + 1}',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
                title: Text(sum.topArtists[i].label, maxLines: 1, overflow: TextOverflow.ellipsis),
                trailing: Text('${sum.topArtists[i].plays}× • ${fmtDuration(sum.topArtists[i].listenedMs)}'),
              ),
          ]);
        },
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat(this.label, this.value);
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
            color: RyuColors.surface, borderRadius: BorderRadius.circular(18)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(value, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900)),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(color: RyuColors.textSecondary)),
        ]),
      );
}

class _BarChart extends StatelessWidget {
  const _BarChart(this.buckets);
  final List<Bucket> buckets;

  @override
  Widget build(BuildContext context) {
    final maxMs = buckets.fold<int>(0, (m, b) => b.listenedMs > m ? b.listenedMs : m);
    if (maxMs == 0) {
      return const Center(
          child: Text('No listening activity in this period yet.',
              style: TextStyle(color: RyuColors.textSecondary)));
    }
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        for (final b in buckets)
          Expanded(
            child: Tooltip(
              message: '${b.label}: ${fmtDuration(b.listenedMs)}, ${b.plays} plays',
              child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                Flexible(
                  child: FractionallySizedBox(
                    heightFactor: (b.listenedMs / maxMs).clamp(0.02, 1.0).toDouble(),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 2),
                      decoration: BoxDecoration(
                        gradient: RyuColors.accent,
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 4),
                Text(b.label,
                    maxLines: 1,
                    overflow: TextOverflow.clip,
                    style: const TextStyle(fontSize: 8.5, color: RyuColors.textSecondary)),
              ]),
            ),
          ),
      ],
    );
  }
}
