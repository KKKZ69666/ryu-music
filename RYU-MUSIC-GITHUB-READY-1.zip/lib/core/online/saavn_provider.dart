import 'dart:async';

import 'package:flutter/foundation.dart';

import '../models/song.dart';
import '../utils/uri_utils.dart';
import 'music_provider.dart';
import 'online_models.dart';

/// JioSaavn community API adapter.
///
/// Search results are only marked playable when the API actually returns an
/// HTTPS CDN URL in `downloadUrl`. No URL is synthesized from song metadata.
class SaavnProvider extends MusicProvider {
  static const List<String> _baseUrls = [
    'https://saavn.dev',
    'https://saavn.sumit.co',
  ];
  static const Duration _timeout = Duration(seconds: 8);

  @override
  String get id => 'jiosaavn';
  @override
  String get displayName => 'JioSaavn';
  @override
  bool get isAvailable => true;
  @override
  String? get unavailableReason => null;
  @override
  bool get supportsDownload => false;
  @override
  String get licenseNote =>
      'Unofficial community API. Playback uses only CDN URLs returned by the service.';

  static String? _bestImage(dynamic value) {
    if (value is! List) return null;
    final urls = value
        .whereType<Map>()
        .map((e) => (e['url'] ?? '').toString())
        .where((s) => s.startsWith('https://') || s.startsWith('http://'))
        .toList();
    return urls.isEmpty ? null : UriUtils.preferHttps(urls.last);
  }

  /// Selects the highest advertised quality that has a real HTTPS URL.
  @visibleForTesting
  static String? playableUrl(dynamic value) {
    if (value is! List) return null;
    final candidates = <(int, String)>[];
    for (final item in value.whereType<Map>()) {
      final raw = (item['url'] ?? '').toString().trim();
      final uri = Uri.tryParse(raw);
      if (uri == null || uri.scheme != 'https' || uri.host.isEmpty) continue;
      final quality = int.tryParse(
            (item['quality'] ?? '').toString().replaceAll(RegExp(r'[^0-9]'), ''),
          ) ??
          0;
      candidates.add((quality, raw));
    }
    if (candidates.isEmpty) return null;
    candidates.sort((a, b) => b.$1.compareTo(a.$1));
    return candidates.first.$2;
  }

  @visibleForTesting
  static Song? songFromJson(Map<String, dynamic> json) {
    final id = (json['id'] ?? '').toString().trim();
    final title = (json['name'] ?? json['title'] ?? '').toString().trim();
    if (id.isEmpty || title.isEmpty) return null;

    final artists = json['artists'];
    String artist = '';
    if (artists is Map && artists['primary'] is List) {
      artist = (artists['primary'] as List)
          .whereType<Map>()
          .map((e) => (e['name'] ?? '').toString())
          .where((s) => s.isNotEmpty)
          .join(', ');
    }
    if (artist.isEmpty) artist = (json['primaryArtists'] ?? json['subtitle'] ?? 'Unknown Artist').toString();
    final albumValue = json['album'];
    final album = albumValue is Map
        ? (albumValue['name'] ?? '').toString()
        : (json['album'] ?? '').toString();
    final durationSeconds = int.tryParse((json['duration'] ?? '0').toString()) ?? 0;
    final image = _bestImage(json['image']);
    final stream = playableUrl(json['downloadUrl']);

    // Keep catalog metadata even when no direct audio URL is supplied.
    // The non-HTTP marker is intentionally rejected by Song.isPlayable.
    return Song.online(
      provider: 'jiosaavn',
      remoteId: id,
      title: title,
      artist: artist,
      album: album,
      durationMs: durationSeconds * 1000,
      streamUrl: stream ?? 'saavn://catalog/$id',
      downloadUrl: null,
      artworkUrl: image,
    );
  }

  Future<Map<String, dynamic>> _request(String path, Map<String, String> query) async {
    Object? lastError;
    for (final base in _baseUrls) {
      try {
        final uri = Uri.parse('$base$path').replace(queryParameters: query);
        final response = await getJson(uri, timeout: _timeout);
        if (response['success'] == false) {
          throw ProviderException('JioSaavn rejected the request');
        }
        return response;
      } catch (error) {
        lastError = error;
      }
    }
    throw ProviderException('JioSaavn endpoints unavailable: $lastError');
  }

  @override
  Future<PagedResult<Song>> searchTracks(String q, {int offset = 0, int limit = 20}) async {
    if (q.trim().isEmpty) return const PagedResult([], hasMore: false);
    try {
      final page = offset ~/ limit;
      final json = await _request('/api/search/songs', {
        'query': q.trim(),
        'page': '$page',
        'limit': '$limit',
      });
      final data = json['data'];
      final results = data is Map ? data['results'] : null;
      if (results is! List) return const PagedResult([], hasMore: false);
      final songs = results
          .whereType<Map>()
          .map((e) => songFromJson(Map<String, dynamic>.from(e)))
          .whereType<Song>()
          .toList();
      final total = int.tryParse((data is Map ? data['total'] : null).toString()) ?? 0;
      return PagedResult(songs, hasMore: total > offset + results.length);
    } on TimeoutException {
      throw ProviderException('JioSaavn request timed out');
    } catch (e) {
      if (e is ProviderException) rethrow;
      throw ProviderException('JioSaavn search failed: $e');
    }
  }

  @override
  Future<PagedResult<OnlineArtist>> searchArtists(String q, {int offset = 0, int limit = 20}) async =>
      const PagedResult([], hasMore: false);
  @override
  Future<PagedResult<OnlineAlbum>> searchAlbums(String q, {int offset = 0, int limit = 20}) async =>
      const PagedResult([], hasMore: false);
  @override
  Future<PagedResult<OnlinePlaylist>> searchPlaylists(String q, {int offset = 0, int limit = 20}) async =>
      const PagedResult([], hasMore: false);
  @override
  Future<List<Song>> artistTracks(OnlineArtist artist, {int limit = 50}) async => [];
  @override
  Future<List<Song>> albumTracks(OnlineAlbum album) async => [];
  @override
  Future<List<Song>> playlistTracks(OnlinePlaylist playlist) async => [];
  @override
  Future<List<Song>> trending({int limit = 20}) async => [];
}
