import 'music_provider.dart';
import 'saavn_provider.dart';
import 'ytmusic_provider.dart';

/// Registry of catalog and playable online providers.
class ProviderHub {
  ProviderHub._();
  static final ProviderHub instance = ProviderHub._();

  final List<MusicProvider> all = [
    SaavnProvider(),
    YTMusicProvider(),
  ];

  List<MusicProvider> get available => all.where((p) => p.isAvailable).toList();

  MusicProvider? byId(String id) {
    for (final p in all) {
      if (p.id == id) return p;
    }
    return null;
  }

  YTMusicProvider? get catalog {
    for (final p in all) {
      if (p is YTMusicProvider) return p;
    }
    return null;
  }
}
